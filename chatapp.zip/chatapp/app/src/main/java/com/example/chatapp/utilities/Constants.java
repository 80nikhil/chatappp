package com.example.chatapp.utilities;

import java.util.HashMap;

public class Constants {
    public static  final String KEY_COLLECTION_USERS = "users";
    public static  final String KEY_COLLECTION_BLOCKED_USERS = "blockusers";
    public static final String KEY_NAME = "name";
    public  static final  String KEY_EMAIL = "email";
    public static final String KEY_PREFRENCE_NAME = "chatAppPrefrence";
    public static final String KEY_IS_SIGNED_IN="isSignedIn";
    public static final String KEY_USER_ID ="userId";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_FCM_TOKEN = "fcmToken";
    public static final String KEY_USER = "user";
    public static final String KEY_COLLECTION_CHAT = "chat";
    public static final String KEY_SENDER_ID = "senderId";
    public static final String KEY_RECIEVER_ID = "recieverId";
    public static final String KEY_MESSAGE = "message";
    public static final String KEY_TIMESTAMP = "timestamp";
    public static final String KEY_COLLECTION_CONVERSATIONS = "conversations";
    public static final String KEY_SENDER_NAME = "senderName";
    public static final String KEY_RECIEVER_NAME = "recieverName";
    public static final String KEY_SENDER_IMAGE = "senderImage";
    public static final String KEY_RECIEVER_IMAGE = "recieverImage";
    public static final String KEY_LAST_MESSAGE = "lastMessage";
    public static final String KEY_AVAILIBILITY = "availibility";
    public static final String REMOTE_MSG_AUTHORIZATION = "Authorization";
    public static final String REMOTE_MSG_CONTENT_TYPE = "Content-Type";
    public static final String REMOTE_MSG_DATA = "data";
    public static final String REMOTE_MSG_REGISTRATION_IDS = "registration_ids";
    public static final String KEY_GENDER = "gender";
    public static final String KEY_VALIDITY = "validity";

    ///-----------------------post---profile-------------------------------///

    public static final String KEY_POST_PROFILE = "profiles";
    public static final String KEY_POST_BOY = "boys";
    public static final String KEY_POST_GIRL = "girls";
    public static final String KEY_POST_WIDOW = "widows";
    public static final String KEY_POST_DIVORCED = "divorceds";
    public static final String KEY_PROFILE = "profile";
    public static final String KEY_POST_IMAGE = "postimage";
    public static final String KEY_PROFILE_FIRST_NAME = "firstname";
    public static final String KEY_PROFILE_MIDDLE_NAME = "middlename";
    public static final String KEY_PROFILE_LAST_NAME = "lastname";
    public static final String KEY_PROFILE_DATEOFBIRTH ="dateofbirth";
    public static final String KEY_FATHER_NAME = "fathername";
    public static final String KEY_MOTHER_NAME = "mothername";
    public static final String KEY_CURRENT_ADDRESS = "currentaddress";
    public static final String KEY_HOMETOWN_ADDRESS = "hometownaddress";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_FATHER_OCCUPATION = "fatheroccupation";
    public static final String KEY_MOTHER_OCCUPATION ="motheroccupation";
    public static final String KEY_WEIGHT = "weight";
    public static final String KEY_HEIGHT_FEET ="heightfeet";
    public static final String KEY_HEIGHT_INCHES = "heightinches";
    public static final String KEY_CAST = "CAST";
    public static final String KEY_SELECT_EDUCATION = "education";
    public static final String KEY_SELECT_OCCUPATION = "occupation";
    public static final String KEY_MONTHLY_INCOME = "monthlyincome";
    public static final String KEY_SELECT_SISTER = "sister";
    public static final String KEY_SELECT_BROTHER = "brother";
    public static final String KEY_IS_MANGLIK = "manglik";
    public static final String KEY_IS_DIVORCED = "divorced";
    public static final String KEY_IS_WIDOW = "widow";
    public static final String KEY_ALLOW_CALL = "allowcall";
    public static final String KEY_CURRENT_DATE_TIME = "currentDateandTime";

    ////----------------------Advertisement------------------------------/////
    public static final String KEY_POST_ADVERTISEMENT = "advertisements";
    public static final String KEY_ADVERTISE = "advertisement";
    public static final String KEY_ADVERTISE_IMAGE = "advertiseimage";
    public static final String KEY_TITLE_NAME = "titlename";
    public static final String KEY_OWNER_NAME = "ownername";
    public static final String KEY_OWNER_CONTACT = "ownwercontact";
    public static final String KEY_CITY = "city" ;
    public static final String KEY_STATE = "state";
    public static final String KEY_CONTACT_NO = "contact" ;
    public static final String KEY_MAP_ID = "mapid";
    public static final String KEY_LOCATION = "location";
    public static final String KEY_POST_LOCATION = "post_location";
    public static final String KEY_ID = "id";
    public static final String KEY_BOARDING = "boarding";
    public static final String KEY_SCREEN_ID = "screenid";
    public static final String KEY_ADVERTISEMENT_ADDRESS = "advertisementaddress";
    public static final String KEY_POST_IMAGE_IN = "postimagein";
    public static final String KEY_PROFILE_RECIEVER_ID = "profilerecieverid";
    public static final String KEY_PAYMENT_POST = "paymentpost";
    public static final String KEY_SPECIAL = "special";


    //-------------------------------profilechatsection------------------------------//

    public static final String KEY_PROFILE_RECIEVER_CHAT = "profilerecieverchat";
    public static final String KEY_PROFILE_RECIEVER_IMAGE = "profilerecieverimage";
    public static final String KEY_PROFILE_RECIEVER_FCM_TOKEN ="profilerecieverfcmtoken" ;
    public static final String KEY_PROFILE_RECIEVER_NAME = "recievername";
    public static final String KEY_COLLECTION_PROFILE_CHAT = "profilechat";
    public static final String KEY_COLLECTION_PROFILE_CONVERSATIONS = "profileconversation";
    public static final String KEY_PROFILE_LAST_MESSAGE = "profilelastmessage";

    //------------------next Refrence  for ptrofile chat-------////

    public static final String KEY_PROFILE_POST_ID = "profilepostid";
    public static final String KEY_TYPE = "type" ;
    public static final String KEY_UNSEEN = "unseen" ;
    public static final String KEY_POST_SPECIAL = "specialpost";
    public static final String PAYMENT = "payment";
    public static final String KEY_POST_IMAGE2 = "postimage2" ;
    public static final String KEY_ACTIVITY = "activity";
    public static final String KEY_POST_CURRENT_ADDRESS = "post_current_address";
    public static final String KEY_BLOCKED_BY = "blockedby" ;
    public static final String KEY_BLOCKED_USER = "blockeduser";
    public static final String KEY_STATUS = "status" ;
    public static final String KEY_POST_CITY = "post_city";
    public static final String KEY_POST_STATE = "post_state";


    ///------------------------messaging--firebase-------------------------///

    public static HashMap<String,String> remoteMsgHeaders = null;
    public static HashMap<String,String> getRemoteMsgHeader(){
        if(remoteMsgHeaders == null){
            remoteMsgHeaders = new HashMap<>();
            remoteMsgHeaders.put(
                    REMOTE_MSG_AUTHORIZATION,
                    "key=AAAAMq98sz0:APA91bF0Rx6lLe1BznnhIXOm3zyNFadnJko3y50nCybxlaO3Qu5arzB-_lHdcH0iSDME_qJk2vz7Y1x7OrXkicBeXhu16oFHgd8uIQiTXU0_WB0VlFCU2qAtRasiHrPYUcGT0zGiv5Hd"
            );
            remoteMsgHeaders.put(
                    REMOTE_MSG_CONTENT_TYPE,
                    "application/json"
            );
        }
        return remoteMsgHeaders;
    }
}
