package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.utilities.Constants;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.makeramen.roundedimageview.RoundedImageView;

public class AdvertisementdetailActivity extends AppCompatActivity {

    TextView titlename,ownername,ownercontacts,currentadd,description,textrecievername;
    String id,no;
    ImageView backbtnA , imageView;
    Button call,chat;
    RelativeLayout rluser;
    RoundedImageView recieverimage;
    String recieverid,chatrecieverimage,chatrecivername,chattoken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advertisementdetail);

        id = getIntent().getExtras().getString(Constants.KEY_ID);
        titlename = findViewById(R.id.titlenameA);
        ownername = findViewById(R.id.Owner_NameA);
        ownercontacts = findViewById(R.id.Owner_contactsA);
        currentadd = findViewById(R.id.current_addressA);
        description = findViewById(R.id.DescriptionA);
        imageView = findViewById(R.id.postimageA);
        call = findViewById(R.id.callbtn);
        rluser = findViewById(R.id.rluser);
        recieverimage = findViewById(R.id.profile_post_image2);
        textrecievername = findViewById(R.id.profile_post_name2);
        chat = findViewById(R.id.chatbtn);
        getadvertisementData();

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdvertisementdetailActivity.this, ProfileChat.class);
                i.putExtra(Constants.KEY_USER_ID, recieverid);
                i.putExtra(Constants.KEY_IMAGE, chatrecieverimage);
                i.putExtra(Constants.KEY_NAME, chatrecivername);
                i.putExtra(Constants.KEY_FCM_TOKEN, chattoken);
                i.putExtra(Constants.KEY_MESSAGE, "I want to chat for");
                startActivity(i);
            }
        });
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                String temp = "tel:" + no;
                intent.setData(Uri.parse(temp));
                startActivity(intent);
            }
        });

        rluser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Chatprofileinfo.class);
                i.putExtra(Constants.KEY_RECIEVER_ID,recieverid);
                startActivity(i);
            }
        });
    }

    private void getadvertisementData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = documentSnapshot.getString(Constants.KEY_RECIEVER_ID);
                        titlename.setText(documentSnapshot.getString(Constants.KEY_TITLE_NAME));
                        ownername.setText(documentSnapshot.getString(Constants.KEY_OWNER_NAME));
                        ownercontacts.setText(documentSnapshot.getString(Constants.KEY_OWNER_CONTACT));
                        currentadd.setText(documentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS));
                        description.setText(documentSnapshot.getString(Constants.KEY_DESCRIPTION));
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        imageView.setImageBitmap(bitmap);
                        no = documentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                        getuser();
                    }
                });
    }
    public  void getuser(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .document( recieverid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        chatrecieverimage = documentSnapshot.getString(Constants.KEY_IMAGE);
                        chatrecivername = documentSnapshot.getString(Constants.KEY_NAME);
                        textrecievername.setText(chatrecivername);
                        byte[] bytes = Base64.decode(chatrecieverimage,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        recieverimage.setImageBitmap(bitmap);
                        chattoken = documentSnapshot.getString(Constants.KEY_FCM_TOKEN);
                    }
                });
    }
}

