package com.example.chatapp.adapters;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.makeramen.roundedimageview.RoundedImageView;
import com.skydoves.androidribbon.ShimmerRibbonView;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {

    private ArrayList<FavouriteModal> courseModalArrayList;
    private Context context;
    private DocumentReference documentReference;
    FirebaseFirestore database;
    PrefrenceManager prefrenceManager;
    private MybagClickInterface mybagClickInterface;
    public FavoriteAdapter(ArrayList<FavouriteModal> courseModalArrayList, Context context) {
        this.courseModalArrayList = courseModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public FavoriteAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_favorite_profile, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteAdapter.ViewHolder holder,@SuppressLint("RecyclerView") int position) {
        FavouriteModal modal = courseModalArrayList.get(position);
        holder.name.setText(modal.getName());
        holder.adress.setText(modal.getCity());
        holder.dateofbirth.setText(modal.getDateofbirth());
        holder.sister.setText(modal.getSister());
        holder.education.setText(modal.getEducation());
        holder.cast.setText(modal.getCast());
        holder.brother.setText(modal.getBrother());
        holder.currentdate.setText(modal.getTextdatetime());
        if(modal.getFavimage() != null) {
            holder.favimage.setImageBitmap(getProfileImage(modal.getFavimage()));
        }
       if(modal.getSpecial() != null) {
           if(modal.getSpecial().equals("special")){
               holder.ribbon.setVisibility(View.VISIBLE);
           }
       }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
            String CurrentDate = sdf.format(new Date());
            String FinalDate = modal.getTextdatetime();
            Date date1;
            Date date2;
            SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
            date1 = dates.parse(CurrentDate);
            date2 = dates.parse(FinalDate);
            long difference = Math.abs(date1.getTime() - date2.getTime());
            long differenceDates = difference / (24 * 60 * 60 * 1000);
            long valid = Long.parseLong(modal.getValidity());
            if (differenceDates <= valid) {
               holder.active.setText("Active");
               holder.active.setBackgroundResource(R.drawable.gradient_green);
            }else{
                holder.active.setText("Inactive");
                holder.active.setBackgroundResource(R.drawable.gradient);
            }
            holder.cardfavorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(modal.getId() != null){
                        Intent i = new Intent(context.getApplicationContext(), FavoritePostDetailActivity.class);
                        i.putExtra(Constants.KEY_ID,modal.getId());
                        i.putExtra(Constants.KEY_SPECIAL,modal.getSpecial());
                        context.startActivity(i);
                    }else{
                        Toast.makeText(context.getApplicationContext(),"error",Toast.LENGTH_SHORT).show();
                    }
                }
            });
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                prefrenceManager = new PrefrenceManager(context.getApplicationContext());
                FavouriteModal modal = courseModalArrayList.get(position);
                SharedPreferences sharedPreferences = context.getSharedPreferences("shared preferences", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String json1 = sharedPreferences.getString("courses", null);
                Gson gson = new Gson();
                Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();
                courseModalArrayList = gson.fromJson(json1, type);
                courseModalArrayList.remove(position);
                prefrenceManager.putString(modal.getId(),null);
                String json = gson.toJson(courseModalArrayList);
                editor.putString("courses", json);
                editor.apply();
                notifyDataSetChanged();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return courseModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView name, adress,cast,brother,sister,education,dateofbirth,city,currentdate,active,delete;
        RoundedImageView favimage;
        ShimmerRibbonView ribbon;
        CardView cardfavorite;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // initializing our views with their ids.
            name = itemView.findViewById(R.id.mprofile_post_name);
            adress = itemView.findViewById(R.id.mprofilecity);
            cast = itemView.findViewById(R.id.mprofilecast);
            brother = itemView.findViewById(R.id.mbrother);
            sister = itemView.findViewById(R.id.msisters);
            education = itemView.findViewById(R.id.mprofileeducation);
            dateofbirth = itemView.findViewById(R.id.mprofiledateofbirth);
            city = itemView.findViewById(R.id.mprofilecity);
            currentdate = itemView.findViewById(R.id.mprofilecurrenttimedate);
            favimage = itemView.findViewById(R.id.mprofile_post_image);
            ribbon = itemView.findViewById(R.id.ribbonfavorite);
            active = itemView.findViewById(R.id.mactive);
            delete = itemView.findViewById(R.id.txtdelete);
            cardfavorite = itemView.findViewById(R.id.cardfavorite);
        }
    }
       private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
    public interface  MybagClickInterface{
        void onmybagClick(int position);
    }

}
