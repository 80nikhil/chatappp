package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignInactivity extends AppCompatActivity {
    EditText edtemail,edtpassword;
    TextView txtlogin,forgetpassword;
    Button btnlogin;
    ProgressBar progressBar;
    ImageView passwordtoggle;
    private PrefrenceManager prefrenceManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_inactivity);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        edtemail = findViewById(R.id.edt_email);
        edtpassword = findViewById(R.id.edt_password);
        btnlogin = findViewById(R.id.btn_login);
        txtlogin = findViewById(R.id.tt_login);
        progressBar = findViewById(R.id.progressbar);
        passwordtoggle = findViewById(R.id.password_toggle);
        passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
        prefrenceManager =new PrefrenceManager(getApplicationContext());
        forgetpassword = findViewById(R.id.forget_password);


        forgetpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),ForgetPassword.class);
                i.putExtra(Constants.KEY_ACTIVITY,"forget");
                startActivity(i);
            }
        });

        passwordtoggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    edtpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
                    edtpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        txtlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SignInactivity.this, ForgetPassword.class);
                i.putExtra(Constants.KEY_ACTIVITY,"register");
                startActivity(i);
            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isValidSignInDetails()){
                    progressBar.setVisibility(View.VISIBLE);
                    btnlogin.setVisibility(View.INVISIBLE);
                    signIn();
                }
            }
        });
    }

    private void signIn() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .whereEqualTo(Constants.KEY_EMAIL,edtemail.getText().toString())
                .whereEqualTo(Constants.KEY_PASSWORD,edtpassword.getText().toString())
                .get()
                .addOnCompleteListener(task -> {
                   if(task.isSuccessful() && task.getResult() != null &&
                           task.getResult().getDocuments().size() >0){
                       progressBar.setVisibility(View.INVISIBLE);
                       btnlogin.setVisibility(View.VISIBLE);
                       DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                       prefrenceManager.putBoolean(Constants.KEY_IS_SIGNED_IN,true);
                       prefrenceManager.putString(Constants.KEY_USER_ID,documentSnapshot.getId());
                       prefrenceManager.putString(Constants.KEY_NAME,documentSnapshot.getString(Constants.KEY_NAME));
                       prefrenceManager.putString(Constants.KEY_IMAGE,documentSnapshot.getString(Constants.KEY_IMAGE));
                       prefrenceManager.putString(Constants.KEY_CITY,documentSnapshot.getString(Constants.KEY_CITY));
                       prefrenceManager.putString(Constants.KEY_STATE,documentSnapshot.getString(Constants.KEY_STATE));
                       prefrenceManager.putString(Constants.KEY_CONTACT_NO,documentSnapshot.getString(Constants.KEY_CONTACT_NO));
                       prefrenceManager.putString(Constants.KEY_EMAIL,documentSnapshot.getString(Constants.KEY_EMAIL));
                       Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                       i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                       startActivity(i);
                   }else{
                       progressBar.setVisibility(View.INVISIBLE);
                       btnlogin.setVisibility(View.VISIBLE);
                       loading(false);
                       showToast("Unable to login");
                   }
                });
    }
    public void loading(Boolean isLoading){
        if(isLoading){
            btnlogin.setVisibility(View.INVISIBLE);
        }else{
            btnlogin.setVisibility(View.VISIBLE);
        }
    }

    private void showToast(String message){
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
    }
    private Boolean isValidSignInDetails(){
        if(edtemail.getText().toString().isEmpty()){
            showToast("Enter Email");
            return false;
        }else if(edtpassword.getText().toString().isEmpty()){
            showToast("Enter Password");
            return false;
        }else{
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}