package com.example.chatapp.activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class PostActivity extends AppCompatActivity {

    ImageView postimage,imgcalender,locationcurrent,locationhometown,Backbtn;
    EditText firstname,lastname,middlename,dateofbirth,fathername,
            mothername,description;
    TextView currentaddress,hometownadress;
    Button submit;
    Spinner spinnerfatheroccupation,spinnermotheroccupation,spinnerweight,spinnerheightfeet
            ,spinnerheightinch,spinnerselectcast,spinnerselecteducation,spinnerselectoccupation,
            spinnermontlyincome,spinnerselectsister,spinnerselectbrother;
    SwitchCompat ismanglik,isdivorced,allowcall,iswidow;
    String manglik,divorced,alowcall,widow,gender,currentDateandTime,validity,special,payment,city,state;
    ProgressBar progressBar;
    private String encodedImage,encodedImage2;
    RadioGroup radioGroupGender;
    RadioButton radioGenderMale,radioGenderFemale;
    final Calendar myCalendar= Calendar.getInstance();
    private PrefrenceManager prefrenceManager;
    private ArrayList<FavouriteModal> postArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        postimage = findViewById(R.id.postimage);
        firstname = findViewById(R.id.edtfirstname);
        middlename = findViewById(R.id.edtmiddlename);
        lastname = findViewById(R.id.edtlastname);
        dateofbirth = findViewById(R.id.edtdob);
        fathername = findViewById(R.id.edtfathername);
        mothername = findViewById(R.id.edtmothername);
        currentaddress = findViewById(R.id.edtcurrentaddresss);
        hometownadress = findViewById(R.id.edthometownaddresss);
//        city = findViewById(R.id.edtcity);
//        state = findViewById(R.id.edtstate);
        description = findViewById(R.id.edtdescription);
        submit = findViewById(R.id.btn_submit);
        spinnerfatheroccupation = findViewById(R.id.spinnerfatheroccupation);
        spinnermotheroccupation = findViewById(R.id.spinnermotherocccupation);
        spinnerweight = findViewById(R.id.spinnerselectweight);
        spinnerheightfeet = findViewById(R.id.spinnerselectheightfeet);
        spinnerheightinch = findViewById(R.id.spinnerselectheightinch);
        spinnerselectcast = findViewById(R.id.spinnerselectcast);
        spinnerselecteducation = findViewById(R.id.spinnerselecteducation);
        spinnerselectoccupation = findViewById(R.id.spinnerselectoccupation);
        spinnermontlyincome = findViewById(R.id.spinnermonthlyincome);
        spinnerselectsister = findViewById(R.id.spinnerCountSister);
        spinnerselectbrother = findViewById(R.id.spinnerCountBrothers);
        ismanglik = findViewById(R.id.switchIsManglik);
        isdivorced = findViewById(R.id.switchIsDivorced);
        iswidow = findViewById(R.id.switchIsWidow);
        allowcall = findViewById(R.id.Allowcall);
        radioGenderFemale = findViewById(R.id.radioGenderFemale);
        radioGenderMale = findViewById(R.id.radioGenderMale);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        imgcalender = findViewById(R.id.imgcalendar);
        locationcurrent = findViewById(R.id.location_current);
        locationhometown = findViewById(R.id.location_hometown);
        Backbtn = findViewById(R.id.backbtn);
        progressBar = findViewById(R.id.progresspost);
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        loaddata();
        Backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(i);
                finish();
            }
        });

        locationhometown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PostActivity.this, MapActivity.class);
                prefrenceManager.putString(Constants.KEY_ID,"hometown");
                startActivityForResult(intent, 02);
            }
        });

        locationcurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PostActivity.this, MapActivity.class);
                prefrenceManager.putString(Constants.KEY_ID,"current");
                startActivityForResult(intent, 01);
            }
        });


        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                prefrenceManager.putString(Constants.KEY_MAP_ID,"postmap");
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        imgcalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.DATE, 0);
                Date newDate = calendar.getTime();
                DatePickerDialog datePickerDialog = new DatePickerDialog(PostActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.getDatePicker().setMaxDate(newDate.getTime() - (newDate.getTime() % (24 * 60 * 60 * 1000)));
                datePickerDialog.show();
            }
        });


        postimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                pickImage.launch(intent);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submit.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                currentDateandTime = sdf.format(new Date());
                if(payment == null){
                    Intent intent = new Intent(PostActivity.this, PaymentActivity.class);
                    intent.putExtra("type","post");
                    startActivityForResult(intent, 03);
                    submit.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.INVISIBLE    );
                }else {
                    if (isValidPostDetails()) {
                        if (isdivorced.isChecked()) {
                            postprofileDivorced();
                        }
                        if (iswidow.isChecked()) {
                            postprofilewidow();
                        }
                        if (radioGenderMale.isChecked()) {
                            postprofileboy();
                        }
                        if (radioGenderFemale.isChecked()) {
                            postprofileGirl();
                        }
                        if (special != null) {
                            postspecialprofile();
                        }
                        if (special == null) {
                            postprofile();
                        }
                        prefrenceManager.putString(Constants.KEY_PAYMENT_POST, "yes");
                    }
                }
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
        if (requestCode == 01) {
                currentaddress.setText(data.getStringExtra(Constants.KEY_CURRENT_ADDRESS));
                city = data.getStringExtra(Constants.KEY_POST_CITY);
                state = data.getStringExtra(Constants.KEY_STATE);
            }else if (requestCode == 02) {
                hometownadress.setText(data.getStringExtra(Constants.KEY_HOMETOWN_ADDRESS));
            }else if (requestCode == 03) {
               validity = data.getStringExtra(Constants.KEY_VALIDITY);
               special = data.getStringExtra(Constants.KEY_SPECIAL);
               payment = data.getStringExtra(Constants.PAYMENT);
            }
        }
    }

    private void postspecialprofile() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_CONTACT_NO,prefrenceManager.getString(Constants.KEY_CONTACT_NO));
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_SPECIAL,special);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        database.collection(Constants.KEY_POST_SPECIAL)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                    Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void postprofileboy() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_SPECIAL,special);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        database.collection(Constants.KEY_POST_BOY)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                    prefrenceManager.putString(Constants.KEY_PROFILE_POST_ID,documentReference.getId());
                })
                .addOnFailureListener(exception -> {
                    });
    }

    private void postprofilewidow() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_SPECIAL,special);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        database.collection(Constants.KEY_POST_WIDOW)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                })
                .addOnFailureListener(exception -> {
                });
    }

    private void postprofileGirl() {    FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_SPECIAL,special);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        database.collection(Constants.KEY_POST_GIRL)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                    })
                .addOnFailureListener(exception -> {
                  });
    }

    private void postprofileDivorced() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_SPECIAL,special);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        database.collection(Constants.KEY_POST_DIVORCED)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                    Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                    Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }


    private final ActivityResultLauncher<Intent> pickImage = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK){
                    if(result.getData() != null){
                        Uri imageurl = result.getData().getData();
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(imageurl);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            encodedImage = encodeImage(bitmap);
                            encodedImage2 = encodedImage2(bitmap);
                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
            }
    );

    private String encodedImage2(Bitmap bitmap) {
        int previewWidth = 760;
        int previewHeight = 640 ;
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,true);
        postimage.setImageBitmap(previewBitmap);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.PNG,100,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }

    private String encodeImage(Bitmap bitmap){
        int previewWidth = 150;
        int previewHeight = bitmap.getHeight()*previewWidth/bitmap.getWidth();
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,true);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG,50,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }


    private void postprofile() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> profile = new HashMap<>();
        profile.put(Constants.KEY_VALIDITY,validity);
        profile.put(Constants.KEY_PROFILE_FIRST_NAME,firstname.getText().toString());
        profile.put(Constants.KEY_PROFILE_MIDDLE_NAME,middlename.getText().toString());
        profile.put(Constants.KEY_PROFILE_LAST_NAME,lastname.getText().toString());
        profile.put(Constants.KEY_PROFILE_DATEOFBIRTH,dateofbirth.getText().toString());
        profile.put(Constants.KEY_MOTHER_NAME,mothername.getText().toString());
        profile.put(Constants.KEY_CURRENT_ADDRESS,currentaddress.getText().toString());
        profile.put(Constants.KEY_HOMETOWN_ADDRESS,hometownadress.getText().toString());
        profile.put(Constants.KEY_DESCRIPTION,description.getText().toString());
        profile.put(Constants.KEY_FATHER_OCCUPATION,spinnerfatheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_MOTHER_OCCUPATION,spinnermotheroccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_WEIGHT,spinnerweight.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_FEET,spinnerheightfeet.getSelectedItem().toString());
        profile.put(Constants.KEY_HEIGHT_INCHES,spinnerheightinch.getSelectedItem().toString());
        profile.put(Constants.KEY_CAST,spinnerselectcast.getSelectedItem().toString());
        profile.put(Constants.KEY_MONTHLY_INCOME,spinnermontlyincome.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_EDUCATION,spinnerselecteducation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_OCCUPATION,spinnerselectoccupation.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_SISTER,spinnerselectsister.getSelectedItem().toString());
        profile.put(Constants.KEY_SELECT_BROTHER,spinnerselectbrother.getSelectedItem().toString());
        profile.put(Constants.KEY_FATHER_NAME,fathername.getText().toString());
        profile.put(Constants.KEY_IS_MANGLIK,manglik);
        profile.put(Constants.KEY_IS_DIVORCED,divorced);
        profile.put(Constants.KEY_IS_WIDOW,widow);
        profile.put(Constants.KEY_GENDER,gender);
        profile.put(Constants.KEY_CONTACT_NO,prefrenceManager.getString(Constants.KEY_CONTACT_NO));
        profile.put(Constants.KEY_ALLOW_CALL,alowcall);
        profile.put(Constants.KEY_CURRENT_DATE_TIME,currentDateandTime);
        profile.put(Constants.KEY_POST_IMAGE,encodedImage);
        profile.put(Constants.KEY_PROFILE_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        profile.put(Constants.KEY_CITY,city);
        profile.put(Constants.KEY_STATE,state);
        profile.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
        profile.put(Constants.KEY_SPECIAL,null);
        profile.put(Constants.KEY_POST_IMAGE2,encodedImage2);
        database.collection(Constants.KEY_POST_PROFILE)
                .add(profile)
                .addOnSuccessListener(documentReference -> {
                    prefrenceManager.putString(Constants.PAYMENT,null);
                    prefrenceManager.putString(Constants.KEY_VALIDITY,null);
                    prefrenceManager.putString(Constants.KEY_SPECIAL,null);
                    Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                    progressBar.setVisibility(View.INVISIBLE);
                    submit.setVisibility(View.VISIBLE);
                    String id = documentReference.getId();
                    postArrayList.add(new FavouriteModal(firstname.getText().toString()+middlename.getText().toString()+lastname.getText().toString(), dateofbirth.getText().toString(),
                            spinnerselecteducation.getSelectedItem().toString(), spinnerselectsister.getSelectedItem().toString(), spinnerselectbrother.getSelectedItem().toString(),
                            spinnerselectcast.getSelectedItem().toString(), currentDateandTime, prefrenceManager.getString(Constants.KEY_CITY)+","+prefrenceManager.getString(Constants.KEY_STATE),
                            encodedImage,special,validity,id));
                    savedata();
                    Toast.makeText(this, id, Toast.LENGTH_SHORT).show();
//                    "Profile posted Successfully"
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private boolean isValidPostDetails() {
        if(ismanglik.isChecked()){
            manglik ="yes";
        }else{
            manglik ="No";
        }if(isdivorced.isChecked()){
            divorced = "Yes";
        }else{
            divorced = "No";
        }if (allowcall.isChecked()){
            alowcall = "Yes";
        }else{
            alowcall = "No";
        }if(iswidow.isChecked()){
            widow ="Yes";
        }else{
            widow = "no";
        }
        if(radioGenderMale.isChecked()){
            gender = "Male";
        }
        if(radioGenderFemale.isChecked()){
            gender = "Female";
        }
        if (encodedImage == null) {
            Toast.makeText(this, "Please Choose image", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(firstname.getText().toString().isEmpty()){
            firstname.setError("Please Enter First Name");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(lastname.getText().toString().isEmpty()){
            lastname.setError("Please Enter Last Name");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(dateofbirth.getText().toString().isEmpty()){
            dateofbirth.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(fathername.getText().toString().isEmpty()){
            fathername.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(mothername.getText().toString().isEmpty()){
            mothername.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(currentaddress.getText().toString().isEmpty()) {
            currentaddress.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(hometownadress.getText().toString().isEmpty()){
            hometownadress.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else if(description.getText().toString().isEmpty()){
            description.setError("Please Enter Date of Birth");
            progressBar.setVisibility(View.INVISIBLE);
            submit.setVisibility(View.VISIBLE);
            return false;
        }else{
            return true;
        }
    }
    private void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(postArrayList);
        editor.putString("posts", json);

        editor.apply();

    }private void loaddata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("posts", null);
        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();
        postArrayList = gson.fromJson(json, type);
        if (postArrayList == null) {
            postArrayList = new ArrayList<>();
        }
//        if(prefrenceManager.getString("activitytype").equals("payment")){
//            special = getIntent().getExtras().getString(Constants.KEY_SPECIAL);
//            validity = getIntent().getExtras().getString(Constants.KEY_VALIDITY);
//            payment = "done";
//        }
    }

    private void updateLabel(){
        String myFormat="dd/MM/yy";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        dateofbirth.setText(dateFormat.format(myCalendar.getTime()));
        prefrenceManager.putString(Constants.KEY_PROFILE_DATEOFBIRTH,dateFormat.format(myCalendar.getTime()));
        }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(),HomeActivity.class);
        startActivity(i);
        finish();
    }
}