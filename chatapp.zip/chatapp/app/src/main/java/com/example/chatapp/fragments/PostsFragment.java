package com.example.chatapp.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.adapters.AdvertisementAdapter;
import com.example.chatapp.adapters.FavoriteAdapter;
import com.example.chatapp.adapters.FavoriteAdsAdapter;
import com.example.chatapp.adapters.FavoritePostAdapter;
import com.example.chatapp.adapters.FavoriteSpecialPostAdapter;
import com.example.chatapp.adapters.ProfileAdapter;
import com.example.chatapp.adapters.SpecialProfileAdapter;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Advertisementfavorite;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class PostsFragment extends Fragment {

    TextView  profile,advertisement;
    private RecyclerView posts,posts2;
    ArrayList<Advertisement> advertisements = new ArrayList<>();
    ArrayList<SpecialProfile> specialprofiles = new ArrayList<>();
    ArrayList<Profile> profiles = new ArrayList<>();
    FirebaseFirestore database;
    PrefrenceManager prefrenceManager;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_posts, container, false);


        database = FirebaseFirestore.getInstance();
        prefrenceManager = new PrefrenceManager(getActivity());
        posts = view.findViewById(R.id.posts_recycler);
        posts2 = view.findViewById(R.id.posts_recycler2);
        profile = view.findViewById(R.id.profile_btn);
        advertisement = view.findViewById(R.id.ads_btn);

        profile.setBackgroundResource(R.drawable.gradient);
        advertisement.setBackgroundResource(R.drawable.edittext_border);
        getspecial();
        getprofiles();

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                profile.setBackgroundResource(R.drawable.gradient);
                advertisement.setBackgroundResource(R.drawable.edittext_border);
                advertisements.clear();
                posts2.setVisibility(View.VISIBLE);
                getspecial();
                getprofiles();
            }
        });
        advertisement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                advertisement.setBackgroundResource(R.drawable.gradient);
                profile.setBackgroundResource(R.drawable.edittext_border);
//                Toast.makeText(getActivity(),prefrenceManager.getString(Constants.KEY_USER_ID),Toast.LENGTH_LONG).show();
                posts2.setVisibility(View.GONE);
                specialprofiles.clear();
                profiles.clear();
                getadvertisements();
            }
        });

        return view;
    }

//    private void loaddata() {
//        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("shared preferences", MODE_PRIVATE);
//
//        Gson gson = new Gson();
//        String json = sharedPreferences.getString("posts", null);
//
//        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();
//
//        postArrayList = gson.fromJson(json, type);
//        if (postArrayList == null) {
//            postArrayList = new ArrayList<>();
//        }
//    }
    private void buildRecyclerView() {
//        adapter = new FavoriteAdapter(postArrayList, getActivity());
//        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
//        posts.setHasFixedSize(true);
//        posts.setLayoutManager(manager);
//        posts.setAdapter(adapter);

    }
    private void buildadsRecyclerView() {
//        adsAdapter = new FavoriteAdsAdapter(advertisementfavorites, getActivity());
//
//        // adding layout manager to our recycler view.
//        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
//        posts.setHasFixedSize(true);
//
//        // setting layout manager to our recycler view.
//        posts.setLayoutManager(manager);
//
//        // setting adapter to our recycler view.
//        posts.setAdapter(adsAdapter);
    }

//    private void loadadsdata() {
//        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("shared preferences", MODE_PRIVATE);
//
//        Gson gson = new Gson();
//        String json = sharedPreferences.getString("advertisements", null);
//
//        Type type = new TypeToken<ArrayList<Advertisementfavorite>>() {}.getType();
//
//        advertisementfavorites = gson.fromJson(json, type);
//        if (advertisementfavorites == null) {
//            advertisementfavorites = new ArrayList<>();
//        }
//    }
    private void getadvertisements() {

        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        for(QueryDocumentSnapshot queryDocumentSnapshot: task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            Advertisement advertisement = new Advertisement();
                            advertisement.id = queryDocumentSnapshot.getId();
                            advertisement.recieverid = queryDocumentSnapshot.getString(Constants.KEY_RECIEVER_ID);
                            advertisement.advertiseimage = queryDocumentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE);
                            advertisement.titlename = queryDocumentSnapshot.getString(Constants.KEY_TITLE_NAME);
                            advertisement.ownername = queryDocumentSnapshot.getString(Constants.KEY_OWNER_NAME);
                            advertisement.ownercontact = queryDocumentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                            advertisement.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            advertisement.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            advertisement.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            advertisement.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                           if(advertisement.recieverid.equals(prefrenceManager.getString(Constants.KEY_USER_ID))){
                               advertisements.add(advertisement);
                           }
                        }
                        if(0<=advertisements.size()){
                            FavoriteAdsAdapter favoriteAdsAdapter = new FavoriteAdsAdapter(advertisements,getContext());
                            posts.setAdapter(favoriteAdsAdapter);
                        }else{

                        }
                    }else{

                    }
                });
    }
    private void getspecial() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            if(specialprofile.profilerecieverid.equals(prefrenceManager.getString(Constants.KEY_USER_ID))){
                                specialprofiles.add(specialprofile);
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            FavoriteSpecialPostAdapter favoriteSpecialPostAdapter = new FavoriteSpecialPostAdapter(specialprofiles,getActivity());
                            posts.setAdapter(favoriteSpecialPostAdapter);
                        } else {

                        }
                    }
                    else {

                    }
                });
    }
    private void getprofiles() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            if(profile.profilerecieverid.equals(prefrenceManager.getString(Constants.KEY_USER_ID))){
                                profiles.add(profile);
                            }
                        }
                        if (profiles.size() > 0) {
                            FavoritePostAdapter favoritePostAdapter = new FavoritePostAdapter(profiles,getActivity());
                            posts2.setAdapter(favoritePostAdapter);
                        } else {

                        }
                    } else {

                    }
                });
    }
}
