package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.chatapp.R;
import com.example.chatapp.activities.AdvertisementdetailActivity;
import com.example.chatapp.databinding.ItemContainerPostAdvertisementBinding;
import com.example.chatapp.databinding.ItemContainerPostFavoriteAdvertisementBinding;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Advertisementfavorite;
import com.example.chatapp.utilities.Constants;
import com.makeramen.roundedimageview.RoundedImageView;
import com.skydoves.androidribbon.ShimmerRibbonView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FavoriteAdsAdapter  extends RecyclerView.Adapter<FavoriteAdsAdapter.AdvertisementViewHolder> {

    private  final ArrayList<Advertisement> advertisements;
    private Context context;

    public FavoriteAdsAdapter(ArrayList<Advertisement> advertisements, Context context) {
        this.advertisements = advertisements;
        this.context = context;
    }

    @NonNull
    @Override
    public FavoriteAdsAdapter.AdvertisementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         ItemContainerPostFavoriteAdvertisementBinding itemContainerPostFavoriteAdvertisementBinding = ItemContainerPostFavoriteAdvertisementBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false);
        return new FavoriteAdsAdapter.AdvertisementViewHolder(itemContainerPostFavoriteAdvertisementBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteAdsAdapter.AdvertisementViewHolder holder, int position) {
        holder.setAdvertisementdata(advertisements.get(position));
    }

    @Override
    public int getItemCount() {
        return advertisements.size();
    }

    public class AdvertisementViewHolder extends RecyclerView.ViewHolder {
        ItemContainerPostFavoriteAdvertisementBinding binding;

        AdvertisementViewHolder(ItemContainerPostFavoriteAdvertisementBinding itemContainerPostFavoriteAdvertisementBinding){
            super(itemContainerPostFavoriteAdvertisementBinding.getRoot());
            binding = itemContainerPostFavoriteAdvertisementBinding;
        }

        public void setAdvertisementdata(Advertisement advertisement) {
            binding.TitleName.setText(advertisement.titlename);
            binding.OwnerName.setText(advertisement.ownername);
            binding.OwnerContacts.setText(advertisement.ownercontact);
            binding.Description.setText(advertisement.description);
            binding.currentAddress.setText(advertisement.currentadress);
            binding.currentdatetime.setText(advertisement.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getAdvertisementImage(advertisement.advertiseimage));
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                String CurrentDate = sdf.format(new Date());
                String FinalDate = advertisement.currentDateandTime;
                Date date1;
                Date date2;
                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                date1 = dates.parse(CurrentDate);
                date2 = dates.parse(FinalDate);
                long difference = Math.abs(date1.getTime() - date2.getTime());
                long differenceDates = difference / (24 * 60 * 60 * 1000);
                long valid = Long.parseLong(advertisement.validity);
                if (differenceDates <= valid) {
                   binding.mactive.setText("Active");
                   binding.mactive.setBackgroundResource(R.drawable.gradient_green);
                }else{
                    binding.mactive.setText("Inactive");
                    binding.mactive.setBackgroundResource(R.drawable.gradient);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            binding.cardads.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context.getApplicationContext(), AdvertisementdetailActivity.class);
                    i.putExtra(Constants.KEY_ID,advertisement.id);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getAdvertisementImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}