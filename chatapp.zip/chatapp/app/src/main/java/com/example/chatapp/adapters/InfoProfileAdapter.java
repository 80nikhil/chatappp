package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;

import java.util.ArrayList;
import java.util.List;

public class InfoProfileAdapter  extends RecyclerView.Adapter<InfoProfileAdapter.AdvertisementViewHolder>{
    private List<Profile> profiles = new ArrayList<>();
    private Context context;

    public InfoProfileAdapter(List<Profile> profiles,Context context) {
        this.profiles = profiles;
        this.context = context;
    }

    @NonNull
    @Override
    public InfoProfileAdapter.AdvertisementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemContainerPostProfileBinding itemContainerPostProfileBinding = ItemContainerPostProfileBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false);
        return new InfoProfileAdapter.AdvertisementViewHolder(itemContainerPostProfileBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull InfoProfileAdapter.AdvertisementViewHolder holder, int position) {
        holder.setData(profiles.get(position));
    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    public class AdvertisementViewHolder extends RecyclerView.ViewHolder {
        ItemContainerPostProfileBinding binding;

        AdvertisementViewHolder(ItemContainerPostProfileBinding itemContainerPostProfileBinding){
            super(itemContainerPostProfileBinding.getRoot());
            binding = itemContainerPostProfileBinding;
        }

        public void setData(Profile profile) {
            binding.profilePostName.setText(profile.firstname+" "+profile.middlename+" "+profile.lastname);
            binding.profiledateofbirth.setText(profile.dateofbirth);
            binding.profilegender.setText(profile.gender);
            binding.profileheight.setText(profile.heightfeet+" "+profile.heightinch);
            if(profile.manglik.equals("yes")){
                binding.profilemanglik.setText("manglik");
            }else{
                binding.profilemanglik.setText("not-manglik");
            }
            binding.profilecurrenttimedate.setText(profile.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(profile.profileimage));
            binding.profilecast.setText(profile.cast);
            binding.profilecity.setText(profile.city);
            binding.profilestate.setText(profile.state);
            if(profile.special != null){
                binding.ribbon.setVisibility(View.VISIBLE);
            }
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context, FavoritePostDetailActivity.class);
                    i.putExtra(Constants.KEY_ID,profile.fcmtoken);
                    i.putExtra(Constants.KEY_SPECIAL,profile.special);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}
