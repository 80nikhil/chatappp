package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import com.example.chatapp.R;
import com.example.chatapp.adapters.AdvertiseAdapter;
import com.example.chatapp.adapters.AdvertisementAdapter;
import com.example.chatapp.databinding.ActivityAdvertisementBinding;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Category;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AdvertisementActivity extends AppCompatActivity {

    private PrefrenceManager prefrenceManager;
    Context context;
    ArrayList<Category> advertiseArrayList = new ArrayList<>();
    private ActivityAdvertisementBinding binding;
    ArrayList<Advertisement> advertisements = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdvertisementBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        context = this;
        getadvertisements();
        prefrenceManager = new PrefrenceManager(getApplicationContext());


        advertiseArrayList.add(new Category("Band Baja Dhol", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Bridal Mehandi", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Bridal Makeup", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Cook House", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("DJ Sound", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Doli on Hire", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Flower Decoration", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Generator", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Hotel", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Horse Baggi", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Light Decoration", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Marriage Garden", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Photographer", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Tent House", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Taxi Service", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category("Wedding Caterers", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category(" Wedding Card", R.drawable.ic_baseline_add_24));
        advertiseArrayList.add(new Category(" Other", R.drawable.ic_baseline_add_24));

        AdvertiseAdapter adapter = new AdvertiseAdapter(context,advertiseArrayList);
        binding.recycleradvertise.setAdapter(adapter);
        binding.recycleradvertise.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        binding.recycleradvertise.setHasFixedSize(true);
    }
// .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)

    private void getadvertisements() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        for(QueryDocumentSnapshot queryDocumentSnapshot: task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            Advertisement advertisement = new Advertisement();
                            advertisement.id = queryDocumentSnapshot.getId();
                            advertisement.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            advertisement.advertiseimage = queryDocumentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE);
                            advertisement.titlename = queryDocumentSnapshot.getString(Constants.KEY_TITLE_NAME);
                            advertisement.ownername = queryDocumentSnapshot.getString(Constants.KEY_OWNER_NAME);
                            advertisement.ownercontact = queryDocumentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                            advertisement.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            advertisement.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            advertisement.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = advertisement.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(advertisement.validity);
                                if (differenceDates <= valid) {
                                    advertisements.add(advertisement);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if(0<=advertisements.size()){
                            AdvertisementAdapter advertisementAdapter = new AdvertisementAdapter(advertisements,this);
                            binding.advertiserecycler.setAdapter(advertisementAdapter);
                            binding.advertiserecycler.setVisibility(View.VISIBLE);
                        }else{

                        }
                    }else{

                    }
                });
    }
}