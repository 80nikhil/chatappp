package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.chatapp.R;
import com.example.chatapp.adapters.AdvertisementAdapter;
import com.example.chatapp.adapters.InfoProfileAdapter;
import com.example.chatapp.adapters.InfoSpecialAdapter;
import com.example.chatapp.adapters.ProfileAdapter;
import com.example.chatapp.adapters.SpecialProfileAdapter;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.makeramen.roundedimageview.RoundedImageView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Chatprofileinfo extends AppCompatActivity {

    TextView name,city,state,contact,gender,email;
    String reciever;
    RoundedImageView imageview;
    ImageView backbtn;
    RecyclerView advertisement,special,post;
    FirebaseFirestore database;
    PrefrenceManager prefrenceManager;
    ArrayList<Advertisement> advertisements = new ArrayList<>();
    ArrayList<Profile> profiles = new ArrayList<>();
    ArrayList<SpecialProfile> specialprofiles = new ArrayList<>();
    Context context;
    String validity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatprofileinfo);

        database = FirebaseFirestore.getInstance();
        reciever = getIntent().getExtras().getString(Constants.KEY_RECIEVER_ID);
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        name = findViewById(R.id.namechat);
        city = findViewById(R.id.citychat);
        state = findViewById(R.id.Statechat);
        contact = findViewById(R.id.contactchat);
        gender = findViewById(R.id.genderchat);
        email = findViewById(R.id.emailchat);
        imageview = findViewById(R.id.img_register_chat);
        backbtn = findViewById(R.id.Backbtnchat);
        advertisement = findViewById(R.id.adsrecycler);
        special = findViewById(R.id.specialrecycler);
        post = findViewById(R.id.postrecycler);

        context = this;
        getData();
        getadvertisements();
        getprofiles();
        getspecial();
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });

    }


    private void getData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
            database.collection(Constants.KEY_COLLECTION_USERS)
                    .document(reciever)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            name.setText(documentSnapshot.getString(Constants.KEY_NAME));
                            email.setText(documentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME));
                            city.setText(documentSnapshot.getString(Constants.KEY_CITY));
                            state.setText(documentSnapshot.getString(Constants.KEY_STATE));
                            gender.setText(documentSnapshot.getString(Constants.KEY_GENDER));
                            contact.setText(documentSnapshot.getString(Constants.KEY_CONTACT_NO));
                            byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_IMAGE),Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                            imageview.setImageBitmap(bitmap);
                       }
           });
        }

    private void getspecial() {
        database.collection(Constants.KEY_POST_SPECIAL)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    if(specialprofile.profilerecieverid.equals(reciever)) {
                                        specialprofiles.add(specialprofile);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            InfoSpecialAdapter infoSpecialAdapter = new InfoSpecialAdapter(specialprofiles,this);
                            special.setAdapter(infoSpecialAdapter);
                        } else {

                        }
                    }
                    else {

                    }
                });
    }
    private void getprofiles() {
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = profile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(profile.validity);
                                if (differenceDates <= valid) {
                                    if(profile.profilerecieverid.equals(reciever)) {
                                        profiles.add(profile);
                                    }
                                  }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (profiles.size() > 0) {
                            InfoProfileAdapter infoProfileAdapter = new InfoProfileAdapter(profiles,this);
                            post.setAdapter(infoProfileAdapter);
                        } else {



                        }
                    } else {

                    }
                });
    }
    private void getadvertisements() {
        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Advertisement advertisement = new Advertisement();
                            advertisement.id = queryDocumentSnapshot.getId();
                            advertisement.recieverid = queryDocumentSnapshot.getString(Constants.KEY_RECIEVER_ID);
                            advertisement.advertiseimage = queryDocumentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE);
                            advertisement.titlename = queryDocumentSnapshot.getString(Constants.KEY_TITLE_NAME);
                            advertisement.ownername = queryDocumentSnapshot.getString(Constants.KEY_OWNER_NAME);
                            advertisement.ownercontact = queryDocumentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                            advertisement.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            advertisement.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            advertisement.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            advertisement.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = advertisement.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(advertisement.validity);
                                if (differenceDates <= valid) {
                                    if(advertisement.recieverid.equals(reciever)) {
                                        advertisements.add(advertisement);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (0 <= advertisements.size()) {
                            AdvertisementAdapter advertisementAdapter = new AdvertisementAdapter(advertisements, this);
                            advertisement.setAdapter(advertisementAdapter);
                        } else {

                        }
                    } else {

                    }
                });
        }
    }
