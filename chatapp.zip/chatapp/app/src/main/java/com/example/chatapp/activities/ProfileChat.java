package com.example.chatapp.activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.adapters.ChatAdapter;
import com.example.chatapp.databinding.ActivityProfileChatBinding;
import com.example.chatapp.models.ChatMessage;
import com.example.chatapp.network.ApiClient;
import com.example.chatapp.network.ApiService;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileChat extends AppCompatActivity {


    private ActivityProfileChatBinding binding;
    private List<ChatMessage> chatMessages;
    private ChatAdapter chatAdapter;
    private PrefrenceManager prefrenceManager;
    private FirebaseFirestore database;
    private String conversionId = null;
    private Boolean isRecieverAvailable = false;
    String recieverid, recieverimage, recievername, recieverfcmtoken,firstmessage,blockid,isblocked,isblockedbyreciever;
    private String encodedImage;
    String seenunseen;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        recieverid = getIntent().getExtras().getString(Constants.KEY_USER_ID);
        recieverimage = getIntent().getExtras().getString(Constants.KEY_IMAGE);
        recievername = getIntent().getExtras().getString(Constants.KEY_NAME);
        recieverfcmtoken = getIntent().getExtras().getString(Constants.KEY_FCM_TOKEN);
        firstmessage = getIntent().getExtras().getString(Constants.KEY_MESSAGE);

        loadRecieverDetails();
        init();
        listenMessages();
        checkblock();
        blockedbyreciever();


        binding.profileimagesend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isblockedbyreciever.equals("blocked")){
                    Toast.makeText(getApplicationContext(), "Blocked by Reciever", Toast.LENGTH_SHORT).show();
                }else if(isblocked.equals("blocked")) {
                    Toast.makeText(getApplicationContext(), isblocked, Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    pickImage.launch(intent);
                }
            }
        });

        binding.profileimageback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        binding.profileimageinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(ProfileChat.this,  binding.profileimageinfo);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch(menuItem.getItemId()) {
                            case R.id.block:
                                Toast.makeText(ProfileChat.this, menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                                return true;
                            case R.id.profile:
                                Toast.makeText(ProfileChat.this, menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),Chatprofileinfo.class);
                                intent.putExtra(Constants.KEY_RECIEVER_ID,recieverid);
                                startActivity(intent);
                                return true;
                        }
                        return false;
                    }
                });
                // Showing the popup menu
                popupMenu.show();
//
            }
        });

        binding.profilelayoutsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isblockedbyreciever.equals("blocked")){
                    Toast.makeText(getApplicationContext(), "Blocked by Reciever", Toast.LENGTH_SHORT).show();
                }else if(isblocked.equals("blocked")) {
                    Toast.makeText(getApplicationContext(), isblocked, Toast.LENGTH_SHORT).show();
                }else {
                    sendMessage();
                }
            }
        });
        binding.profileimagecall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isblockedbyreciever.equals("blocked")){
                    Toast.makeText(getApplicationContext(), "Blocked by Reciever", Toast.LENGTH_SHORT).show();
                }else if(isblocked.equals("blocked")) {
                    Toast.makeText(getApplicationContext(), isblocked, Toast.LENGTH_SHORT).show();
                }else {
                    getmobileno();
                }
            }
        });

    }

    private void getmobileno() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .document(recieverid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        String phone = documentSnapshot.getString(Constants.KEY_CONTACT_NO);
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        String temp = "tel:" + phone;
                        intent.setData(Uri.parse(temp));
                        startActivity(intent);
                    }
                });
    }

    private void init(){
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        chatMessages = new ArrayList<>();
        chatAdapter = new ChatAdapter(
                chatMessages,
                getBitmapFromEncodedString(recieverimage),
                prefrenceManager.getString(Constants.KEY_USER_ID)
        );
        binding.profilechatRecyclerView.setAdapter(chatAdapter);
        database = FirebaseFirestore.getInstance();
    }
    private void sendMessage(){
        HashMap<String, Object> message = new HashMap<>();
        message.put(Constants.KEY_SENDER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        message.put(Constants.KEY_RECIEVER_ID,recieverid);
        message.put(Constants.KEY_MESSAGE,binding.profileinputMessage.getText().toString());
        message.put(Constants.KEY_TYPE,"text");
        message.put(Constants.KEY_TIMESTAMP,new Date());
        database.collection(Constants.KEY_COLLECTION_CHAT).add(message);
        if(conversionId != null){
            updateConversion(binding.profileinputMessage.getText().toString());
        }else{
            HashMap<String , Object> conversion = new HashMap<>();
            conversion.put(Constants.KEY_SENDER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
            conversion.put(Constants.KEY_SENDER_NAME,prefrenceManager.getString(Constants.KEY_NAME));
            conversion.put(Constants.KEY_SENDER_IMAGE,prefrenceManager.getString(Constants.KEY_IMAGE));
            conversion.put(Constants.KEY_RECIEVER_ID,recieverid);
            conversion.put(Constants.KEY_RECIEVER_NAME,recievername);
            conversion.put(Constants.KEY_RECIEVER_IMAGE,recieverimage);
            conversion.put(Constants.KEY_TYPE,"text");
            if(isRecieverAvailable){
                conversion.put(Constants.KEY_UNSEEN,"seen");
            }else{
                conversion.put(Constants.KEY_UNSEEN,"unseen");
            }
            conversion.put(Constants.KEY_LAST_MESSAGE,binding.profileinputMessage.getText().toString());
            conversion.put(Constants.KEY_TIMESTAMP,new Date());
            addConversion(conversion);
        }if(!isRecieverAvailable){
            try{
                JSONArray tokens = new JSONArray();
                tokens.put(recieverfcmtoken);

                JSONObject data = new JSONObject();
                data.put(Constants.KEY_USER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
                data.put(Constants.KEY_NAME,prefrenceManager.getString(Constants.KEY_NAME));
                data.put(Constants.KEY_FCM_TOKEN,prefrenceManager.getString(Constants.KEY_FCM_TOKEN));
                data.put(Constants.KEY_MESSAGE,binding.profileinputMessage.getText().toString());
                JSONObject body = new JSONObject();
                body.put(Constants.REMOTE_MSG_DATA,data);
                body.put(Constants.REMOTE_MSG_REGISTRATION_IDS,tokens);

                sendNotification(body.toString());

            }catch (Exception exception){
                showToast(exception.getMessage());
            }
        }
        binding.profileinputMessage.setText(null);
    }
    public void showToast(String message){
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
    }

    private void sendNotification(String messageBody){
        ApiClient.getClient().create(ApiService.class).sendMessage(
                Constants.getRemoteMsgHeader(),
                messageBody
        ).enqueue(new Callback<String>() {
            @Override
            public void onResponse(@NonNull Call<String> call, Response<String> response) {
                if(response.isSuccessful()){
                    try {
                        if(response.body() != null){
                            JSONObject responseJson = new JSONObject(response.body());
                            JSONArray results = responseJson.getJSONArray("results");
                            if(responseJson.getInt("failure") == 1){
                                JSONObject error = (JSONObject) results.get(0);
                                showToast(error.getString("error"));
                                return;
                            }
                        }

                    }catch (JSONException e){
                        e.printStackTrace();
                    }
                }else{
                    showToast("Error : " + response.code());
                }
            }
            @Override
            public void onFailure(@NonNull Call<String> call, Throwable t) {
                showToast(t.getMessage());
            }
        });
    }
    private void listenSAvailibilityOfReciever(){
        database.collection(Constants.KEY_COLLECTION_USERS).document(
                recieverid
        ).addSnapshotListener(ProfileChat.this,(value,error) ->{
            if(error != null){
                return;
            }
            if(value != null){
                if(value.getLong(Constants.KEY_AVAILIBILITY) != null){
                    int availability = Objects.requireNonNull(
                            value.getLong(Constants.KEY_AVAILIBILITY)
                    ).intValue();
                    isRecieverAvailable = availability == 1;
                }
                recieverfcmtoken = value.getString(Constants.KEY_FCM_TOKEN);
                if(recieverimage != null){
                    recieverimage = value.getString(Constants.KEY_IMAGE);
                    chatAdapter.setRecieverProfileImage(getBitmapFromEncodedString(recieverimage));
                    chatAdapter.notifyItemRangeChanged(0,chatMessages.size());
                }
            }
            if(isRecieverAvailable){
                binding.profiletextAvailibility.setVisibility(View.VISIBLE);
            }else{
                binding.profiletextAvailibility.setVisibility(View.GONE);
            }
            recieverfcmtoken = value.getString(Constants.KEY_FCM_TOKEN);
        });

    }
    private void listenMessages(){
        database.collection(Constants.KEY_COLLECTION_CHAT)
                .whereEqualTo(Constants.KEY_SENDER_ID,prefrenceManager.getString(Constants.KEY_USER_ID))
                .whereEqualTo(Constants.KEY_RECIEVER_ID,recieverid)
                .addSnapshotListener(eventListener);
        database.collection(Constants.KEY_COLLECTION_CHAT)
                .whereEqualTo(Constants.KEY_SENDER_ID,recieverid)
                .whereEqualTo(Constants.KEY_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID))
                .addSnapshotListener(eventListener);
    }

    private final EventListener<QuerySnapshot> eventListener = (value,error) ->{
        if(error != null){
            return;
        }if(value != null){
            int count = chatMessages.size();
            for(DocumentChange documentChange : value.getDocumentChanges()){
                if(documentChange.getType() == DocumentChange.Type.ADDED) {
                    ChatMessage chatMessage = new ChatMessage();
                    chatMessage.senderId = documentChange.getDocument().getString(Constants.KEY_SENDER_ID);
                    chatMessage.recieverId = documentChange.getDocument().getString(Constants.KEY_RECIEVER_ID);
                    chatMessage.message = documentChange.getDocument().getString(Constants.KEY_MESSAGE);
                    chatMessage.type = documentChange.getDocument().getString(Constants.KEY_TYPE);
                    chatMessage.dateTime = getReadableDateTime(documentChange.getDocument().getDate(Constants.KEY_TIMESTAMP));
                    chatMessage.dateObject = documentChange.getDocument().getDate(Constants.KEY_TIMESTAMP);
                    chatMessages.add(chatMessage);
                }
            }
            Collections.sort(chatMessages,(obj1,obj2) -> obj1.dateObject.compareTo(obj2.dateObject));
            if(count == 0){
                chatAdapter.notifyDataSetChanged();
            }else {
                chatAdapter.notifyItemRangeChanged(chatMessages.size(),chatMessages.size());
                binding.profilechatRecyclerView.smoothScrollToPosition(chatMessages.size() - 1);
            }
            binding.profilechatRecyclerView.setVisibility(View.VISIBLE);
        }
        binding.profileprogressbar.setVisibility(View.GONE);
        if(conversionId == null){
            checkForConversion();
        }
    };
    private Bitmap getBitmapFromEncodedString(String encodedImage){
        if(encodedImage != null){
            byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
        }
        else{
            return null;
        }
    }

    private  void loadRecieverDetails(){
//        recieverUser = (User) getIntent().getSerializableExtra(Constants.KEY_USER);
        binding.profiletextName.setText(recievername);
//        binding.profileinputMessage.setText(firstmessage);
    }
    private String getReadableDateTime(Date date){
        return new SimpleDateFormat("MMMM dd,yyyy - hh:mm a", Locale.getDefault()).format(date);
    }
    private void addConversion(HashMap<String,Object> conversion){
        database.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
                .add(conversion)
                .addOnSuccessListener(documentReference -> conversionId = documentReference.getId());
    }
    private  void updateConversion(String message){
        if(isRecieverAvailable){
            seenunseen = "seen";
        }else{
            seenunseen = "unseen";
        }
        DocumentReference documentReference =
                database.collection(Constants.KEY_COLLECTION_CONVERSATIONS).document(conversionId);
        documentReference.update(
                Constants.KEY_LAST_MESSAGE,message,
                Constants.KEY_UNSEEN,seenunseen,
                Constants.KEY_TYPE,"text",
                Constants.KEY_TIMESTAMP,new Date()
        );
    }

    private void checkForConversion(){
        if(chatMessages.size() != 0){
            checkForconversationRemotely(
                    prefrenceManager.getString(Constants.KEY_USER_ID),
                    recieverid
            );
            checkForconversationRemotely(
                    recieverid,
                    prefrenceManager.getString(Constants.KEY_USER_ID)
            );
        }
    }

    private void checkForconversationRemotely(String senderId , String recieverId){
        database.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
                .whereEqualTo(Constants.KEY_SENDER_ID,senderId)
                .whereEqualTo(Constants.KEY_RECIEVER_ID,recieverId)
                .get()
                .addOnCompleteListener(coversionCompleteListener);
    }

    private final OnCompleteListener<QuerySnapshot> coversionCompleteListener = task ->{
        if(task.isSuccessful() && task.getResult() != null &&task.getResult().getDocuments().size() > 0){
            DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
            conversionId = documentSnapshot.getId();
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        listenSAvailibilityOfReciever();
    }
    private String encodeImage(Bitmap bitmap){
//        int previewWidth = 150;
//        int previewHeight = bitmap.getHeight()*previewWidth/bitmap.getWidth();
        int nh = (int) ( bitmap.getHeight() * (512.0 / bitmap.getWidth()) );
//        Bitmap scaled = Bitmap.createScaledBitmap(bitmapImage, 512, nh, true);
//        int previewWidth = (bitmap.getWidth()/100)*70;
//        int previewHeight = (bitmap.getHeight()/100)*70;
//        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,false);
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,512,nh,false);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }
    private final ActivityResultLauncher<Intent> pickImage = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK){
                    if(result.getData() != null){
                        Uri imageurl = result.getData().getData();
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(imageurl);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            encodedImage = encodeImage(bitmap);
                            sendImage();
                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
            }
    );

    private void sendImage() {
        HashMap<String, Object> message = new HashMap<>();
        message.put(Constants.KEY_SENDER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        message.put(Constants.KEY_RECIEVER_ID,recieverid);
        message.put(Constants.KEY_MESSAGE,encodedImage);
        message.put(Constants.KEY_TYPE,"image");
        message.put(Constants.KEY_TIMESTAMP,new Date());
        database.collection(Constants.KEY_COLLECTION_CHAT).add(message);
        if(conversionId != null){
            updateConversionimage(encodedImage);
        }else{
            HashMap<String , Object> conversion = new HashMap<>();
            conversion.put(Constants.KEY_SENDER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
            conversion.put(Constants.KEY_SENDER_NAME,prefrenceManager.getString(Constants.KEY_NAME));
            conversion.put(Constants.KEY_SENDER_IMAGE,prefrenceManager.getString(Constants.KEY_IMAGE));
            conversion.put(Constants.KEY_RECIEVER_ID,recieverid);
            conversion.put(Constants.KEY_RECIEVER_NAME,recievername);
            conversion.put(Constants.KEY_RECIEVER_IMAGE,recieverimage);
            conversion.put(Constants.KEY_TYPE,"image");
//            if(isRecieverAvailable){
//                conversion.put(Constants.KEY_UNSEEN,"seen");
//            }else{
            conversion.put(Constants.KEY_UNSEEN,"unseen");
//            }
            conversion.put(Constants.KEY_LAST_MESSAGE,encodedImage);
            conversion.put(Constants.KEY_TIMESTAMP,new Date());
            addConversion(conversion);
        }
    }
    private  void updateConversionimage(String encodedImage) {
        if(isRecieverAvailable){
            seenunseen = "seen";
        }else{
            seenunseen = "unseen";
        }
        DocumentReference documentReference =
                database.collection(Constants.KEY_COLLECTION_CONVERSATIONS).document(conversionId);
        documentReference.update(
                Constants.KEY_LAST_MESSAGE, encodedImage,
                Constants.KEY_UNSEEN,seenunseen,
                Constants.KEY_TYPE,"image",
                Constants.KEY_TIMESTAMP, new Date()
        );
    }
    public  void checkblock(){
    FirebaseFirestore database = FirebaseFirestore.getInstance();
    database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
            .whereEqualTo(Constants.KEY_BLOCKED_BY,prefrenceManager.getString(Constants.KEY_USER_ID))
            .whereEqualTo(Constants.KEY_BLOCKED_USER,recieverid)
            .get()
            .addOnCompleteListener(task -> {
                if(task.isSuccessful() && task.getResult() != null &&
                        task.getResult().getDocuments().size() >0){
                    DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                    blockid = documentSnapshot.getId();
                    if(documentSnapshot.getString(Constants.KEY_STATUS).equals("1")) {
                        isblocked = "blocked";
//                        Toast.makeText(getApplicationContext(), blockid, Toast.LENGTH_SHORT).show();
                    }
                    else{
                        isblocked = "unblocked";
//                        Toast.makeText(getApplicationContext(),blockid,Toast.LENGTH_SHORT).show();
                    }
                }else{
                    isblocked = "unblocked";
//                    Toast.makeText(getApplicationContext(),blockid,Toast.LENGTH_SHORT).show();
                }
            });
}
    private void blockedbyreciever() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
                .whereEqualTo(Constants.KEY_BLOCKED_BY,recieverid)
                .whereEqualTo(Constants.KEY_BLOCKED_USER,prefrenceManager.getString(Constants.KEY_USER_ID))
                .get()
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful() && task.getResult() != null &&
                            task.getResult().getDocuments().size() >0){
                        DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                        if(documentSnapshot.getString(Constants.KEY_STATUS).equals("1")) {
                            isblockedbyreciever = "blocked";
//                            Toast.makeText(getApplicationContext(), "Blocked by Reciever", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            isblockedbyreciever = "unblocked";
                        }
                    }else{
                        isblockedbyreciever = "unblocked";
//                        Toast.makeText(getApplicationContext(),isblocked,Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void blockuser() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
                .whereEqualTo(Constants.KEY_BLOCKED_BY,prefrenceManager.getString(Constants.KEY_USER_ID))
                .whereEqualTo(Constants.KEY_BLOCKED_USER,recieverid)
                .get()
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful() && task.getResult() != null &&
                            task.getResult().getDocuments().size() >0){
                        DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                        if(documentSnapshot.getString(Constants.KEY_STATUS).equals("1")) {
                            DocumentReference documentReference = database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
                                    .document(blockid);
                            documentReference.update(Constants.KEY_STATUS,"0");
                            isblocked = "unblocked";
                            blockedbyreciever();
//                            Toast.makeText(getApplicationContext(), "Unblocked", Toast.LENGTH_SHORT).show();
                        }
                        if(documentSnapshot.getString(Constants.KEY_STATUS).equals("0")){
                            DocumentReference documentReference = database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
                                    .document(blockid);
                            documentReference.update(Constants.KEY_STATUS,"1");
                            isblocked = "blocked";
                            blockedbyreciever();
//                            Toast.makeText(getApplicationContext(), "blocked", Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        HashMap<String,Object> user = new HashMap<>();
                        user.put(Constants.KEY_BLOCKED_BY,prefrenceManager.getString(Constants.KEY_USER_ID));
                        user.put(Constants.KEY_BLOCKED_USER,recieverid);
                        user.put(Constants.KEY_STATUS,"1");
                        database.collection(Constants.KEY_COLLECTION_BLOCKED_USERS)
                                .add(user)
                                .addOnSuccessListener(documentReference -> {
                                    isblocked = "blocked";
                                    blockedbyreciever();
//                                    Toast.makeText(this,"Blocked",Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(exception -> {
//                                    Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    }

                });

        }
    }