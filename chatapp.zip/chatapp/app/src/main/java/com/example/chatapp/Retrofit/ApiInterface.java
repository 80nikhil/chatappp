package com.example.chatapp.Retrofit;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiInterface {
    @POST("flow")
    Call<Retroresponse> OTPApi(@Body MultipartBody file);
}
