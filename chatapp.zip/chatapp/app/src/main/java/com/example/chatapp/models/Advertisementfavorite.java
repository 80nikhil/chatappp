package com.example.chatapp.models;

public class Advertisementfavorite {
    public String advertiseimage,titlename,ownername,ownercontact,currentadress
            ,description,currentDateandTime,validity;

    public Advertisementfavorite(String advertiseimage, String titlename, String ownername,
                                 String ownercontact, String currentadress, String description,
                                 String currentDateandTime, String validity) {
        this.advertiseimage = advertiseimage;
        this.titlename = titlename;
        this.ownername = ownername;
        this.ownercontact = ownercontact;
        this.currentadress = currentadress;
        this.description = description;
        this.currentDateandTime = currentDateandTime;
        this.validity = validity;
    }

    public String getAdvertiseimage() {
        return advertiseimage;
    }

    public void setAdvertiseimage(String advertiseimage) {
        this.advertiseimage = advertiseimage;
    }

    public String getTitlename() {
        return titlename;
    }

    public void setTitlename(String titlename) {
        this.titlename = titlename;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public String getOwnercontact() {
        return ownercontact;
    }

    public void setOwnercontact(String ownercontact) {
        this.ownercontact = ownercontact;
    }

    public String getCurrentadress() {
        return currentadress;
    }

    public void setCurrentadress(String currentadress) {
        this.currentadress = currentadress;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrentDateandTime() {
        return currentDateandTime;
    }

    public void setCurrentDateandTime(String currentDateandTime) {
        this.currentDateandTime = currentDateandTime;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }
}
