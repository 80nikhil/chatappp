package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.Retrofit.ApiClient;
import com.example.chatapp.Retrofit.Retroresponse;
import com.example.chatapp.utilities.Constants;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Random;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPassword extends AppCompatActivity {

    EditText email,otp;
    TextView resend;
    Button verify,sendotp;
    FirebaseFirestore database;
    private DocumentReference documentReference;
    String mactivity,otp2;
    ProgressBar progress_bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mactivity = getIntent().getExtras().getString(Constants.KEY_ACTIVITY);
        database = FirebaseFirestore.getInstance();
        email = findViewById(R.id.edt_email);
        otp = findViewById(R.id.edt_otp);
        verify = findViewById(R.id.btn_login);
        sendotp = findViewById(R.id.send_otp);
        resend = findViewById(R.id.resend);
        progress_bar = findViewById(R.id.progress_bar);
        Random r = new Random();
         otp2 = String.format("%04d", r.nextInt(1001));

         resend.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 progress_bar.setVisibility(View.VISIBLE);
                 if (email.getText().toString().isEmpty()) {
                     Toast.makeText(getApplicationContext(), "Mobile no. is empty", Toast.LENGTH_SHORT).show();
                 } else {
                     getotp();
                 }
             }
         });

        sendotp.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              progress_bar.setVisibility(View.VISIBLE);
              if (email.getText().toString().isEmpty()) {
                  progress_bar.setVisibility(View.GONE);
                  Toast.makeText(getApplicationContext(), "Mobile no. is empty", Toast.LENGTH_SHORT).show();
              } else {
//                  MultipartBody.Builder builder = new MultipartBody.Builder();
//                  builder.setType(MultipartBody.FORM);
//                  builder.addFormDataPart("flow_id", "61de6gf17d56c40a5616c3b9");
//                  builder.addFormDataPart("sender", "KUSSVH");
//                  builder.addFormDataPart("mobiles", "+91" + email.getText().toString());
//                  builder.addFormDataPart("otp", "9435");
//                  builder.addFormDataPart("time", "12");
//                  MultipartBody requestBody = builder.build();
//                  ApiClient.getAPIService().OTPApi(requestBody).enqueue(new Callback<Retroresponse>() {
//                      @Override
//                      public void onResponse(Call<Retroresponse> call, Response<Retroresponse> response) {
//                          try {
//                              if (response.code() == 200) {
//                                  progress_bar.setVisibility(View.GONE);
//                                  otp.setText(otp2);
//                                  Toast.makeText(getApplicationContext(), "mobile no verified sucessfully", Toast.LENGTH_SHORT).show();
//                              } else if (response.code() == 401) {
//                                  progress_bar.setVisibility(View.GONE);
//                                  Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
//                              } else if (response.code() == 400) {
//                                  progress_bar.setVisibility(View.GONE);
//                                  Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
//                              }
//                          } catch (Exception e) {
//                              e.printStackTrace();
//                          }
//                      }
//
//                      @Override
//                      public void onFailure(Call<Retroresponse> call, Throwable t) {
//                          Log.e("TAG", "On Failure:==>");
//                          t.printStackTrace();
//                      }
//                  });
                  getotp();
              }
          }
      });
        verify.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        progress_bar.setVisibility(View.VISIBLE);
                        if(otp.getText().toString().equals(otp2)){
                            if(mactivity.equals("register")){
                                progress_bar.setVisibility(View.GONE);
                                Intent i = new Intent(getApplicationContext(),Signupactivity.class);
                                startActivity(i);
                            }else if(mactivity.equals("forget")){
                                progress_bar.setVisibility(View.GONE);
                                Intent i = new Intent(getApplicationContext(),Passwordchange.class);
                                i.putExtra(Constants.KEY_CONTACT_NO,email.getText().toString());
                                startActivity(i);
                            }
                        }
                    }
        });
    }
    public void getotp(){
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);
        builder.addFormDataPart("flow_id", "61de6gf17d56c40a5616c3b9");
        builder.addFormDataPart("sender", "KUSSVH");
        builder.addFormDataPart("mobiles", "+91" + email.getText().toString());
        builder.addFormDataPart("otp", otp2);
        builder.addFormDataPart("time", "12");
        MultipartBody requestBody = builder.build();
        ApiClient.getAPIService().OTPApi(requestBody).enqueue(new Callback<Retroresponse>() {
            @Override
            public void onResponse(Call<Retroresponse> call, Response<Retroresponse> response) {
                try {
                    if (response.code() == 200) {
                        progress_bar.setVisibility(View.GONE);
                        otp.setText(otp2);
                        Toast.makeText(getApplicationContext(), "mobile no verified sucessfully", Toast.LENGTH_SHORT).show();
                    } else if (response.code() == 401) {
                        progress_bar.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                    } else if (response.code() == 400) {
                        progress_bar.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Retroresponse> call, Throwable t) {
                Log.e("TAG", "On Failure:==>");
                t.printStackTrace();
            }
        });
    }
}