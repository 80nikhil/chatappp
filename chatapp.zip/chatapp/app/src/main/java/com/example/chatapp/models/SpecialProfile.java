package com.example.chatapp.models;

import java.io.Serializable;

public class SpecialProfile implements Serializable {
    public String firstname, middlename, lastname, profileimage, dateofbirth, gender, fathername, mothername,
            currentadress, hometownaddress, currentDateandTime, description, manglik, divorced, allowcall, iswidow, brothers, sisters,
            monthlyincome, occupation, education, cast, weight, heightinch, heightfeet, motheroccupation,
            fatheroccupation, contactno, profilerecieverid, fcmtoken, city, state, validity, special;
}
