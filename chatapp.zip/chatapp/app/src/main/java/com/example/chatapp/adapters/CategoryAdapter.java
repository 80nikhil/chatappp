package com.example.chatapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.activities.AdvertisementActivity;
import com.example.chatapp.activities.BoyActivity;
import com.example.chatapp.activities.DivorcedActivity;
import com.example.chatapp.activities.GirlActivity;
import com.example.chatapp.activities.WidowActivity;
import com.example.chatapp.models.Category;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder>{

    ArrayList<Category> list;
   Context context;

    public CategoryAdapter(Context context, ArrayList<Category> list){
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View contactView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_category, parent, false);


//        ViewHolder viewHolder = new ViewHolder(contactView);
        CategoryAdapter.ViewHolder viewHolder = new CategoryAdapter.ViewHolder(contactView);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Category currentItem = list.get(position);

        ImageView imageView = holder.subjectImageView;
        imageView.setImageResource(currentItem.getImageId());

        TextView subjectTextView = holder.subjectTextView;
        subjectTextView.setText(currentItem.getSubject());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentItem.getSubject() == "Boy") {
                    Intent intent = new Intent(context, BoyActivity.class);
                    context.startActivity(intent);
                }else if(currentItem.getSubject() == "Girl") {
                    Intent intent = new Intent(context, GirlActivity.class);
                    context.startActivity(intent);
                }else if(currentItem.getSubject() == "Widow") {
                    Intent intent = new Intent(context, WidowActivity.class);
                    context.startActivity(intent);
                }else if(currentItem.getSubject() == "Divorced") {
                    Intent intent = new Intent(context, DivorcedActivity.class);
                    context.startActivity(intent);
                }else if(currentItem.getSubject() == "Advertisement") {
                    Intent intent = new Intent(context, AdvertisementActivity.class);
                    context.startActivity(intent);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView subjectImageView;
        public TextView subjectTextView;
        LinearLayout linearLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            subjectImageView = itemView.findViewById(R.id.imageCategoryIcon);
            subjectTextView = itemView.findViewById(R.id.textName);
            linearLayout = itemView.findViewById(R.id.linear_category);
        }
    }
}