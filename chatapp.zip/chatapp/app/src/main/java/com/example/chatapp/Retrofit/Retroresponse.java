package com.example.chatapp.Retrofit;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Retroresponse {
    @SerializedName("flow_id")
    @Expose
    private String flowId;
    @SerializedName("sender")
    @Expose
    private String sender;
    @SerializedName("mobiles")
    @Expose
    private String mobiles;
    @SerializedName("otp")
    @Expose
    private String otp;
    @SerializedName("time")
    @Expose
    private String time;

    public String getFlowId() {
        return flowId;
    }

    public void setFlowId(String flowId) {
        this.flowId = flowId;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getMobiles() {
        return mobiles;
    }

    public void setMobiles(String mobiles) {
        this.mobiles = mobiles;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
