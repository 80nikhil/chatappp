package com.example.chatapp.models;

import java.security.PublicKey;
import java.util.Date;

public class ChatMessage {
    public String senderId,recieverId,message,dateTime,image,mobile,type,unseen,id,currentid;
    public Date dateObject;
    public String conversionId,conversionName,conversionImage;
    public Long availibility;
}
