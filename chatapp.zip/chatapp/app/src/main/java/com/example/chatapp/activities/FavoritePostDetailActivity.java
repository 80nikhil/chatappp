package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jsibbold.zoomage.ZoomageView;
import com.makeramen.roundedimageview.RoundedImageView;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class FavoritePostDetailActivity extends AppCompatActivity {

    ImageView Backbtn,sharebtn,favourite;
    ZoomageView postimage;
    RoundedImageView recieverimage;
    Button startcall1,startcall2,fav1,fav2;
    TextView textname,dateofbirth,gender,cast,manglik,address,
            fullname,dob,city,ismanglik,height,weight,religion,
            education,occupation,monthlyincome,fatheroccupation,fathername,height2,
            mothername,motheroccupation,sister,brother,widodivo,description,textdatetime,contactno,textrecievername;
    String id,recieverid,chatrecieverimage,chatrecivername,chattoken,special,no,favencoded,validity;
    RelativeLayout rluser;
    private  ArrayList<FavouriteModal> courseModalArrayList;
    PrefrenceManager prefrenceManager;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite_post_detail);

        prefrenceManager = new PrefrenceManager(getApplicationContext());
        progressBar = findViewById(R.id.progress);
        postimage = findViewById(R.id.postimage2);
        textname = findViewById(R.id.textname2);
        dateofbirth = findViewById(R.id.dateofbirth2);
        gender = findViewById(R.id.gender2);
        cast = findViewById(R.id.cast2);
        manglik = findViewById(R.id.manglik2);
        address = findViewById(R.id.address2);
        fullname = findViewById(R.id.fullname2);
        dob = findViewById(R.id.dob2);
        city = findViewById(R.id.city2);
        ismanglik = findViewById(R.id.ismanglik2);
        height = findViewById(R.id.height2);
        height2 = findViewById(R.id.hgt2);
        weight = findViewById(R.id.weight2);
        religion = findViewById(R.id.religion2);
        education = findViewById(R.id.education2);
        occupation = findViewById(R.id.occupation2);
        monthlyincome = findViewById(R.id.monthlyincome2);
        fatheroccupation = findViewById(R.id.fatheroccupation2);
        fathername = findViewById(R.id.fathername2);
        mothername = findViewById(R.id.mothername2);
        motheroccupation = findViewById(R.id.motheroccupation2);
        sister = findViewById(R.id.sister2);
        brother = findViewById(R.id.brother2);
        widodivo = findViewById(R.id.widowdivo2);
        description = findViewById(R.id.description2);
        textdatetime = findViewById(R.id.textDateTime2);
        startcall1 = findViewById(R.id.btn_call2);
        startcall2 = findViewById(R.id.btn_call22);
        sharebtn = findViewById(R.id.btn_share);
        contactno = findViewById(R.id.contactno2);
        recieverimage = findViewById(R.id.profile_post_image2);
        textrecievername = findViewById(R.id.profile_post_name2);
        favourite = findViewById(R.id.fevBtn);
        fav1 = findViewById(R.id.btn_markFev12);
        fav2 = findViewById(R.id.btn_markFev2);
        rluser = findViewById(R.id.rluser);
        id = getIntent().getExtras().getString(Constants.KEY_ID);
        special = getIntent().getExtras().getString(Constants.KEY_SPECIAL);

        progressBar.setVisibility(View.VISIBLE);
        if(special != null){
            getspecialprofileData();
        }else {
            getprofileData();
        }
        loaddata();
        favourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addfavorite();
            }
        });
        fav1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addfavorite();
            }
        });
        fav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addfavorite();            }
        });
        startcall1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(special !=null) {
                    if (special.equals("special")) {
                        Intent i = new Intent(FavoritePostDetailActivity.this, ProfileChat.class);
                        i.putExtra(Constants.KEY_USER_ID, recieverid);
                        i.putExtra(Constants.KEY_IMAGE, chatrecieverimage);
                        i.putExtra(Constants.KEY_NAME, chatrecivername);
                        i.putExtra(Constants.KEY_FCM_TOKEN, chattoken);
                        i.putExtra(Constants.KEY_MESSAGE, "I want to chat for");
                        startActivity(i);
                    }
                }else {
                    Intent i = new Intent(FavoritePostDetailActivity.this, ProfileChat.class);
                    i.putExtra(Constants.KEY_USER_ID, recieverid);
                    i.putExtra(Constants.KEY_IMAGE, chatrecieverimage);
                    i.putExtra(Constants.KEY_NAME, chatrecivername);
                    i.putExtra(Constants.KEY_FCM_TOKEN, chattoken);
                    i.putExtra(Constants.KEY_MESSAGE, "I want to chat for");
                    startActivity(i);
                }
            }
        });
        startcall2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(no==null){
                    Toast.makeText(getApplicationContext(),"Call is Not Allowed",Toast.LENGTH_LONG).show();
                }else{
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    String temp = "tel:" + no;
                    intent.setData(Uri.parse(temp));
                    startActivity(intent);
                }
            }
        });
        rluser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Chatprofileinfo.class);
                i.putExtra(Constants.KEY_RECIEVER_ID,recieverid);
                startActivity(i);
            }
        });
    }

    private void getspecialprofileData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        textname.setText(documentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME) + documentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME) + documentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME));
                        dateofbirth.setText(documentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH));
                        gender.setText(documentSnapshot.getString(Constants.KEY_GENDER));
                        cast.setText(documentSnapshot.getString(Constants.KEY_CAST));
                        manglik.setText(documentSnapshot.getString(Constants.KEY_IS_MANGLIK));
                        address.setText(documentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS));
                        fullname.setText(documentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME) + documentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME) + documentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME));
                        dob.setText(documentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH));
                        city.setText(documentSnapshot.getString(Constants.KEY_CITY));
                        if(documentSnapshot.getString(Constants.KEY_IS_MANGLIK).equals("yes")){
                            ismanglik.setText("manglik");
                        }else{
                            ismanglik.setText("not-manglik");
                        }
                        ismanglik.setText(documentSnapshot.getString(Constants.KEY_IS_MANGLIK));
                        height.setText(documentSnapshot.getString(Constants.KEY_HEIGHT_FEET) + documentSnapshot.getString(Constants.KEY_HEIGHT_INCHES));
                        height2.setText(documentSnapshot.getString(Constants.KEY_HEIGHT_FEET) + documentSnapshot.getString(Constants.KEY_HEIGHT_INCHES));
                        weight.setText(documentSnapshot.getString(Constants.KEY_WEIGHT));
                        religion.setText(documentSnapshot.getString(Constants.KEY_CAST));
                        education.setText(documentSnapshot.getString(Constants.KEY_SELECT_EDUCATION));
                        occupation.setText(documentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION));
                        monthlyincome.setText(documentSnapshot.getString(Constants.KEY_MONTHLY_INCOME));
                        fatheroccupation.setText(documentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION));
                        fathername.setText(documentSnapshot.getString(Constants.KEY_FATHER_NAME));
                        mothername.setText(documentSnapshot.getString(Constants.KEY_MOTHER_NAME));
                        motheroccupation.setText(documentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION));
                        sister.setText(documentSnapshot.getString(Constants.KEY_SELECT_SISTER));
                        brother.setText(documentSnapshot.getString(Constants.KEY_SELECT_BROTHER));
                        widodivo.setText(documentSnapshot.getString(Constants.KEY_IS_WIDOW));
                        description.setText(documentSnapshot.getString(Constants.KEY_DESCRIPTION));
                        textdatetime.setText(documentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME));
                        contactno.setText(documentSnapshot.getString(Constants.KEY_CONTACT_NO));
                        textrecievername.setText(documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_NAME));
                        favencoded = documentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                        validity = documentSnapshot.getString(Constants.KEY_VALIDITY);
                        byte[] bytes = Base64.decode(favencoded, Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                        recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                        no = documentSnapshot.getString(Constants.KEY_CONTACT_NO);
                        getData();
                    }
                });
    }

    private void getprofileData() {
            FirebaseFirestore database = FirebaseFirestore.getInstance();
            database.collection(Constants.KEY_POST_PROFILE)
                    .document(id)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            textname.setText(documentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME)+documentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME)+documentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME));
                            dateofbirth.setText(documentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH));
                            gender.setText(documentSnapshot.getString(Constants.KEY_GENDER));
                            cast.setText(documentSnapshot.getString(Constants.KEY_CAST));
                            manglik.setText(documentSnapshot.getString(Constants.KEY_IS_MANGLIK));
                            address.setText(documentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS));
                            fullname.setText(documentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME)+documentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME)+documentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME));
                            dob.setText(documentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH));
                            city.setText(documentSnapshot.getString(Constants.KEY_CITY));
                            if(documentSnapshot.getString(Constants.KEY_IS_MANGLIK).equals("yes")){
                                ismanglik.setText("manglik");
                            }else{
                                ismanglik.setText("not-manglik");
                            }
//                            ismanglik.setText(documentSnapshot.getString(Constants.KEY_IS_MANGLIK));
                            height.setText(documentSnapshot.getString(Constants.KEY_HEIGHT_FEET)+documentSnapshot.getString(Constants.KEY_HEIGHT_INCHES));
                            height2.setText(documentSnapshot.getString(Constants.KEY_HEIGHT_FEET)+documentSnapshot.getString(Constants.KEY_HEIGHT_INCHES));
                            weight.setText(documentSnapshot.getString(Constants.KEY_WEIGHT));
                            religion.setText(documentSnapshot.getString(Constants.KEY_CAST));
                            education.setText(documentSnapshot.getString(Constants.KEY_SELECT_EDUCATION));
                            occupation.setText(documentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION));
                            monthlyincome.setText(documentSnapshot.getString(Constants.KEY_MONTHLY_INCOME));
                            fatheroccupation.setText(documentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION));
                            fathername.setText(documentSnapshot.getString(Constants.KEY_FATHER_NAME));
                            mothername.setText(documentSnapshot.getString(Constants.KEY_MOTHER_NAME));
                            motheroccupation.setText(documentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION));
                            sister.setText(documentSnapshot.getString(Constants.KEY_SELECT_SISTER));
                            brother.setText(documentSnapshot.getString(Constants.KEY_SELECT_BROTHER));
                            widodivo.setText(documentSnapshot.getString(Constants.KEY_IS_WIDOW));
                            description.setText(documentSnapshot.getString(Constants.KEY_DESCRIPTION));
                            textdatetime.setText(documentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME));
                            contactno.setText(documentSnapshot.getString(Constants.KEY_CONTACT_NO));
                            textrecievername.setText(documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_NAME));
                            favencoded = documentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            validity = documentSnapshot.getString(Constants.KEY_VALIDITY);
                            byte[] bytes = Base64.decode(favencoded,Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                            postimage.setImageBitmap(bitmap);
                            recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            no = documentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            getData();
                        }
                    });

    }
    private void getData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .document( recieverid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        chatrecieverimage = documentSnapshot.getString(Constants.KEY_IMAGE);
                        chatrecivername = documentSnapshot.getString(Constants.KEY_NAME);
                        textrecievername.setText(chatrecivername);
                        byte[] bytes = Base64.decode(chatrecieverimage,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        recieverimage.setImageBitmap(bitmap);
                        chattoken = documentSnapshot.getString(Constants.KEY_FCM_TOKEN);
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }
    private void loaddata() {
        if(prefrenceManager.getString(id) != null) {
            favourite.setImageResource(R.drawable.ic_baseline_favorite_24);
        }
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();

        String json = sharedPreferences.getString("courses", null);
        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();

        courseModalArrayList = gson.fromJson(json, type);
        if (courseModalArrayList == null) {
            courseModalArrayList = new ArrayList<>();
        }
    }
    private void addfavorite() {
        if(prefrenceManager.getString(id) == null) {
            favourite.setImageResource(R.drawable.ic_baseline_favorite_24);
            courseModalArrayList.add(new FavouriteModal(textname.getText().toString(), dateofbirth.getText().toString(),
                    education.getText().toString(), sister.getText().toString(), brother.getText().toString(),
                    cast.getText().toString(), textdatetime.getText().toString(), address.getText().toString(), favencoded, special, validity, id));
            prefrenceManager.putString(id,"favourite");
            saveData();
        }else{
            Toast.makeText(FavoritePostDetailActivity.this, "Already addded in Favorite.", Toast.LENGTH_SHORT).show();
        }
    }
    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(courseModalArrayList);
        editor.putString("courses", json);
        editor.apply();
        Toast.makeText(this, "Added to favorite", Toast.LENGTH_SHORT).show();

    }
}