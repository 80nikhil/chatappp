package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.activities.AdvertisementdetailActivity;
import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostAdvertisementBinding;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.listeners.ProfileListener;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Profile;
import com.example.chatapp.utilities.Constants;

import java.util.ArrayList;
import java.util.List;

public class ProfileAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    final int VIEW_TYPE_POST = 0;
    final int VIEW_TYPE_ADVERTISEMENT = 1;
    List<Profile> profiles;
    List<Advertisement> advertisements;
    public final ProfileListener profileListener;
   List<Profile> exampleListFull;
   Context context;

    public ProfileAdapter(List<Profile> profiles, List<Advertisement> advertisements, ProfileListener profileListener,Context context) {
        this.profiles = profiles;
        this.advertisements = advertisements;
        this.profileListener = profileListener;
        this.context = context;
    }

    public void setFilteredList(List<Profile> filteredList){
        this.profiles = filteredList;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_POST) {
            return new ProfileAdapter.MessageViewHolder(
                    ItemContainerPostProfileBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        }
        if (viewType == VIEW_TYPE_ADVERTISEMENT) {
            return new ProfileAdapter.ImageViewHolder(
                    ItemContainerPostAdvertisementBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        }

        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        try {
            if (getItemViewType(position) == VIEW_TYPE_POST) {
                ((ProfileAdapter.MessageViewHolder) holder).setData(profiles.get(position - ((position / 5)+1)));
            } else if (getItemViewType(position) == VIEW_TYPE_ADVERTISEMENT) {
                ((ProfileAdapter.ImageViewHolder) holder).setData(advertisements.get(position / 5));
            }
        } catch (Exception e) {

        }
    }

    @Override
    public int getItemCount() {
        return profiles.size() + advertisements.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (profiles.isEmpty() == false) {
            if (position % 5 != 0) {
                return VIEW_TYPE_POST;
            }
        } else {
            return VIEW_TYPE_ADVERTISEMENT;
        }
        return VIEW_TYPE_ADVERTISEMENT;
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder {
        private final ItemContainerPostProfileBinding binding;

        MessageViewHolder(ItemContainerPostProfileBinding itemContainerPostProfileBinding) {
            super(itemContainerPostProfileBinding.getRoot());
            binding = itemContainerPostProfileBinding;
        }
        public void setData(Profile profile) {
            binding.profilePostName.setText(profile.firstname+" "+profile.middlename+" "+profile.lastname);
            binding.profiledateofbirth.setText(profile.dateofbirth);
            binding.profilegender.setText(profile.gender);
            binding.profileheight.setText(profile.heightfeet+" "+profile.heightinch);
            if(profile.manglik.equals("yes")){
                binding.profilemanglik.setText("manglik");
            }else{
                binding.profilemanglik.setText("not-manglik");
            }
            binding.profilecurrenttimedate.setText(profile.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(profile.profileimage));
            binding.profilecast.setText(profile.cast);
            binding.profilecity.setText(profile.city);
            binding.profilestate.setText(profile.state);
            if(profile.special != null){
                binding.ribbon.setVisibility(View.VISIBLE);
            }
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                        profileListener.onProfileClicked(profile);
                    Intent i = new Intent(context, FavoritePostDetailActivity.class);
                    i.putExtra(Constants.KEY_ID,profile.fcmtoken);
                    i.putExtra(Constants.KEY_SPECIAL,profile.special);
                    context.startActivity(i);
                }
            });
        }
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder {
        private final  ItemContainerPostAdvertisementBinding binding;

        ImageViewHolder(ItemContainerPostAdvertisementBinding itemContainerPostAdvertisementBinding) {
            super(itemContainerPostAdvertisementBinding.getRoot());
            binding = itemContainerPostAdvertisementBinding;
        }
        public void setData(Advertisement advertisement) {
            binding.TitleName.setText(advertisement.titlename);
            binding.OwnerName.setText(advertisement.ownername);
            binding.OwnerContacts.setText(advertisement.ownercontact);
            binding.Description.setText(advertisement.description);
            binding.currentAddress.setText(advertisement.currentadress);
            binding.currentdatetime.setText(advertisement.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(advertisement.advertiseimage));
            binding.cardads.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context.getApplicationContext(), AdvertisementdetailActivity.class);
                    i.putExtra(Constants.KEY_ID,advertisement.id);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}
