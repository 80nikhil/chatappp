package com.example.chatapp.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.chatapp.PersistentBag;
import com.example.chatapp.R;
import com.example.chatapp.activities.PostProfileDetailActivity;
import com.example.chatapp.adapters.FavoriteAdapter;
import com.example.chatapp.listeners.ProfileListener;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class FavouriteFragment extends Fragment{

    private RecyclerView courseRV;
    private FavoriteAdapter adapter;
    private ArrayList<FavouriteModal> courseModalArrayList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
     View view = inflater.inflate(R.layout.fragment_favourite, container, false);

        courseRV = view.findViewById(R.id.idRVCourses);

        loaddata();
        buildRecyclerView();

        PersistentBag appState = PersistentBag.getInstance(getContext());
        JSONArray mycart = appState.getMybagcart();

        return view;
    }

    private void loaddata() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("shared preferences", MODE_PRIVATE);

        Gson gson = new Gson();
        String json = sharedPreferences.getString("courses", null);

        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();

        courseModalArrayList = gson.fromJson(json, type);
        if (courseModalArrayList == null) {
            courseModalArrayList = new ArrayList<>();
        }
    }
    private void buildRecyclerView() {
        adapter = new FavoriteAdapter(courseModalArrayList, getActivity());
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        courseRV.setHasFixedSize(true);
        courseRV.setLayoutManager(manager);
        courseRV.setAdapter(adapter);
    }

}