package com.example.chatapp.models;

public class Category {
    private String subject;
    private int imageId;

    public Category(String subject, int imageId){
        this.subject = subject;
        this.imageId = imageId;
    }

    public String getSubject() {
        return subject;
    }

    public int getImageId() {
        return imageId;
    }
}
