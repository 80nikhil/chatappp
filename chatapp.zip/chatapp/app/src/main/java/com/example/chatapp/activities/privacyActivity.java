package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import com.example.chatapp.R;

public class privacyActivity extends AppCompatActivity {
 WebView mywebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);

        mywebview = findViewById(R.id.mywebview);
        mywebview.loadUrl("https://kushwahasamajshubhvivah.com/privacy");
        mywebview.getSettings().setDomStorageEnabled(true);
        mywebview.getSettings().setJavaScriptEnabled(true);
    }
}