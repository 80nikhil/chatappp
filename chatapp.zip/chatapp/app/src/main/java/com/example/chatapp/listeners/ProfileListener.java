package com.example.chatapp.listeners;


import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;

public interface ProfileListener {
    void onProfileClicked(Profile profile);

    void onSpecialProfileClicked(SpecialProfile specialProfile);
}
