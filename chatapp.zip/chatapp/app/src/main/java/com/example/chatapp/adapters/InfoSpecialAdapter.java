package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;

import java.util.List;

public class InfoSpecialAdapter extends RecyclerView.Adapter<InfoSpecialAdapter.AdvertisementViewHolder>{
    private  final List<SpecialProfile> specialprofiles;
    private Context context;

    public InfoSpecialAdapter(List<SpecialProfile> specialprofiles,Context context) {
        this.specialprofiles = specialprofiles;
        this.context = context;
    }

    @NonNull
    @Override
    public InfoSpecialAdapter.AdvertisementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemContainerPostProfileBinding itemContainerPostProfileBinding = ItemContainerPostProfileBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false);
        return new InfoSpecialAdapter.AdvertisementViewHolder(itemContainerPostProfileBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull InfoSpecialAdapter.AdvertisementViewHolder holder, int position) {
        holder.setData(specialprofiles.get(position));
    }

    @Override
    public int getItemCount() {
        return specialprofiles.size();
    }

    public class AdvertisementViewHolder extends RecyclerView.ViewHolder {
        ItemContainerPostProfileBinding binding;

        AdvertisementViewHolder(ItemContainerPostProfileBinding itemContainerPostProfileBinding){
            super(itemContainerPostProfileBinding.getRoot());
            binding = itemContainerPostProfileBinding;
        }

        public void setData(SpecialProfile specialprofiles) {
            binding.profilePostName.setText(specialprofiles.firstname+" "+specialprofiles.middlename+" "+specialprofiles.lastname);
            binding.profiledateofbirth.setText(specialprofiles.dateofbirth);
            binding.profilegender.setText(specialprofiles.gender);
            binding.profileheight.setText(specialprofiles.heightfeet+" "+specialprofiles.heightinch);
            if(specialprofiles.manglik.equals("yes")){
                binding.profilemanglik.setText("manglik");
            }else{
                binding.profilemanglik.setText("not-manglik");
            }
            binding.profilecurrenttimedate.setText(specialprofiles.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(specialprofiles.profileimage));
            binding.profilecast.setText(specialprofiles.cast);
            binding.profilecity.setText(specialprofiles.city);
            binding.profilestate.setText(specialprofiles.state);
            if(specialprofiles.special != null){
                binding.ribbon.setVisibility(View.VISIBLE);
            }
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context, FavoritePostDetailActivity.class);
                    i.putExtra(Constants.KEY_ID,specialprofiles.fcmtoken);
                    i.putExtra(Constants.KEY_SPECIAL,specialprofiles.special);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}
