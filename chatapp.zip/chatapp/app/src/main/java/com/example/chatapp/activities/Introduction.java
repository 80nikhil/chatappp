package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.chatapp.fragments.Fragment1;
import com.example.chatapp.fragments.Fragment2;
import com.example.chatapp.fragments.Fragment3;
import com.example.chatapp.fragments.Fragment4;
import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;

public class Introduction extends AppCompatActivity {

    PrefrenceManager prefrenceManager;
    Button next;
    int position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        next = findViewById(R.id.btn_next);
        prefrenceManager = new PrefrenceManager(getApplicationContext());

        Fragment mFragment = null;
        mFragment = new Fragment1();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.frame_layout, mFragment).commit();
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefrenceManager.putBoolean(Constants.KEY_BOARDING,true);
                 if(position == 0){
                     Fragment mFragment = null;
                     mFragment = new Fragment2();
                     FragmentManager fragmentManager = getSupportFragmentManager();
                     fragmentManager.beginTransaction()
                             .replace(R.id.frame_layout, mFragment).commit();
                 }else if(position == 1){
                     Fragment mFragment = null;
                     mFragment = new Fragment3();
                     FragmentManager fragmentManager = getSupportFragmentManager();
                     fragmentManager.beginTransaction()
                             .replace(R.id.frame_layout, mFragment).commit();
                 }else if(position == 2){
                     Fragment mFragment = null;
                     mFragment = new Fragment4();
                     FragmentManager fragmentManager = getSupportFragmentManager();
                     fragmentManager.beginTransaction()
                             .replace(R.id.frame_layout, mFragment).commit();
                     next.setText("Done");
                 }else if(position == 3){
                     Intent i = new Intent(Introduction.this,SignInactivity.class);
                     startActivity(i);
                 }
                 ++position;
            }
        });
    }
}