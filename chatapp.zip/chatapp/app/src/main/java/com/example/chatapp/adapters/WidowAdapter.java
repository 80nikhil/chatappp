package com.example.chatapp.adapters;

public class WidowAdapter {
}
