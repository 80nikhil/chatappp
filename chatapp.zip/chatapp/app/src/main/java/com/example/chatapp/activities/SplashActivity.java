package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;

public class SplashActivity extends AppCompatActivity {

   private PrefrenceManager prefrenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);;

        prefrenceManager =new PrefrenceManager(getApplicationContext());

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(prefrenceManager.getBoolean(Constants.KEY_BOARDING) == true) {
                    if (prefrenceManager.getBoolean(Constants.KEY_IS_SIGNED_IN) == true) {
                        Intent i = new Intent(SplashActivity.this, HomeActivity.class);
                        startActivity(i);
                        finish();
                    } else {
                        Intent i = new Intent(SplashActivity.this, SignInactivity.class);
                        startActivity(i);
                        finish();
                    }
                }else{
                    Intent i = new Intent(SplashActivity.this, Introduction.class);
                    startActivity(i);
                    finish();
                }
            }
        }, 1500);
    }
}