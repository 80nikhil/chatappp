package com.example.chatapp.activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UpdateProfileActivity extends AppCompatActivity {

    ImageView img_UpdatePhoto,imgcalender,locationcurrent,locationhometown,backBtn;
    EditText edtName,UpdateContactNo,etEmailId,edtcurrentaddress,edthometownaddress,dob;
    Button btn_Update;
    FirebaseFirestore database;
    RadioButton male,female;
    TextView txtname;
    PrefrenceManager prefrenceManager;
    String encodedImage,gender;
    private DocumentReference documentReference;
    final Calendar myCalendar= Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        img_UpdatePhoto = findViewById(R.id.img_UpdatePhoto);
        backBtn = findViewById(R.id.backBtn);
        imgcalender = findViewById(R.id.imgcalendar);
        locationcurrent = findViewById(R.id.location_current);
        locationhometown = findViewById(R.id.location_hometown);
        edtName = findViewById(R.id.edtName);
        dob = findViewById(R.id.edtdob);
        UpdateContactNo = findViewById(R.id.UpdateContactNo);
        etEmailId = findViewById(R.id.etEmailId);
        edtcurrentaddress = findViewById(R.id.edtcurrentaddresss);
        edthometownaddress = findViewById(R.id.edthometownaddresss);
        btn_Update = findViewById(R.id.btn_Update);
        male = findViewById(R.id.radioGenderMale);
        female = findViewById(R.id.radioGenderFemale);
        txtname  = findViewById(R.id.txtname);

        prefrenceManager = new PrefrenceManager(getApplicationContext());
        loadProfileDetails();
        database = FirebaseFirestore.getInstance();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        locationhometown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefrenceManager.putString(Constants.KEY_CONTACT_NO,UpdateContactNo.getText().toString());
                prefrenceManager.putString(Constants.KEY_GENDER,gender);
                prefrenceManager.putString(Constants.KEY_PROFILE_DATEOFBIRTH,dob.getText().toString());
                prefrenceManager.putString(Constants.KEY_EMAIL,etEmailId.getText().toString());
                prefrenceManager.putString(Constants.KEY_SCREEN_ID,"updateprofile");
                prefrenceManager.putString(Constants.KEY_ID,"updatehometown");
                Intent i = new Intent(UpdateProfileActivity.this, MapActivity.class);
                startActivity(i);
            }
        });

        locationcurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefrenceManager.putString(Constants.KEY_CONTACT_NO,UpdateContactNo.getText().toString());
                prefrenceManager.putString(Constants.KEY_GENDER,gender);
                prefrenceManager.putString(Constants.KEY_PROFILE_DATEOFBIRTH,dob.getText().toString());
                prefrenceManager.putString(Constants.KEY_EMAIL,etEmailId.getText().toString());
                prefrenceManager.putString(Constants.KEY_ID,"updatecurrent");
                prefrenceManager.putString(Constants.KEY_MAP_ID,"postmap");
                prefrenceManager.putString(Constants.KEY_SCREEN_ID,"updateprofile");
                Intent i = new Intent(UpdateProfileActivity.this, MapActivity.class);
                startActivity(i);
            }
        });

        img_UpdatePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                pickImage.launch(intent);
            }
        });
        btn_Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(male.isChecked()){
                    gender = "Male";
                    prefrenceManager.putString(Constants.KEY_GENDER,"Male");
                }if(female.isChecked()){
                    gender = "Female";
                    prefrenceManager.putString(Constants.KEY_GENDER,"Female");
                }
                validatefields();
            }
        });
        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                prefrenceManager.putString(Constants.KEY_MAP_ID,"postmap");
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        imgcalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.DATE, 0);
                Date newDate = calendar.getTime();
                DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateProfileActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.getDatePicker().setMaxDate(newDate.getTime() - (newDate.getTime() % (24 * 60 * 60 * 1000)));
                datePickerDialog.show();
            }
        });

    }

    private void updateLabel() {
        String myFormat="dd/MM/yy";
        SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);
        dob.setText(dateFormat.format(myCalendar.getTime()));
        prefrenceManager.putString(Constants.KEY_PROFILE_DATEOFBIRTH,dateFormat.format(myCalendar.getTime()));
    }

    private void validatefields() {
        if(edtName.getText().toString().isEmpty()){
            edtName.setError("Please Enter Name");
        }else if(UpdateContactNo.getText().toString().isEmpty()){
            UpdateContactNo.setError("Please Enter Contact No");
        }else if(dob.getText().toString().isEmpty()){
          dob.setError("Please Enter Date Of Birth");
        } else if(etEmailId.getText().toString().isEmpty()){
            etEmailId.setError("Please Enter Email");
        }else if(edtcurrentaddress.getText().toString().isEmpty()){
            edtcurrentaddress.setError("Please Enter CurrentAddress");
        }else if(edthometownaddress.getText().toString().isEmpty()){
            edthometownaddress.setError("Please Enter Town address");
        }else{
//            PrefrenceManager prefrenceManager = new PrefrenceManager(getApplicationContext());
            documentReference = database.collection(Constants.KEY_COLLECTION_USERS)
                    .document(prefrenceManager.getString(Constants.KEY_USER_ID));
            documentReference.update(Constants.KEY_NAME,edtName.getText().toString());
            documentReference.update(Constants.KEY_CONTACT_NO,UpdateContactNo.getText().toString());
            documentReference.update(Constants.KEY_IMAGE,prefrenceManager.getString(Constants.KEY_IMAGE));
            documentReference.update(Constants.KEY_GENDER,gender);
            documentReference.update(Constants.KEY_PROFILE_DATEOFBIRTH,dob.getText().toString());
            documentReference.update(Constants.KEY_EMAIL,etEmailId.getText().toString());
            prefrenceManager.putString(Constants.KEY_NAME,edtName.getText().toString());
            prefrenceManager.putString(Constants.KEY_CONTACT_NO,UpdateContactNo.getText().toString());
            prefrenceManager.putString(Constants.KEY_GENDER,gender);
            prefrenceManager.putString(Constants.KEY_PROFILE_DATEOFBIRTH,dob.getText().toString());
            prefrenceManager.putString(Constants.KEY_EMAIL,etEmailId.getText().toString());
            prefrenceManager.putString(Constants.KEY_CURRENT_ADDRESS,edtcurrentaddress.getText().toString());
            prefrenceManager.putString(Constants.KEY_LOCATION,edthometownaddress.getText().toString());
            Toast.makeText(getApplicationContext(),"Profile Updated Successfully",Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(i);
        }
    }

    private final ActivityResultLauncher<Intent> pickImage = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK){
                    if(result.getData() != null){
                        Uri imageurl = result.getData().getData();
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(imageurl);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            img_UpdatePhoto.setImageBitmap(bitmap);
                            encodedImage = encodeImage(bitmap);
                            prefrenceManager.putString(Constants.KEY_IMAGE,encodedImage);
                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
            }
    );

    private String encodeImage(Bitmap bitmap){
        int previewWidth = 150;
        int previewHeight = bitmap.getHeight()*previewWidth/bitmap.getWidth();
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,false);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG,50,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }

    private void loadProfileDetails(){
            edtName.setText(prefrenceManager.getString(Constants.KEY_NAME));
            byte[] bytes = Base64.decode(prefrenceManager.getString(Constants.KEY_IMAGE), Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            img_UpdatePhoto.setImageBitmap(bitmap);
            UpdateContactNo.setText(prefrenceManager.getString(Constants.KEY_CONTACT_NO));
            etEmailId.setText(prefrenceManager.getString(Constants.KEY_EMAIL));
            if (prefrenceManager.getString(Constants.KEY_GENDER) == "Male") {
                male.setChecked(true);
            } else {
                female.setChecked(true);
            }
            edtcurrentaddress.setText(prefrenceManager.getString(Constants.KEY_CURRENT_ADDRESS));
            edthometownaddress.setText(prefrenceManager.getString(Constants.KEY_LOCATION));
            dob.setText(prefrenceManager.getString(Constants.KEY_PROFILE_DATEOFBIRTH));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}