package com.example.chatapp.adapters;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.databinding.ItemContainerRecievedMessageBinding;
import com.example.chatapp.databinding.ItemContainerSendMessgageBinding;
import com.example.chatapp.databinding.ItemContainerUserBinding;
import com.example.chatapp.models.ChatMessage;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<ChatMessage> chatMessage;
    private Bitmap recieverProfileImage;
    private final String senderId;
    public static final int VIEW_TYPE_SENT = 1;
    public static final int VIEW_TYPE_RECIEVED = 2;

    public void setRecieverProfileImage(Bitmap bitmap) {
        recieverProfileImage = bitmap;
    }

    public ChatAdapter(List<ChatMessage> chatMessage, Bitmap recieverProfileImage, String senderId) {
        this.chatMessage = chatMessage;
        this.recieverProfileImage = recieverProfileImage;
        this.senderId = senderId;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_SENT) {
            return new SentMessageViewHolder(
                    ItemContainerSendMessgageBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        } else {
            return new RecievedMessageViewHolder(
                    ItemContainerRecievedMessageBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == VIEW_TYPE_SENT) {
            ((SentMessageViewHolder) holder).setData(chatMessage.get(position));
        } else {
            ((RecievedMessageViewHolder) holder).setData(chatMessage.get(position), recieverProfileImage);
        }
    }

    @Override
    public int getItemCount() {
        return chatMessage.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (chatMessage.get(position).senderId.equals(senderId)) {
            return VIEW_TYPE_SENT;
        } else {
            return VIEW_TYPE_RECIEVED;
        }
    }

    static class SentMessageViewHolder extends RecyclerView.ViewHolder {

        private final ItemContainerSendMessgageBinding binding;

        SentMessageViewHolder(ItemContainerSendMessgageBinding itemContainerSendMessgageBinding) {
            super(itemContainerSendMessgageBinding.getRoot());
            binding = itemContainerSendMessgageBinding;
        }

        void setData(ChatMessage chatMessage) {
            if (chatMessage != null) {
                if (chatMessage.type.equals("image")) {
                    binding.textMessage.setVisibility(View.GONE);
                    binding.textDateTime.setVisibility(View.GONE);
                    binding.imagechat.setVisibility(View.VISIBLE);
                    binding.imagechat.setImageBitmap(getImage(chatMessage.message));
                    binding.textDateTimeimage.setText(chatMessage.dateTime);
                } else if (chatMessage.type.equals("text")) {
                    binding.textDateTimeimage.setVisibility(View.GONE);
                    binding.textMessage.setVisibility(View.VISIBLE);
                    binding.imagechat.setVisibility(View.GONE);
                    binding.textMessage.setText(chatMessage.message);
                    binding.textDateTime.setText(chatMessage.dateTime);
                }
                if (getItemViewType() == VIEW_TYPE_SENT) {
                    binding.seendeliver.setText("Sent");
                } else {
                    binding.seendeliver.setText("Delievered");
                }
            }
        }
        private Bitmap getImage(String encodedImage){
            byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
        }
    }

    static class RecievedMessageViewHolder extends RecyclerView.ViewHolder {

        private final ItemContainerRecievedMessageBinding binding;

        RecievedMessageViewHolder(ItemContainerRecievedMessageBinding itemContainerRecievedMessageBinding) {
            super(itemContainerRecievedMessageBinding.getRoot());
            binding = itemContainerRecievedMessageBinding;
        }

        void setData(ChatMessage chatMessage, Bitmap recieveProfileImage) {
            if (chatMessage != null) {
                try {
                    if (chatMessage.type.equals("image")) {
                        binding.textDateTime.setVisibility(View.GONE);
                        binding.textMessage.setVisibility(View.GONE);
                        binding.imagechat.setVisibility(View.VISIBLE);
                        binding.imagechat.setImageBitmap(getImage(chatMessage.message));
                        binding.textDateTimeimage.setText(chatMessage.dateTime);
                    } else if (chatMessage.type.equals("text")) {
                        binding.textDateTimeimage.setVisibility(View.GONE);
                        binding.textMessage.setVisibility(View.VISIBLE);
                        binding.imagechat.setVisibility(View.GONE);
                        binding.textMessage.setText(chatMessage.message);
                        binding.textDateTime.setText(chatMessage.dateTime);
                    }
                }catch (Exception e){
                    e.printStackTrace();
            }
                if (recieveProfileImage != null) {
                    binding.imageprofile.setImageBitmap(recieveProfileImage);
                }
            }
        }
        private Bitmap getImage(String encodedImage){
            byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
        }
    }
}