package com.example.chatapp.activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.models.Advertisementfavorite;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class PostAdvertisementActivity extends AppCompatActivity {

    ImageView PostImg, imgCloseBtnA,bacckbtn;
    EditText edtTitleName, edtOwnerName, edtOwnerContact, edtDescription;
    Button submit;
    private String encodedImage,currentdatetime,validity,payment;
    PrefrenceManager prefrenceManager;
    ArrayList<Advertisementfavorite> advertisementarraylist;
    ProgressBar progressBar;
    TextView edtCurrentAddress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_advertisement);

        PostImg = findViewById(R.id.postimage);
        bacckbtn = findViewById(R.id.Backbtn);
        imgCloseBtnA = findViewById(R.id.imgCloseBtnA);
        edtTitleName = findViewById(R.id.edtTitleName);
        edtOwnerName = findViewById(R.id.edtOwnerName);
        edtOwnerContact = findViewById(R.id.edtOwnerContact);
        edtCurrentAddress = findViewById(R.id.edtCurrentAddress);
        edtDescription = findViewById(R.id.edtDescription);
        submit = findViewById(R.id.btn_submit);
        progressBar = findViewById(R.id.progress);
//        validity = getIntent().getExtras().getString("validity");
        prefrenceManager = new PrefrenceManager(getApplicationContext());

        loaddata();
        bacckbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(i);
            }
        });
        imgCloseBtnA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MapActivity.class);
                prefrenceManager.putString(Constants.KEY_SCREEN_ID,"advertisement");
                prefrenceManager.putString(Constants.KEY_ID,"advertisement");
                startActivityForResult(intent, 01);
            }
        });

        PostImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                pickImage.launch(intent);
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                currentdatetime = sdf.format(new Date());
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);
                submit.setVisibility(View.GONE);
                if(payment == null){
                    Intent intent = new Intent(getApplicationContext(), PaymentActivity.class);
                    intent.putExtra("type","advertisement");
                    prefrenceManager.putString(Constants.KEY_ID,"advertisement");
                    startActivityForResult(intent, 02);
                    progressBar.setVisibility(View.GONE);
                    submit.setVisibility(View.VISIBLE);
                }else {
                    if (isValidAdvertiseDetails()) {
                        postadvertisement();
                        advertisementarraylist.add(new Advertisementfavorite(encodedImage, edtTitleName.getText().toString(), edtOwnerName.getText().toString()
                                , edtOwnerContact.getText().toString(), edtCurrentAddress.getText().toString()
                                , edtDescription.getText().toString(), currentdatetime, validity));
                        savedata();
                    }
                }
            }
        });
    }@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 01) {
                edtCurrentAddress.setText(data.getStringExtra(Constants.KEY_ADVERTISEMENT_ADDRESS));
            }else if (requestCode == 02) {
                validity = data.getStringExtra(Constants.KEY_VALIDITY);
                payment = data.getStringExtra(Constants.PAYMENT);
            }
        }
    }

    private void postadvertisement() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> advertise = new HashMap<>();
        advertise.put(Constants.KEY_VALIDITY,validity);
        advertise.put(Constants.KEY_RECIEVER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        advertise.put(Constants.KEY_ADVERTISE_IMAGE,encodedImage);
        advertise.put(Constants.KEY_TITLE_NAME,edtTitleName.getText().toString());
        advertise.put(Constants.KEY_OWNER_NAME,edtOwnerName.getText().toString());
        advertise.put(Constants.KEY_OWNER_CONTACT,edtOwnerContact.getText().toString());
        advertise.put(Constants.KEY_CURRENT_ADDRESS,edtCurrentAddress.getText().toString());
        advertise.put(Constants.KEY_DESCRIPTION,edtDescription.getText().toString());
        advertise.put(Constants.KEY_CURRENT_DATE_TIME,currentdatetime);
        advertise.put(Constants.KEY_USER_ID,prefrenceManager.getString(Constants.KEY_USER_ID));
        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .add(advertise)
                .addOnSuccessListener(documentReference -> {
                    Intent i = new Intent(getApplicationContext(), HomeActivity.class);
                    progressBar.setVisibility(View.GONE);
                    submit.setVisibility(View.VISIBLE);
                    prefrenceManager.putString(Constants.KEY_ADVERTISEMENT_ADDRESS,null);
                    Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .addOnFailureListener(exception -> {
                    Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private final ActivityResultLauncher<Intent> pickImage = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK){
                    if(result.getData() != null){
                        Uri imageurl = result.getData().getData();
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(imageurl);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            encodedImage = encodeImage(bitmap);
                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
            }
    );

    private String encodeImage(Bitmap bitmap){
        int previewWidth = 500;
        int previewHeight = 250;
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,true);
        PostImg.setImageBitmap(previewBitmap);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }
    private boolean isValidAdvertiseDetails() {
        if (encodedImage == null) {
            Toast.makeText(this, "Please Choose image", Toast.LENGTH_SHORT).show();
            return false;
        } else if (edtTitleName.getText().toString().isEmpty()) {
            edtTitleName.setError("Title Name is Empty");
            progressBar.setVisibility(View.GONE);
            submit.setVisibility(View.VISIBLE);
            return false;
        } else if (edtOwnerName.getText().toString().isEmpty()) {
            edtOwnerName.setError("Ownername is Empty");
            progressBar.setVisibility(View.GONE);
            submit.setVisibility(View.VISIBLE);
            return false;
        } else if (edtOwnerContact.getText().toString().isEmpty()) {
            edtOwnerContact.setError("OwnerContact is Empty");
            progressBar.setVisibility(View.GONE);
            submit.setVisibility(View.VISIBLE);
            return false;
        } else if (edtCurrentAddress.getText().toString().isEmpty()) {
            edtCurrentAddress.setError("CurrentAdress is Empty");
            progressBar.setVisibility(View.GONE);
            submit.setVisibility(View.VISIBLE);
            return false;
        } else if (edtDescription.getText().toString().isEmpty()) {
            edtDescription.setError("Description is Empty");
            progressBar.setVisibility(View.GONE);
            submit.setVisibility(View.VISIBLE);
            return false;
        } else {
            return true;
        }
    }
    private void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(advertisementarraylist);
        editor.putString("advertisements", json);

        editor.apply();
    }private void loaddata() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("advertisements", null);
        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();
        advertisementarraylist = gson.fromJson(json, type);
        if (advertisementarraylist == null) {
            advertisementarraylist = new ArrayList<>();
        }
    }
}