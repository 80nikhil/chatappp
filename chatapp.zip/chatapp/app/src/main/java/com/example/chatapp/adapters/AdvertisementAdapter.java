package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.activities.AdvertisementdetailActivity;
import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostAdvertisementBinding;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Profile;
import com.example.chatapp.utilities.Constants;

import java.util.List;

public class AdvertisementAdapter extends RecyclerView.Adapter<AdvertisementAdapter.AdvertisementViewHolder>{
    private  final List<Advertisement> advertisements;
    private Context context;

    public AdvertisementAdapter(List<Advertisement> advertisements,Context context) {
        this.advertisements = advertisements;
        this.context = context;
    }

    @NonNull
    @Override
    public AdvertisementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemContainerPostAdvertisementBinding itemContainerPostAdvertisementBinding = ItemContainerPostAdvertisementBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false);
        return new AdvertisementAdapter.AdvertisementViewHolder(itemContainerPostAdvertisementBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull AdvertisementViewHolder holder, int position) {
        holder.setAdvertisementdata(advertisements.get(position));
    }

    @Override
    public int getItemCount() {
        return advertisements.size();
    }

    public class AdvertisementViewHolder extends RecyclerView.ViewHolder {
        ItemContainerPostAdvertisementBinding binding;

        AdvertisementViewHolder(ItemContainerPostAdvertisementBinding itemContainerPostAdvertisementBinding){
            super(itemContainerPostAdvertisementBinding.getRoot());
            binding = itemContainerPostAdvertisementBinding;
        }

        public void setAdvertisementdata(Advertisement advertisement) {
                binding.TitleName.setText(advertisement.titlename);
                binding.OwnerName.setText(advertisement.ownername);
                binding.OwnerContacts.setText(advertisement.ownercontact);
                binding.Description.setText(advertisement.description);
                binding.currentAddress.setText(advertisement.currentadress);
                binding.currentdatetime.setText(advertisement.currentDateandTime);
                binding.profilePostImage.setImageBitmap(getAdvertisementImage(advertisement.advertiseimage));
                binding.cardads.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(context.getApplicationContext(), AdvertisementdetailActivity.class);
                        i.putExtra(Constants.KEY_ID,advertisement.id);
                        context.startActivity(i);
                    }
                });
//                binding.call.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent intent = new Intent(Intent.ACTION_DIAL);
//                        String temp = "tel:" + advertisement.ownercontact;
//                        intent.setData(Uri.parse(temp));
//                        context.startActivity(intent);
//                    }
//                });
        }
    }
    private Bitmap getAdvertisementImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}
