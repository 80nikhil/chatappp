package com.example.chatapp.activities;

import androidx.annotation.NonNull;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.example.chatapp.R;
import com.example.chatapp.adapters.CategoryAdapter;
import com.example.chatapp.adapters.ProfileAdapter;
import com.example.chatapp.adapters.SpecialProfileAdapter;
import com.example.chatapp.databinding.ActivityHomeBinding;
import com.example.chatapp.listeners.ProfileListener;
import com.example.chatapp.listeners.SpecialProfileListener;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Category;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class HomeActivity extends BaseActivity implements ProfileListener {
    private PrefrenceManager prefrenceManager;
    ViewFlipper flipper;
    Context context;
    ArrayList<Category> subjectArrayList = new ArrayList<>();
    private ActivityHomeBinding binding;
    ArrayList<Advertisement> advertisements = new ArrayList<>();
    ArrayList<Profile> profiles = new ArrayList<>();
    ArrayList<SpecialProfile> specialprofiles = new ArrayList<>();
    String validity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        prefrenceManager = new PrefrenceManager(getApplicationContext());
        binding.progresshome.setVisibility(View.VISIBLE);
        binding.txtloading.setVisibility(View.VISIBLE);
        getadvertisements();
        getspecial();
        getfirst();
        if(prefrenceManager.getString("position") != null) {
            binding.scrollhome.setVerticalScrollbarPosition(Integer.parseInt(prefrenceManager.getString("position")));
        }


        flipper = findViewById(R.id.flipper);
        int imgarr[] = {R.drawable.slide_img1,R.drawable.slide_img2, R.drawable.slide_img3,R.drawable.slide_img5};
        for(int i =0;i< imgarr.length;i++) {
            showimage(imgarr[i]);
            context = this;
        }



            RecyclerView recyclerView = findViewById(R.id.categoryrecycler);
            CategoryAdapter adapter = new CategoryAdapter(context,subjectArrayList);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
            recyclerView.setHasFixedSize(true);

            subjectArrayList.add(new Category("Boy", R.drawable.boyfront));
            subjectArrayList.add(new Category("Girl", R.drawable.girlfront));
            subjectArrayList.add(new Category("Widow", R.drawable.widowfront));
            subjectArrayList.add(new Category("Divorced", R.drawable.divorcefront));
            subjectArrayList.add(new Category("Advertisement", R.drawable.advertisefront));


            //bottom navigation
            binding.bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    Fragment temp = null;
                    switch (item.getItemId()) {

                        case R.id.home:
                            Intent i3 = new Intent(HomeActivity.this,HomeActivity.class);
                            startActivity(i3);
                            finish();
                            break;

                        case R.id.chat:
                            Intent i = new Intent(HomeActivity.this,MainActivity.class);
                            startActivity(i);
                            finish();
                            break;

                        case R.id.profile:
                            Intent i2 = new Intent(HomeActivity.this,MyPostActivity.class);
                            startActivity(i2);
                            finish();
//                            prefrenceManager.putString(Constants.KEY_PAYMENT_POST,"yes");
//                            Toast.makeText(getApplicationContext(),prefrenceManager.getString(Constants.KEY_PAYMENT_POST),Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.notification:
                            Intent intent = new Intent(HomeActivity.this,ProfileActivity.class);
                            startActivity(intent);
                            break;

                    }
                    return true;
                }
            });
            binding.fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BottomSheetDialog bottomSheet = new BottomSheetDialog();
                    bottomSheet.show(getSupportFragmentManager(),
                            "Select Option");
                }
            });
            binding.postfirstnow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getApplicationContext(), PostActivity.class);
                    i.putExtra(Constants.KEY_SPECIAL,"null");
                    i.putExtra(Constants.KEY_VALIDITY,"30");
                    startActivity(i);
                }
            });
            binding.scrollhome.fullScroll(View.FOCUS_DOWN);
            binding.scrollhome.setSmoothScrollingEnabled(true);
    }

    private void getspecial() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    specialprofiles.add(specialprofile);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            SpecialProfileAdapter specialprofileAdapter = new SpecialProfileAdapter(specialprofiles, advertisements,this,this);
                            binding.specialprofilesrecycler.setAdapter(specialprofileAdapter);
                            binding.progresshome.setVisibility(View.INVISIBLE);
                            binding.specialprofilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    }
                    else {

                    }
                });
        getprofiles();
    }

    private void getfirst() {
        if(prefrenceManager.getString(Constants.KEY_PAYMENT_POST) != null) {
            if (prefrenceManager.getString(Constants.KEY_PAYMENT_POST).equals("yes")) {
                binding.cardfirst.setVisibility(View.GONE);
            }
        }else{
            binding.cardfirst.setVisibility(View.VISIBLE);
        }
    }


    private void getprofiles() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                                try {
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                    String CurrentDate = sdf.format(new Date());
                                    String FinalDate = profile.currentDateandTime;
                                    Date date1;
                                    Date date2;
                                    SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                    date1 = dates.parse(CurrentDate);
                                    date2 = dates.parse(FinalDate);
                                    long difference = Math.abs(date1.getTime() - date2.getTime());
                                    long differenceDates = difference / (24 * 60 * 60 * 1000);
                                    long valid = Long.parseLong(profile.validity);
                                    if (differenceDates <= valid) {
                                        profiles.add(profile);
//                                        Collections.reverse(profiles);
//                                        Collections.sort(profile.currentDateandTime, (t1, t2) -> t1.currentDateandTime().compareTo(t2.currentDateandTime()));
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        if (profiles.size() > 0) {
                            ProfileAdapter profileAdapter = new ProfileAdapter(profiles, advertisements,this,this);
                            binding.profilesrecycler.setAdapter(profileAdapter);
                            binding.profilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        binding.progresshome.setVisibility(View.GONE);
        binding.txtloading.setVisibility(View.GONE);
    }

    private void showimage(int img){
        ImageView imageView = new ImageView(getApplicationContext());
        imageView.setBackgroundResource(img);
        flipper.addView(imageView);
        flipper.setFlipInterval(3000);
        flipper.setAutoStart(true);
        flipper.setInAnimation(getApplicationContext(), android.R.anim.slide_in_left);
        flipper.setOutAnimation(getApplicationContext(), android.R.anim.slide_out_right);
    }

    @Override
    public void onProfileClicked(Profile profile) {
        Intent intent = new Intent(getApplicationContext(),PostProfileDetailActivity.class);
        intent.putExtra(Constants.KEY_PROFILE,profile);
        intent.putExtra(Constants.KEY_PROFILE_DATEOFBIRTH,profile);
        intent.putExtra(Constants.KEY_PROFILE_FIRST_NAME,profile);
        intent.putExtra(Constants.KEY_PROFILE_MIDDLE_NAME,profile);
        intent.putExtra(Constants.KEY_PROFILE_LAST_NAME,profile);
        intent.putExtra(Constants.KEY_GENDER,profile);
        intent.putExtra(Constants.KEY_FATHER_NAME,profile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_MOTHER_NAME,profile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_CURRENT_ADDRESS,profile);
        intent.putExtra(Constants.KEY_HOMETOWN_ADDRESS,profile);
        intent.putExtra(Constants.KEY_DESCRIPTION,profile);
        intent.putExtra(Constants.KEY_IS_MANGLIK,profile);
        intent.putExtra(Constants.KEY_IS_DIVORCED,profile);
        intent.putExtra(Constants.KEY_ALLOW_CALL,profile);
        intent.putExtra(Constants.KEY_IS_WIDOW,profile);
        intent.putExtra(Constants.KEY_SELECT_BROTHER,profile);
        intent.putExtra(Constants.KEY_SELECT_SISTER,profile);
        intent.putExtra(Constants.KEY_MONTHLY_INCOME,profile);
        intent.putExtra(Constants.KEY_SELECT_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_SELECT_EDUCATION,profile);
        intent.putExtra(Constants.KEY_CAST,profile);
        intent.putExtra(Constants.KEY_WEIGHT,profile);
        intent.putExtra(Constants.KEY_HEIGHT_INCHES,profile);
        intent.putExtra(Constants.KEY_HEIGHT_FEET,profile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_POST_IMAGE,profile);
        intent.putExtra(Constants.KEY_CURRENT_DATE_TIME,profile);
        intent.putExtra(Constants.KEY_CONTACT_NO,profile);
        intent.putExtra(Constants.KEY_PROFILE_RECIEVER_ID,profile);
        intent.putExtra(Constants.KEY_FCM_TOKEN,profile);
        intent.putExtra(Constants.KEY_CITY,profile);
        intent.putExtra(Constants.KEY_STATE,profile);
        intent.putExtra(Constants.KEY_SPECIAL,"null");
        intent.putExtra(Constants.KEY_VALIDITY,validity);
        intent.putExtra(Constants.KEY_ACTIVITY,"home");
        prefrenceManager.putString("position", String.valueOf(binding.scrollhome.getVerticalScrollbarPosition()));
        startActivity(intent);
        finish();
    }

    @Override
    public void onSpecialProfileClicked(SpecialProfile specialProfile) {
        Intent intent = new Intent(getApplicationContext(),PostProfileDetailActivity.class);
        intent.putExtra(Constants.KEY_PROFILE,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_DATEOFBIRTH,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_FIRST_NAME,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_MIDDLE_NAME,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_LAST_NAME,specialProfile);
        intent.putExtra(Constants.KEY_GENDER,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_NAME,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_NAME,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_CURRENT_ADDRESS,specialProfile);
        intent.putExtra(Constants.KEY_HOMETOWN_ADDRESS,specialProfile);
        intent.putExtra(Constants.KEY_DESCRIPTION,specialProfile);
        intent.putExtra(Constants.KEY_IS_MANGLIK,specialProfile);
        intent.putExtra(Constants.KEY_IS_DIVORCED,specialProfile);
        intent.putExtra(Constants.KEY_ALLOW_CALL,specialProfile);
        intent.putExtra(Constants.KEY_IS_WIDOW,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_BROTHER,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_SISTER,specialProfile);
        intent.putExtra(Constants.KEY_MONTHLY_INCOME,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_EDUCATION,specialProfile);
        intent.putExtra(Constants.KEY_CAST,specialProfile);
        intent.putExtra(Constants.KEY_WEIGHT,specialProfile);
        intent.putExtra(Constants.KEY_HEIGHT_INCHES,specialProfile);
        intent.putExtra(Constants.KEY_HEIGHT_FEET,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_POST_IMAGE,specialProfile);
        intent.putExtra(Constants.KEY_CURRENT_DATE_TIME,specialProfile);
        intent.putExtra(Constants.KEY_CONTACT_NO,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_RECIEVER_ID,specialProfile);
        intent.putExtra(Constants.KEY_FCM_TOKEN,specialProfile);
        intent.putExtra(Constants.KEY_CITY,specialProfile);
        intent.putExtra(Constants.KEY_STATE,specialProfile);
        intent.putExtra(Constants.KEY_SPECIAL,"special");
        intent.putExtra(Constants.KEY_VALIDITY,validity);
        intent.putExtra(Constants.KEY_ACTIVITY,"home");
        prefrenceManager.putString("position", String.valueOf(binding.scrollhome.getVerticalScrollbarPosition()));
        startActivity(intent);
        finish();
    }

    private void getadvertisements() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();

        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                                Advertisement advertisement = new Advertisement();
                                advertisement.id = queryDocumentSnapshot.getId();
                                advertisement.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                                advertisement.advertiseimage = queryDocumentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE);
                                advertisement.titlename = queryDocumentSnapshot.getString(Constants.KEY_TITLE_NAME);
                                advertisement.ownername = queryDocumentSnapshot.getString(Constants.KEY_OWNER_NAME);
                                advertisement.ownercontact = queryDocumentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                                advertisement.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                                advertisement.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                                advertisement.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);

                            try {
                                  SimpleDateFormat sdf = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                    String CurrentDate = sdf.format(new Date());
                                    String FinalDate = advertisement.currentDateandTime;
                                    Date date1;
                                    Date date2;
                                    SimpleDateFormat dates = new SimpleDateFormat("dd.mm.yyyy  hh:mm");
                                    date1 = dates.parse(CurrentDate);
                                    date2 = dates.parse(FinalDate);
                                    long difference = Math.abs(date1.getTime() - date2.getTime());
                                    long differenceDates = difference / (24 * 60 * 60 * 1000);
                                    long valid = Long.parseLong(advertisement.validity);
                                    if (differenceDates <= valid) {
                                        advertisements.add(advertisement);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                        }
                        if (advertisements.size() > 0) {
                            Collections.shuffle(advertisements);
                            ProfileAdapter profileAdapter = new ProfileAdapter(profiles, advertisements,this,this);
                            binding.profilesrecycler.setAdapter(profileAdapter);
                            binding.progresshome.setVisibility(View.INVISIBLE);
                            binding.profilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}
