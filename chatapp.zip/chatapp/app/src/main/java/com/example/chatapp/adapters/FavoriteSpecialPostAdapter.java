package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.databinding.ItemPostFavoriteProfileBinding;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FavoriteSpecialPostAdapter extends RecyclerView.Adapter<FavoriteSpecialPostAdapter.AdvertisementViewHolder> {

    ArrayList<SpecialProfile> specialprofiles;
    private Context context;

    public FavoriteSpecialPostAdapter(ArrayList<SpecialProfile> specialprofiles, Context context) {
        this.specialprofiles = specialprofiles;
        this.context = context;
    }

    @NonNull
    @Override
    public FavoriteSpecialPostAdapter.AdvertisementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPostFavoriteProfileBinding itemPostFavoriteProfileBinding = ItemPostFavoriteProfileBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false);
        return new FavoriteSpecialPostAdapter.AdvertisementViewHolder(itemPostFavoriteProfileBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteSpecialPostAdapter.AdvertisementViewHolder holder, int position) {
        holder.setData(specialprofiles.get(position));
    }

    @Override
    public int getItemCount() {
        return specialprofiles.size();
    }

    public class AdvertisementViewHolder extends RecyclerView.ViewHolder {
        ItemPostFavoriteProfileBinding binding;

        AdvertisementViewHolder(ItemPostFavoriteProfileBinding itemPostFavoriteProfileBinding) {
            super(itemPostFavoriteProfileBinding.getRoot());
            binding = itemPostFavoriteProfileBinding;
        }

        public void setData(SpecialProfile specialProfiles) {
            binding.mprofilePostName.setText(specialProfiles.firstname + " " + specialProfiles.middlename + " " + specialProfiles.lastname);
            binding.mprofiledateofbirth.setText(specialProfiles.dateofbirth);
            binding.mprofileeducation.setText(specialProfiles.education);
            binding.mbrother.setText(specialProfiles.brothers);
            binding.msisters.setText(specialProfiles.sisters);
            binding.mprofiledateofbirth.setText(specialProfiles.dateofbirth);
            binding.mprofilePostImage.setImageBitmap(getProfileImage(specialProfiles.profileimage));
            binding.mprofilecast.setText(specialProfiles.cast);
            binding.mprofilecurrenttimedate.setText(specialProfiles.currentDateandTime);
            binding.mprofilecity.setText(specialProfiles.city + "," + specialProfiles.state);
            if (specialProfiles.special != null) {
                binding.ribbonfavorite.setVisibility(View.VISIBLE);
            }
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                String CurrentDate = sdf.format(new Date());
                String FinalDate = specialProfiles.currentDateandTime;
                Date date1;
                Date date2;
                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                date1 = dates.parse(CurrentDate);
                date2 = dates.parse(FinalDate);
                long difference = Math.abs(date1.getTime() - date2.getTime());
                long differenceDates = difference / (24 * 60 * 60 * 1000);
                long valid = Long.parseLong(specialProfiles.validity);
                if (differenceDates <= valid) {
                    binding.mactive.setText("Active");
                    binding.mactive.setBackgroundResource(R.drawable.gradient_green);
                } else {
                    binding.mactive.setText("Inactive");
                    binding.mactive.setBackgroundResource(R.drawable.gradient);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context, FavoritePostDetailActivity.class);
                    i.putExtra(Constants.KEY_ID, specialProfiles.fcmtoken);
                    i.putExtra(Constants.KEY_SPECIAL, specialProfiles.special);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}