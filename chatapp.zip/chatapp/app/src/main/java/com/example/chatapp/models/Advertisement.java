package com.example.chatapp.models;

import java.io.Serializable;

public class Advertisement implements Serializable {
    public String advertiseimage,titlename,ownername,ownercontact,currentadress
            ,description,currentDateandTime,validity,id,recieverid;
}
