package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Passwordchange extends AppCompatActivity {

    EditText no,password,confirmpassword;
    Button submit;
    FirebaseFirestore database;
    private DocumentReference documentReference;
    ProgressBar progress_bar;
    String mobileno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passwordchange);


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        progress_bar = findViewById(R.id.progress_bar);
        database = FirebaseFirestore.getInstance();
        no = findViewById(R.id.edt_mobile);
        password = findViewById(R.id.edt_password);
        confirmpassword = findViewById(R.id.edt_confirm_password);
        submit = findViewById(R.id.btn_submit);
        mobileno = getIntent().getExtras().getString(Constants.KEY_CONTACT_NO);
        no.setText(mobileno);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progress_bar.setVisibility(View.VISIBLE);
                if(password.getText().toString().equals(confirmpassword.getText().toString())){
                    database.collection(Constants.KEY_COLLECTION_USERS)
                            .whereEqualTo(Constants.KEY_CONTACT_NO,no.getText().toString())
                            .get()
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful() && task.getResult() != null &&
                                        task.getResult().getDocuments().size() > 0) {
                                    DocumentSnapshot documentSnapshot = task.getResult().getDocuments().get(0);
                                    String id = documentSnapshot.getId();
                                  try {
                                      documentReference = database.collection(Constants.KEY_COLLECTION_USERS)
                                              .document(id);
                                      documentReference.update(Constants.KEY_PASSWORD, password.getText().toString());
                                      progress_bar.setVisibility(View.GONE);
                                      Toast.makeText(Passwordchange.this, "Password Updated Successfully", Toast.LENGTH_SHORT).show();
                                      startActivity(new Intent(getApplicationContext(), SignInactivity.class));
                                  }catch (Exception e){
                                      Toast.makeText(Passwordchange.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                                  }
                                }
                            });
                }else{
                    Toast.makeText(Passwordchange.this, "Password Doesn't match", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}