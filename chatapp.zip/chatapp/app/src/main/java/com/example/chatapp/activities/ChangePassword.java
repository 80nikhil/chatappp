package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class ChangePassword extends AppCompatActivity {

    EditText currentpassword,newpassword,confirmpassword;
    Button submit;
    TextView password;
    ImageView passwordtoggle,confirmpasswordtoggle,confirmpasswordtoggle2,Backbtn;
    FirebaseFirestore database;
    private PrefrenceManager prefrenceManager;
    private DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        database = FirebaseFirestore.getInstance();
        currentpassword = findViewById(R.id.edt_password);
        newpassword = findViewById(R.id.edtnewpassword);
        confirmpassword = findViewById(R.id.edt_confirm_password);
        submit = findViewById(R.id.btn_submit);
        password = findViewById(R.id.password);
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        passwordtoggle = findViewById(R.id.password_toggle);
        confirmpasswordtoggle = findViewById(R.id.confirm_password_toggle);
        confirmpasswordtoggle2 = findViewById(R.id.confirm_password_toggle2);
        Backbtn = findViewById(R.id.backBtn);
        passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
        confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
        confirmpasswordtoggle2.setImageResource(R.drawable.ic_baseline_visibility_24);


        password.setText(prefrenceManager.getString(Constants.KEY_PASSWORD));


        passwordtoggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    currentpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
                    currentpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        confirmpasswordtoggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(newpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    newpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
                    newpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        confirmpasswordtoggle2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(confirmpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    confirmpasswordtoggle2.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    confirmpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    confirmpasswordtoggle2.setImageResource(R.drawable.ic_baseline_visibility_24);
                    confirmpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        Backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validatefield();
            }
        });


    }

    private void validatefield() {
        if(currentpassword.getText().toString().isEmpty()){
            Toast.makeText(ChangePassword.this,"Current Password is empty",Toast.LENGTH_SHORT).show();
        } if(newpassword.getText().toString().isEmpty()){
            Toast.makeText(ChangePassword.this,"New Password is empty",Toast.LENGTH_SHORT).show();
        }
        if(confirmpassword.getText().toString().isEmpty()){
            Toast.makeText(ChangePassword.this,"Confirm Password is empty",Toast.LENGTH_SHORT).show();
        }
        if(confirmpassword.getText().toString().equals(newpassword.getText().toString())) {
           if (currentpassword.getText().toString().equals(prefrenceManager.getString(Constants.KEY_PASSWORD))) {
               PrefrenceManager prefrenceManager = new PrefrenceManager(getApplicationContext());
               documentReference = database.collection(Constants.KEY_COLLECTION_USERS)
                       .document(prefrenceManager.getString(Constants.KEY_USER_ID));
               documentReference.update(Constants.KEY_PASSWORD,confirmpassword.getText().toString());
               Toast.makeText(getApplicationContext(),"Password changed Successfully",Toast.LENGTH_SHORT).show();
               Intent i = new Intent(getApplicationContext(),HomeActivity.class);
               prefrenceManager.putString(Constants.KEY_PASSWORD,confirmpassword.getText().toString());
               startActivity(i);
           }else{
               Toast.makeText(getApplicationContext(), "current password doesn't match", Toast.LENGTH_SHORT).show();
           }
        }else{
            Toast.makeText(getApplicationContext(), "password doesn't match", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(),HomeActivity.class);
        startActivity(i);
    }
}