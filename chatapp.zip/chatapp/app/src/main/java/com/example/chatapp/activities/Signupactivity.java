package com.example.chatapp.activities;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Signupactivity extends AppCompatActivity {

    private static final int PIC_CROP = 1 ;
    EditText edtemail, edtname, edtpassword,edtconfirmpassword, edtcontact,edtstate,edtcity;
    Button btnregister;
    TextView txtregister;
    ImageView imgregister,passwordtoggle,confirmpasswordtoggle;
    ProgressBar progressBar;
    RadioButton radiomale,radiofemale;
    RadioGroup radiogroupgender;
    Spinner spinnerstate;
    private String encodedImage,gender;
    private PrefrenceManager prefrenceManager;
    Uri imageurl;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupactivity);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        context = this;
        edtemail = findViewById(R.id.edt_email);
        edtname = findViewById(R.id.edt_name);
        edtpassword = findViewById(R.id.edt_password);
        edtcontact = findViewById(R.id.edt_contact);
        edtconfirmpassword = findViewById(R.id.edt_confirm_password);
        spinnerstate = findViewById(R.id.spinner_state);
        edtcity = findViewById(R.id.edt_city);
        btnregister = findViewById(R.id.btn_register);
        txtregister = findViewById(R.id.tt_Register);
        imgregister = findViewById(R.id.img_register);
        progressBar = findViewById(R.id.progressbar);
        radiogroupgender = findViewById(R.id.radioGroupGender);
        radiomale = findViewById(R.id.radioGenderMale);
        radiofemale = findViewById(R.id.radioGenderFemale);
        passwordtoggle = findViewById(R.id.password_toggle);
        confirmpasswordtoggle = findViewById(R.id.confirm_password_toggle);
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
        confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);

        passwordtoggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    edtpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    passwordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
                    edtpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        confirmpasswordtoggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtconfirmpassword.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_off_24);
                    edtconfirmpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                    confirmpasswordtoggle.setImageResource(R.drawable.ic_baseline_visibility_24);
                    edtconfirmpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        txtregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Signupactivity.this, SignInactivity.class));
            }
        });
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isValidSignUpDetails()){
                    if(radiomale.isChecked()){
                        gender = "Male";
                    }
                   else if(radiofemale.isChecked()){
                        gender = "Female";
                    }
                    isalreadyregister();
                }
            }
        });
        imgregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                pickImage.launch(intent);
            }
        });
    }

    private void performCrop(Uri picUri) {
        try {
            Intent cropIntent = new Intent("com.android.camera.action.CROP");
            // indicate image type and Uri
            cropIntent.setDataAndType(picUri, "image/*");
            // set crop properties here
            cropIntent.putExtra("crop", true);
            // indicate aspect of desired crop
            cropIntent.putExtra("aspectX", 1);
            cropIntent.putExtra("aspectY", 1);
            // indicate output X and Y
            cropIntent.putExtra("outputX", 128);
            cropIntent.putExtra("outputY", 128);
            // retrieve data on return
            cropIntent.putExtra("return-data", true);
            // start the activity - we handle returning in onActivityResult
            startActivityForResult(cropIntent, PIC_CROP);
        }
        // respond to users whose devices do not support the crop action
        catch (ActivityNotFoundException anfe) {
            // display an error message
            String errorMessage = "Whoops - your device doesn't support the crop action!";
            Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    private void signUp() {
        loading(true);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
        String currentdatetime = sdf.format(new Date());
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        HashMap<String,Object> user = new HashMap<>();
        user.put(Constants.KEY_NAME,edtname.getText().toString());
        user.put(Constants.KEY_EMAIL,edtemail.getText().toString());
        user.put(Constants.KEY_PASSWORD,edtpassword.getText().toString());
        user.put(Constants.KEY_CITY,edtcity.getText().toString());
        user.put(Constants.KEY_STATE,spinnerstate.getSelectedItem().toString());
        user.put(Constants.KEY_CONTACT_NO,edtcontact.getText().toString());
        user.put(Constants.KEY_GENDER,gender);
        user.put(Constants.KEY_IMAGE,encodedImage);
        user.put(Constants.KEY_CURRENT_DATE_TIME,currentdatetime);
        database.collection(Constants.KEY_COLLECTION_USERS)
        .add(user)
         .addOnSuccessListener(documentReference -> {
            loading(false);
            prefrenceManager.putString(Constants.KEY_USER_ID,documentReference.getId());
            prefrenceManager.putString(Constants.KEY_NAME,edtname.getText().toString());
            prefrenceManager.putString(Constants.KEY_GENDER,gender);
            prefrenceManager.putString(Constants.KEY_EMAIL,edtemail.getText().toString());
            prefrenceManager.putString(Constants.KEY_IMAGE,encodedImage);
            prefrenceManager.putString(Constants.KEY_CONTACT_NO,edtcontact.getText().toString());
            prefrenceManager.putString(Constants.KEY_STATE,spinnerstate.getSelectedItem().toString());
            prefrenceManager.putString(Constants.KEY_CITY,edtcity.getText().toString());
             Intent i = new Intent(getApplicationContext(), SignInactivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
             startActivity(i);
         })
         .addOnFailureListener(exception -> {
            loading(false);
             Toast.makeText(this, exception.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private String encodeImage(Bitmap bitmap){
        int previewWidth = 150;
        int previewHeight = bitmap.getHeight()*previewWidth/bitmap.getWidth();
        Bitmap previewBitmap = Bitmap.createScaledBitmap(bitmap,previewWidth,previewHeight,false);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        previewBitmap.compress(Bitmap.CompressFormat.JPEG,50,byteArrayOutputStream);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(bytes,Base64.DEFAULT);
    }

    private final ActivityResultLauncher<Intent> pickImage = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK){
                  if(result.getData() != null){
                      imageurl = result.getData().getData();
                      showdialog();
                  }
                }
            }
    );

    private Boolean isValidSignUpDetails() {
        if (encodedImage == null) {
            Toast.makeText(this, "Please Choose image", Toast.LENGTH_SHORT).show();
            return false;
        } else if (edtname.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please Enter name", Toast.LENGTH_SHORT).show();
            return false;
        }else if(edtcontact.getText().toString().isEmpty()){
            edtcontact.setError("Enter Mobile no");
           return  false;
        } else if (edtpassword.getText().toString().equals(edtconfirmpassword.getText().toString().isEmpty())) {
           edtconfirmpassword.setError("password doesn't match");
            return false;
        } else if (edtemail.getText().toString().isEmpty()) {
            edtemail.setError("Please Enter Email");
            return false;
        } else if (edtcity.getText().toString().isEmpty()) {
            edtcity.setError("Please Enter City");
            return false;
        }else {
            return  true;
        }
    }
    public void isalreadyregister(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .whereEqualTo(Constants.KEY_EMAIL,edtemail.getText().toString())
                .get()
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful() && task.getResult() != null &&
                            task.getResult().getDocuments().size() >0){
                        Toast.makeText(getApplicationContext(),"Already registered",Toast.LENGTH_SHORT).show();
                    }else{
                        checkmobile();
                    }
                });
    }
    public void  checkmobile(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .whereEqualTo(Constants.KEY_CONTACT_NO,edtcontact.getText().toString())
                .get()
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful() && task.getResult() != null &&
                            task.getResult().getDocuments().size() >0){
                        Toast.makeText(getApplicationContext(),"Already registered",Toast.LENGTH_SHORT).show();
                    }else{
                        signUp();
                    }
                });
    }
    public  void loading(Boolean isloading){
        if(isloading){
            btnregister.setVisibility(View.INVISIBLE);
            progressBar.setVisibility(View.VISIBLE);
        }else{
            btnregister.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    public  void showdialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage("Are You want to crop image ?");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        performCrop(imageurl);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        try{
                            InputStream inputStream = getContentResolver().openInputStream(imageurl);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            imgregister.setImageBitmap(bitmap);
                            encodedImage = encodeImage(bitmap);
                        }catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PIC_CROP) {
            if (data != null) {
                // get the returned data
                Bundle extras = data.getExtras();
                // get the cropped bitmap
                Bitmap selectedBitmap = extras.getParcelable("data");

                imgregister.setImageBitmap(selectedBitmap);
                encodedImage = encodeImage(selectedBitmap);
            }
        }
    }
}