package com.example.chatapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.chatapp.R;
import com.example.chatapp.fragments.FavouriteFragment;
import com.example.chatapp.fragments.PostsFragment;

public class MyPostActivity extends AppCompatActivity {

    RadioButton postsbtn,favouritebtn;
    FrameLayout mypostframe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_post);

        postsbtn = findViewById(R.id.post_mypost);
        favouritebtn = findViewById(R.id.favorite);
        mypostframe =findViewById(R.id.framemypost);

        PostsFragment mFragment = null;
        mFragment = new PostsFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.framemypost, mFragment).commit();

        postsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PostsFragment mFragment = null;
                mFragment = new PostsFragment();
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction()
                        .replace(R.id.framemypost, mFragment).commit();

            }
        });

        favouritebtn.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                FavouriteFragment mFragment = null;
                mFragment = new FavouriteFragment();
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction()
                        .replace(R.id.framemypost, mFragment).commit();

            }
        });

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(),HomeActivity.class);
        startActivity(i);
    }
}