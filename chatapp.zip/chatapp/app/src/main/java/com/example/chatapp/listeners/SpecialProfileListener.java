package com.example.chatapp.listeners;

import com.example.chatapp.models.SpecialProfile;

public interface SpecialProfileListener {
     void onSpecialProfileClicked(SpecialProfile specialProfile);
}
