package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.razorpay.Checkout;
import com.razorpay.Order;
import com.razorpay.PaymentResultListener;
import com.razorpay.RazorpayClient;
import org.json.JSONException;
import org.json.JSONObject;

public class PaymentActivity extends AppCompatActivity implements PaymentResultListener {

    PrefrenceManager prefrenceManager;
    int amount;
    String validity,type,samount,special;
    CardView card90,  card180, card365,cardspecial90,cardspecial180,cardspecial365;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        card90 = findViewById(R.id.card90);
        card180 = findViewById(R.id.card180);
        card365 = findViewById(R.id.card365);
        cardspecial90 = findViewById(R.id.cardspecial90);
        cardspecial180 = findViewById(R.id.cardspecial180);
        cardspecial365 = findViewById(R.id.cardspecial365);
        type = getIntent().getExtras().getString("type");
        prefrenceManager = new PrefrenceManager(getApplicationContext());


        card90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                samount = "1500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"90");
                validity = "90";
                payment();
            }
        });
        card180.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                samount = "2500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"180");
                validity = "180";
                payment();
            }
        });
        card365.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                samount = "4500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"365");
                validity = "365";
                payment();
            }
        });
        cardspecial90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                samount = "2500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"90");
                prefrenceManager.putString(Constants.KEY_SPECIAL,"special");
                validity = "90";
                special = "special";
                payment();
            }
        });
        cardspecial180.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                samount = "4500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"180");
                prefrenceManager.putString(Constants.KEY_SPECIAL,"special");
                validity = "180";
                special = "special";
                payment();
            }
        });
        cardspecial365.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                samount = "7500";
                amount = Math.round(Float.parseFloat(samount) * 100);
                prefrenceManager.putString(Constants.KEY_VALIDITY,"180");
                prefrenceManager.putString(Constants.KEY_SPECIAL,"special");
                validity = "365";
                special = "special";
                payment();
            }
        });
    }

    private void payment() {
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_qpZvVP1h7nZxeT");
        checkout.setImage(R.drawable.img_logo_1000);
        JSONObject object = new JSONObject();

        try {
            object.put("name",prefrenceManager.getString(Constants.KEY_NAME));
            object.put("description","Kushwah Matrimonial");
            object.put("theme.color","#0093DD");
            object.put("amount",amount);
            object.put("currency","INR");
            object.put("prefill.contact",prefrenceManager.getString(Constants.KEY_CONTACT_NO));
            object.put("prefill.email",prefrenceManager.getString(Constants.KEY_EMAIL));
            checkout.open(PaymentActivity.this,object);
        } catch (JSONException e) {
            Toast.makeText(PaymentActivity.this,"Payment Failed",Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onPaymentSuccess(String s) {
        Toast.makeText(PaymentActivity.this, "Payment Successfull", Toast.LENGTH_SHORT).show();
        prefrenceManager.putString(Constants.PAYMENT,"success");
        if (type.equals("post")) {
            Intent intent = new Intent();
            intent.putExtra(Constants.KEY_VALIDITY,validity);
            if(special != null){
                intent.putExtra(Constants.KEY_SPECIAL,special);
            }
            intent.putExtra(Constants.PAYMENT,"done");
            setResult(RESULT_OK, intent);
            finish();
            }
        if (type.equals("advertisement")) {
            Intent intent = new Intent();
            intent.putExtra(Constants.KEY_VALIDITY, validity);
            if (special != null) {
                intent.putExtra(Constants.KEY_SPECIAL, special);
            }
            intent.putExtra(Constants.PAYMENT, "done");
            setResult(RESULT_OK, intent);
            finish();
        }
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(PaymentActivity.this, "Payment Failed due to error : " + s, Toast.LENGTH_SHORT).show();

    }
}