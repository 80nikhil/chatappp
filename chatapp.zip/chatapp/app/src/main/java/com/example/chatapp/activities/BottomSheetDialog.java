package com.example.chatapp.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.razorpay.Checkout;
import com.razorpay.Order;
import com.razorpay.PaymentResultListener;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BottomSheetDialog extends BottomSheetDialogFragment {

    PrefrenceManager prefrenceManager;

    @Override
        public View onCreateView(LayoutInflater inflater, @Nullable
                ViewGroup container, @Nullable Bundle savedInstanceState)
        {
            View v = inflater.inflate(R.layout.custom_dialog,
                    container, false);

          RelativeLayout layoutprofile = v.findViewById(R.id.layout_profile);
          RelativeLayout layoutadvertisement = v.findViewById(R.id.layout_advertise);
          ImageView crossbtn = v.findViewById(R.id.crossbtn);
          prefrenceManager = new PrefrenceManager(v.getContext());

          crossbtn.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                dismiss();
              }
          });

            layoutprofile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    if(prefrenceManager.getString(Constants.PAYMENT) == null){
//                        Intent i = new Intent(getActivity(), PaymentActivity.class);
//                        i.putExtra("type", "post");
//                        startActivity(i);
//                    }else {
//                        Intent i = new Intent(getActivity(),PostActivity.class);
//                        i.putExtra(Constants.KEY_VALIDITY,prefrenceManager.getString(Constants.KEY_VALIDITY));
//                        if(prefrenceManager.getString(Constants.KEY_SPECIAL) == null){
//                            i.putExtra(Constants.KEY_SPECIAL,"null");
//                        }else{
//                            i.putExtra(Constants.KEY_SPECIAL,prefrenceManager.getString(Constants.KEY_SPECIAL));
//                        }
//                        startActivity(i);
//                    }
                    Intent i = new Intent(getActivity(),PostActivity.class);
                    prefrenceManager.putString("activitytype","base");
                    startActivity(i);
                }
            });

            layoutadvertisement.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    if(prefrenceManager.getString(Constants.PAYMENT) == null){
//                        Intent i = new Intent(getActivity(), PaymentActivity.class);
//                        i.putExtra("type", "advertisement");
//                        startActivity(i);
//                    }else {
//                        Intent i = new Intent(getActivity(),PostAdvertisementActivity.class);
//                        i.putExtra(Constants.KEY_VALIDITY,prefrenceManager.getString(Constants.KEY_VALIDITY));
//                        if(prefrenceManager.getString(Constants.KEY_SPECIAL) == null){
//                            i.putExtra(Constants.KEY_SPECIAL,"null");
//                        }else{
//                            i.putExtra(Constants.KEY_SPECIAL,prefrenceManager.getString(Constants.KEY_SPECIAL));
//                        }
//                        startActivity(i);
//                    }
                    startActivity(new Intent(getActivity(),PostAdvertisementActivity.class));
                }
            });
            return v;
        }
}
