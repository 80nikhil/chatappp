package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import com.example.chatapp.R;

public class SupportActivity extends AppCompatActivity {
WebView mywebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

        mywebview = findViewById(R.id.mywebview);
        mywebview.loadUrl("https://kushwahasamajshubhvivah.com/contact");
        mywebview.getSettings().setDomStorageEnabled(true);
        mywebview.getSettings().setJavaScriptEnabled(true);
    }
}