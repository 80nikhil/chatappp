package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.PersistentBag;
import com.example.chatapp.R;
import com.example.chatapp.models.FavouriteModal;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.models.User;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.BuildConfig;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jsibbold.zoomage.ZoomageView;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class PostProfileDetailActivity extends AppCompatActivity {

    ImageView  Backbtn,sharebtn;
    ZoomageView postimage;
    RoundedImageView recieverimage;
    Button startcall1,startcall2,fav1,fav2;
    Context context;
    private FirebaseFirestore database;
    PrefrenceManager prefrenceManager;
    private Profile Profileuser,Profiledateofbirth ,Profilefirstname,Profilemiddlename,Profilelastname,
                    Profileimage,Profilegender,Profilefathername,Profilemothername,Profilecurrentadress,
                    Profilehometownaddress,Profiledescription,Profilemanglik,Profiledivorced,Profileallowcall,
                    Profileiswidow,Profilebrothers,Profilesisters,Profilemonthlyincome,Profileoccupation,
                    Profileeducation,Profilecast,Profileweight,Profileheightinch,Profileheightfeet,
                    Profilemotheroccupation, Profilefatheroccupation,ProfileCurrentDateTime,
                    Profilecontactno,ProfileRecieverid,ProfileFcmToken,Profilecity,Profilestate,Profilevaidity;
    private SpecialProfile SProfileuser,SProfiledateofbirth ,SProfilefirstname,SProfilemiddlename,SProfilelastname,
                            SProfileimage,SProfilegender,SProfilefathername,SProfilemothername,SProfilecurrentadress,
                            SProfilehometownaddress,SProfiledescription,SProfilemanglik,SProfiledivorced,SProfileallowcall,
                            SProfileiswidow,SProfilebrothers,SProfilesisters,SProfilemonthlyincome,SProfileoccupation,
                            SProfileeducation,SProfilecast,SProfileweight,SProfileheightinch,SProfileheightfeet,
                            SProfilemotheroccupation, SProfilefatheroccupation,SProfileCurrentDateTime,
                            SProfilecontactno,SProfileRecieverid,SProfileFcmToken,SProfilecity,SProfilestate,SProfilevaidity;
    TextView textname,dateofbirth,gender,cast,manglik,address,
             fullname,dob,city,ismanglik,height,weight,religion,
             education,occupation,monthlyincome,fatheroccupation,fathername,
             mothername,motheroccupation,sister,brother,widodivo,description,textdatetime,contactno,textrecievername,hgt;
    String chattoken,chatrecieverimage,chatrecivername,Schattoken,Schatrecieverimage,
            Schatrecivername,no,special,favencoded,validity,recieverid,id,mactivity,postid;
    ImageView favourite;
    RelativeLayout rluser;
    private  ArrayList<FavouriteModal> courseModalArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_profile_detail);

        context = this;
        postimage = findViewById(R.id.postimage);
        textname = findViewById(R.id.textname);
        dateofbirth = findViewById(R.id.dateofbirth);
        gender = findViewById(R.id.gender);
        cast = findViewById(R.id.cast);
        manglik = findViewById(R.id.manglik);
        address = findViewById(R.id.address);
        fullname = findViewById(R.id.fullname);
        dob = findViewById(R.id.dob);
        Backbtn = findViewById(R.id.backbtn);
        city = findViewById(R.id.city);
        ismanglik = findViewById(R.id.ismanglik);
        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);
        religion = findViewById(R.id.religion);
        education = findViewById(R.id.education);
        occupation = findViewById(R.id.occupation);
        monthlyincome = findViewById(R.id.monthlyincome);
        fatheroccupation = findViewById(R.id.fatheroccupation);
        fathername = findViewById(R.id.fathername);
        mothername = findViewById(R.id.mothername);
        motheroccupation = findViewById(R.id.motheroccupation);
        sister = findViewById(R.id.sister);
        brother = findViewById(R.id.brother);
        widodivo = findViewById(R.id.widowdivo);
        description = findViewById(R.id.description);
        textdatetime = findViewById(R.id.textDateTime);
        startcall1 = findViewById(R.id.btn_call);
        startcall2 = findViewById(R.id.btn_call2);
        fav1 = findViewById(R.id.btn_markFev1);
        fav2 = findViewById(R.id.btn_markFev);
        sharebtn = findViewById(R.id.btn_share);
        contactno = findViewById(R.id.contactno);
        recieverimage = findViewById(R.id.profile_post_image);
        textrecievername = findViewById(R.id.profile_post_name);
        favourite = findViewById(R.id.fevBtn);
        rluser = findViewById(R.id.rluser);
        hgt = findViewById(R.id.hgt);

        prefrenceManager = new PrefrenceManager(getApplicationContext());
        database = FirebaseFirestore.getInstance();

        special = getIntent().getExtras().getString(Constants.KEY_SPECIAL);
        validity = getIntent().getExtras().getString(Constants.KEY_VALIDITY);
        mactivity = getIntent().getExtras().getString(Constants.KEY_ACTIVITY);


        if(special.equals("special")){
            loadSpecialProfileDetails();
        }if(special.equals("null")){
            loadProfileDetails();
        }
        loaddata();
        favourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              addfavorite();
            }
        });
        fav1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addfavorite();
            }
        });
        fav2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addfavorite();
            }
        });

        Backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (mactivity.equals("boy")) {
                        startActivity(new Intent(getApplicationContext(), BoyActivity.class));
                    } else if (mactivity.equals("girl")) {
                        startActivity(new Intent(getApplicationContext(), GirlActivity.class));
                    } else if (mactivity.equals("divorce")) {
                        startActivity(new Intent(getApplicationContext(), DivorcedActivity.class));
                    } else if (mactivity.equals("widow")) {
                        startActivity(new Intent(getApplicationContext(), WidowActivity.class));
                    }else if(mactivity.equals("home")){
                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                    }
//                onBackPressed();

            }
        });
        startcall1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(special.equals("special")){
                    Intent i = new Intent(PostProfileDetailActivity.this,ProfileChat.class);
                    i.putExtra(Constants.KEY_USER_ID,SProfileRecieverid.profilerecieverid);
                    i.putExtra(Constants.KEY_IMAGE,Schatrecieverimage);
                    i.putExtra(Constants.KEY_NAME,Schatrecivername);
                    i.putExtra(Constants.KEY_FCM_TOKEN,Schattoken);
                    i.putExtra(Constants.KEY_MESSAGE,"I want to chat for"+SProfilefirstname.firstname+" "+SProfilemiddlename.middlename+" "+SProfilelastname.lastname);
                    startActivity(i);
                }else {
                    Intent i = new Intent(PostProfileDetailActivity.this, ProfileChat.class);
                    i.putExtra(Constants.KEY_USER_ID, ProfileRecieverid.profilerecieverid);
                    i.putExtra(Constants.KEY_IMAGE, chatrecieverimage);
                    i.putExtra(Constants.KEY_NAME, chatrecivername);
                    i.putExtra(Constants.KEY_FCM_TOKEN, chattoken);
                    i.putExtra(Constants.KEY_MESSAGE, "I want to chat for" + Profilefirstname.firstname + " " + Profilemiddlename.middlename + " " + Profilelastname.lastname);
                    startActivity(i);
                }
            }
        });
        startcall2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(no==null){
                    Toast.makeText(getApplicationContext(),"Call is Not Allowed",Toast.LENGTH_LONG).show();
                }else{
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    String temp = "tel:" + no;
                    intent.setData(Uri.parse(temp));
                    startActivity(intent);
                }
            }
        });
        sharebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                    String shareMessage= "\nHey, I found a marriage profile.For looking the profile download\n6666669";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +"\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch(Exception e) {
                    Toast.makeText(getApplicationContext(),"an error occured",Toast.LENGTH_SHORT).show();
                }
            }
        });
        rluser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Chatprofileinfo.class);
                i.putExtra(Constants.KEY_RECIEVER_ID,postid);
                startActivity(i);
            }
        });
    }

    private void loaddata() {
        if(prefrenceManager.getString(id) != null) {
            favourite.setImageResource(R.drawable.ic_baseline_favorite_24);
        }
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();

        String json = sharedPreferences.getString("courses", null);
        Type type = new TypeToken<ArrayList<FavouriteModal>>() {}.getType();

        courseModalArrayList = gson.fromJson(json, type);
        if (courseModalArrayList == null) {
            courseModalArrayList = new ArrayList<>();
        }
        }


    private void loadSpecialProfileDetails() {
        SProfileuser = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE);
        SProfiledateofbirth = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_DATEOFBIRTH);
        SProfilefirstname = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_FIRST_NAME);
        SProfilemiddlename = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_MIDDLE_NAME);
        SProfilelastname = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_LAST_NAME);
        SProfileimage = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_POST_IMAGE);
        SProfilegender = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_GENDER);
        SProfilefathername = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_FATHER_NAME);
        SProfilemothername = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_MOTHER_NAME);
        SProfilecurrentadress = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_CURRENT_ADDRESS);
        SProfilehometownaddress = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_HOMETOWN_ADDRESS);
        SProfiledescription = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_DESCRIPTION);
        SProfilemanglik = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_IS_MANGLIK);
        SProfiledivorced = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_IS_DIVORCED);
        SProfileallowcall = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_ALLOW_CALL);
        SProfileiswidow = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_IS_WIDOW);
        SProfilesisters = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_SELECT_SISTER);
        SProfilebrothers = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_SELECT_BROTHER);
        SProfilemonthlyincome = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_MONTHLY_INCOME);
        SProfileoccupation = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_SELECT_OCCUPATION);
        SProfileeducation = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_SELECT_EDUCATION);
        SProfilecast = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_CAST);
        SProfileweight = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_WEIGHT);
        SProfileheightinch = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_HEIGHT_INCHES);
        SProfileheightfeet = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_HEIGHT_FEET);
        SProfilemotheroccupation = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_MOTHER_OCCUPATION);
        SProfilefatheroccupation = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_FATHER_OCCUPATION);
        SProfileCurrentDateTime = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_CURRENT_DATE_TIME);
        SProfilecontactno = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_CONTACT_NO);
        SProfileRecieverid = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_RECIEVER_ID);
        SProfileFcmToken = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_FCM_TOKEN);
        SProfilecity = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_CITY);
        SProfilestate = (SpecialProfile) getIntent().getSerializableExtra(Constants.KEY_STATE);
        dateofbirth.setText(SProfiledateofbirth.dateofbirth);
        dob.setText(SProfiledateofbirth.dateofbirth);
        textname.setText(SProfilefirstname.firstname+" "+SProfilemiddlename.middlename+" "+SProfilelastname.lastname);
        gender.setText(SProfilegender.gender);
        cast.setText(SProfilecast.cast);
        address.setText(SProfilecity.city+","+SProfilestate.state);
        fullname.setText(SProfilefirstname.firstname+" "+SProfilemiddlename.middlename+" "+SProfilelastname.lastname);
        city.setText(SProfilecurrentadress.currentadress);
        height.setText(SProfileheightfeet.heightfeet+" "+SProfileheightinch.heightinch);
        weight.setText(SProfileweight.weight);
        education.setText(SProfileeducation.education);
        occupation.setText(SProfileoccupation.occupation);
        monthlyincome.setText(SProfilemonthlyincome.monthlyincome);
        fatheroccupation.setText(SProfilefatheroccupation.fatheroccupation);
        fathername.setText(SProfilefathername.fathername);
        mothername.setText(SProfilemothername.mothername);
        motheroccupation.setText(SProfilemotheroccupation.motheroccupation);
        sister.setText(SProfilesisters.sisters);
        brother.setText(SProfilebrothers.brothers);
        widodivo.setText(SProfileiswidow.iswidow+"/"+SProfiledivorced.divorced);
        description.setText(SProfiledescription.description);
        textdatetime.setText(SProfileCurrentDateTime.currentDateandTime);
        hgt.setText(SProfileheightfeet.heightfeet+" "+SProfileheightinch.heightinch);
        postid = SProfileRecieverid.profilerecieverid;
        manglik.setText(SProfilemanglik.manglik);
        if(SProfilemanglik.manglik.equals("yes")){
            ismanglik.setText("manglik");
        }else{
            ismanglik.setText("not-manglik");
        }
        if(SProfileallowcall.allowcall.equals("Yes")){
            contactno.setText(SProfilecontactno.contactno);
            no = SProfilecontactno.contactno;
        }
        favencoded = SProfileimage.profileimage;
        id = SProfileFcmToken.fcmtoken;
        getSpecialData();
            if (mactivity.equals("boy")) {
                getboySpecialimage();
            } else if (mactivity.equals("girl")) {
                getgirlSpecialimage();
            } else if (mactivity.equals("divorce")) {
                getdivorceSpecialimage();
            } else if (mactivity.equals("widow")) {
                getwidowSpecialimage();
            }else if(mactivity.equals("home")){
                getSpecialimage();
            }
    }

    private void loadProfileDetails() {
        Profileuser = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE);
        Profiledateofbirth = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_DATEOFBIRTH);
        Profilefirstname = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_FIRST_NAME);
        Profilemiddlename = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_MIDDLE_NAME);
        Profilelastname = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_LAST_NAME);
        Profileimage = (Profile) getIntent().getSerializableExtra(Constants.KEY_POST_IMAGE);
        Profilegender = (Profile) getIntent().getSerializableExtra(Constants.KEY_GENDER);
        Profilefathername = (Profile) getIntent().getSerializableExtra(Constants.KEY_FATHER_NAME);
        Profilemothername = (Profile) getIntent().getSerializableExtra(Constants.KEY_MOTHER_NAME);
        Profilecurrentadress = (Profile) getIntent().getSerializableExtra(Constants.KEY_CURRENT_ADDRESS);
        Profilehometownaddress = (Profile) getIntent().getSerializableExtra(Constants.KEY_HOMETOWN_ADDRESS);
        Profiledescription = (Profile) getIntent().getSerializableExtra(Constants.KEY_DESCRIPTION);
        Profilemanglik = (Profile) getIntent().getSerializableExtra(Constants.KEY_IS_MANGLIK);
        Profiledivorced = (Profile) getIntent().getSerializableExtra(Constants.KEY_IS_DIVORCED);
        Profileallowcall = (Profile) getIntent().getSerializableExtra(Constants.KEY_ALLOW_CALL);
        Profileiswidow = (Profile) getIntent().getSerializableExtra(Constants.KEY_IS_WIDOW);
        Profilesisters = (Profile) getIntent().getSerializableExtra(Constants.KEY_SELECT_SISTER);
        Profilebrothers = (Profile) getIntent().getSerializableExtra(Constants.KEY_SELECT_BROTHER);
        Profilemonthlyincome = (Profile) getIntent().getSerializableExtra(Constants.KEY_MONTHLY_INCOME);
        Profileoccupation = (Profile) getIntent().getSerializableExtra(Constants.KEY_SELECT_OCCUPATION);
        Profileeducation = (Profile) getIntent().getSerializableExtra(Constants.KEY_SELECT_EDUCATION);
        Profilecast = (Profile) getIntent().getSerializableExtra(Constants.KEY_CAST);
        Profileweight = (Profile) getIntent().getSerializableExtra(Constants.KEY_WEIGHT);
        Profileheightinch = (Profile) getIntent().getSerializableExtra(Constants.KEY_HEIGHT_INCHES);
        Profileheightfeet = (Profile) getIntent().getSerializableExtra(Constants.KEY_HEIGHT_FEET);
        Profilemotheroccupation = (Profile) getIntent().getSerializableExtra(Constants.KEY_MOTHER_OCCUPATION);
        Profilefatheroccupation = (Profile) getIntent().getSerializableExtra(Constants.KEY_FATHER_OCCUPATION);
        ProfileCurrentDateTime = (Profile) getIntent().getSerializableExtra(Constants.KEY_CURRENT_DATE_TIME);
        Profilecontactno = (Profile) getIntent().getSerializableExtra(Constants.KEY_CONTACT_NO);
        ProfileRecieverid = (Profile) getIntent().getSerializableExtra(Constants.KEY_PROFILE_RECIEVER_ID);
        ProfileFcmToken = (Profile) getIntent().getSerializableExtra(Constants.KEY_FCM_TOKEN);
        Profilecity = (Profile) getIntent().getSerializableExtra(Constants.KEY_CITY);
        Profilestate = (Profile) getIntent().getSerializableExtra(Constants.KEY_STATE);
        dateofbirth.setText(Profiledateofbirth.dateofbirth);
        dob.setText(Profiledateofbirth.dateofbirth);
        textname.setText(Profilefirstname.firstname+" "+Profilemiddlename.middlename+" "+Profilelastname.lastname);
        gender.setText(Profilegender.gender);
        cast.setText(Profilecast.cast);
        address.setText(Profilecity.city+","+Profilestate.state);
        fullname.setText(Profilefirstname.firstname+" "+Profilemiddlename.middlename+" "+Profilelastname.lastname);
        city.setText(Profilecurrentadress.currentadress);
        height.setText(Profileheightfeet.heightfeet+" "+Profileheightinch.heightinch);
        weight.setText(Profileweight.weight);
        education.setText(Profileeducation.education);
        occupation.setText(Profileoccupation.occupation);
        monthlyincome.setText(Profilemonthlyincome.monthlyincome);
        fatheroccupation.setText(Profilefatheroccupation.fatheroccupation);
        fathername.setText(Profilefathername.fathername);
        mothername.setText(Profilemothername.mothername);
        motheroccupation.setText(Profilemotheroccupation.motheroccupation);
        sister.setText(Profilesisters.sisters);
        brother.setText(Profilebrothers.brothers);
        widodivo.setText(Profileiswidow.iswidow+"/"+Profiledivorced.divorced);
        description.setText(Profiledescription.description);
        textdatetime.setText(ProfileCurrentDateTime.currentDateandTime);
        hgt.setText(Profileheightfeet.heightfeet+" "+Profileheightinch.heightinch);
        postid = ProfileRecieverid.profilerecieverid;
        manglik.setText(Profilemanglik.manglik);
        if(Profilemanglik.manglik.equals("yes")){
            ismanglik.setText("manglik");
        }else{
            ismanglik.setText("not-manglik");
        }
//        postimage.setImageBitmap(getProfileImage(Profileimage.profileimage));
        favencoded = Profileimage.profileimage;
        id = ProfileFcmToken.fcmtoken;
        if(Profileallowcall.allowcall.equals("Yes")){
           contactno.setText(Profilecontactno.contactno);
           no = Profilecontactno.contactno;
        }
        getData();
            if (mactivity.equals("boy")) {
                getboySpecialimage();
            } else if (mactivity.equals("girl")) {
                getgirlSpecialimage();
            } else if (mactivity.equals("divorce")) {
                getdivorceSpecialimage();
            } else if (mactivity.equals("widow")) {
                getwidowSpecialimage();
            }else if(mactivity.equals("home")){
                getimage();
            }
    }

    private void getimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = ProfileRecieverid.fcmtoken;
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }

    private void getSpecialimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .document( SProfileRecieverid.fcmtoken)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = SProfileRecieverid.profilerecieverid;
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }


    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
        }

    private void getData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
                .document(ProfileRecieverid.profilerecieverid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        chatrecieverimage = documentSnapshot.getString(Constants.KEY_IMAGE);
                        chatrecivername = documentSnapshot.getString(Constants.KEY_NAME);
                        textrecievername.setText(chatrecivername);
                        byte[] bytes = Base64.decode(chatrecieverimage,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        recieverimage.setImageBitmap(bitmap);
                        chattoken = documentSnapshot.getString(Constants.KEY_FCM_TOKEN);
                    }
                });
    }
    private void getSpecialData() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_COLLECTION_USERS)
            .document( SProfileRecieverid.profilerecieverid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
        @Override
        public void onSuccess(DocumentSnapshot documentSnapshot) {
            Schatrecieverimage = documentSnapshot.getString(Constants.KEY_IMAGE);
            Schatrecivername = documentSnapshot.getString(Constants.KEY_NAME);
            textrecievername.setText(Schatrecivername);
            byte[] bytes = Base64.decode(Schatrecieverimage,Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
            recieverimage.setImageBitmap(bitmap);
            Schattoken = documentSnapshot.getString(Constants.KEY_FCM_TOKEN);
        }
    });
   }
    private void getdivorceSpecialimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_DIVORCED)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }

    private void getgirlSpecialimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_GIRL)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }

    private void getboySpecialimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_BOY)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }

    private void getwidowSpecialimage() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_WIDOW)
                .document(id)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        recieverid = documentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                        byte[] bytes = Base64.decode(documentSnapshot.getString(Constants.KEY_POST_IMAGE2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
                        postimage.setImageBitmap(bitmap);
                    }
                });
    }

    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(courseModalArrayList);
        editor.putString("courses", json);
        editor.apply();
        Toast.makeText(this, "Added to favorite", Toast.LENGTH_SHORT).show();

    }
    private void addfavorite() {
        if(prefrenceManager.getString(id) == null) {
            favourite.setImageResource(R.drawable.ic_baseline_favorite_24);
            courseModalArrayList.add(new FavouriteModal(textname.getText().toString(), dateofbirth.getText().toString(),
                    education.getText().toString(), sister.getText().toString(), brother.getText().toString(),
                    cast.getText().toString(), textdatetime.getText().toString(), address.getText().toString(), favencoded, special, validity, id));
            prefrenceManager.putString(id,"favourite");
            saveData();
        }else{
            Toast.makeText(PostProfileDetailActivity.this, "Already addded in Favorite.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
            if (mactivity.equals("boy")) {
                startActivity(new Intent(getApplicationContext(), BoyActivity.class));
            } else if (mactivity.equals("girl")) {
                startActivity(new Intent(getApplicationContext(), GirlActivity.class));
            } else if (mactivity.equals("divorce")) {
                startActivity(new Intent(getApplicationContext(), DivorcedActivity.class));
            } else if (mactivity.equals("widow")) {
                startActivity(new Intent(getApplicationContext(), WidowActivity.class));
            }else if(mactivity.equals("home")){
                startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            }
    }
}