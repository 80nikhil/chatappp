package com.example.chatapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.R;
import com.example.chatapp.models.Category;

import java.util.ArrayList;

public class AdvertiseAdapter extends RecyclerView.Adapter<AdvertiseAdapter.ViewHolder>{

    ArrayList<Category> list;
    Context context;

    public AdvertiseAdapter(Context context, ArrayList<Category> list){
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public AdvertiseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View contactView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_category, parent, false);


        AdvertiseAdapter.ViewHolder viewHolder = new AdvertiseAdapter.ViewHolder(contactView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category currentItem = list.get(position);

        ImageView imageView = holder.subjectImageView;
        imageView.setImageResource(currentItem.getImageId());

        TextView subjectTextView = holder.subjectTextView;
        subjectTextView.setText(currentItem.getSubject());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(currentItem.getSubject() == "Boy") {
                    Toast.makeText(context,"Boy",Toast.LENGTH_SHORT).show();
                }else if(currentItem.getSubject() == "Girl") {
                    Toast.makeText(context,"Girl",Toast.LENGTH_SHORT).show();
                }else if(currentItem.getSubject() == "Widow") {
                    Toast.makeText(context,"Widow",Toast.LENGTH_SHORT).show();
                }else if(currentItem.getSubject() == "Divorced") {
                    Toast.makeText(context,"divorced",Toast.LENGTH_SHORT).show();
                }else if(currentItem.getSubject() == "Advertisement") {
                    Toast.makeText(context,"Advertisement",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView subjectImageView;
        public TextView subjectTextView;
        LinearLayout linearLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            subjectImageView = itemView.findViewById(R.id.imageCategoryIcon);
            subjectTextView = itemView.findViewById(R.id.textName);
            linearLayout = itemView.findViewById(R.id.linear_category);
        }
    }
}
