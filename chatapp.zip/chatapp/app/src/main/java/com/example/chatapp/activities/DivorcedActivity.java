package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.adapters.ProfileAdapter;
import com.example.chatapp.adapters.SpecialProfileAdapter;
import com.example.chatapp.databinding.ActivityDivorcedBinding;
import com.example.chatapp.listeners.ProfileListener;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.Profile;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DivorcedActivity extends AppCompatActivity implements ProfileListener {

    ProfileAdapter  profileAdapter;
    private ActivityDivorcedBinding binding;
    private PrefrenceManager prefrenceManager;
    ArrayList<Profile> profiles = new ArrayList<>();
    ArrayList<Advertisement> advertisements = new ArrayList<>();
    ArrayList<SpecialProfile> specialprofiles = new ArrayList<>();
    String city,adress,state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDivorcedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        prefrenceManager = new PrefrenceManager(getApplicationContext());
        try {
            city = getIntent().getExtras().getString(Constants.KEY_STATE);
            adress = getIntent().getExtras().getString(Constants.KEY_CURRENT_ADDRESS);
            state = getIntent().getExtras().getString(Constants.KEY_CITY);
        }catch (Exception e){
            e.printStackTrace();
        }
        if( city == null){
            getadvertisements();
            getspecial();
            binding.allDBtn.setBackgroundResource(R.drawable.gradient);
        }else {
            getlocationlist();
        }
        if(prefrenceManager.getString(Constants.KEY_STATE) != null){
            binding.hometxt.setText(prefrenceManager.getString(Constants.KEY_STATE));
            getlocationlist();
        }
        binding.allDBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.allDBtn.setBackgroundResource(R.drawable.gradient);
                binding.maleDBtn.setBackgroundResource(R.drawable.edittext_border);
                binding.femaleDBtn.setBackgroundResource(R.drawable.edittext_border);
                getadvertisements();
                getspecial();
//                Toast.makeText(DivorcedActivity.this, "all profile", Toast.LENGTH_SHORT).show();

            }
        });
        binding.maleDBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.maleDBtn.setBackgroundResource(R.drawable.gradient);
                binding.allDBtn.setBackgroundResource(R.drawable.edittext_border);
                binding.femaleDBtn.setBackgroundResource(R.drawable.edittext_border);
                getadvertisements();
                getspecialmale();
//                Toast.makeText(DivorcedActivity.this, "all male profile", Toast.LENGTH_SHORT).show();

            }
        });
        binding.femaleDBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.femaleDBtn.setBackgroundResource(R.drawable.gradient);
                binding.allDBtn.setBackgroundResource(R.drawable.edittext_border);
                binding.maleDBtn.setBackgroundResource(R.drawable.edittext_border);
                getspecialfemale();
                getadvertisements();
//                Toast.makeText(DivorcedActivity.this, "all female profile", Toast.LENGTH_SHORT).show();
            }
        });


        binding.map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefrenceManager.putString(Constants.KEY_SCREEN_ID,"divorce");
                Intent i = new Intent(DivorcedActivity.this, MapActivity.class);
                startActivity(i);
            }
        });
    }

    private void getspecial() {
        binding.progresshome.setVisibility(View.VISIBLE);
        binding.txtloading.setVisibility(View.VISIBLE);
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    if( specialprofile.special != null){
                                        if(specialprofile.divorced.equals("Yes")) {
                                            specialprofiles.add(specialprofile);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            SpecialProfileAdapter specialprofileAdapter = new SpecialProfileAdapter(specialprofiles, advertisements,this,this);
                            binding.specialprofilesrecycler.setAdapter(specialprofileAdapter);
                            binding.specialprofilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        getdivorceds();
    }
    private void getadvertisements() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();

        database.collection(Constants.KEY_POST_ADVERTISEMENT)
                .orderBy(Constants.KEY_CURRENT_DATE_TIME, Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Advertisement advertisement = new Advertisement();
                            advertisement.id = queryDocumentSnapshot.getId();
                            advertisement.advertiseimage = queryDocumentSnapshot.getString(Constants.KEY_ADVERTISE_IMAGE);
                            advertisement.titlename = queryDocumentSnapshot.getString(Constants.KEY_TITLE_NAME);
                            advertisement.ownername = queryDocumentSnapshot.getString(Constants.KEY_OWNER_NAME);
                            advertisement.ownercontact = queryDocumentSnapshot.getString(Constants.KEY_OWNER_CONTACT);
                            advertisement.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            advertisement.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            advertisement.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            advertisements.add(advertisement);
                        }
                        if (advertisements.size() > 0) {
                            ProfileAdapter profileAdapter = new ProfileAdapter(profiles, advertisements,this,this);
                            binding.divorcedrecycler.setAdapter(profileAdapter);
                            binding.divorcedrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
    }
    private void getdivorceds() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        for(QueryDocumentSnapshot queryDocumentSnapshot: task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = profile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(profile.validity);
                                if (differenceDates <= valid) {
                                    if (profile.special == null) {
                                        if(profile.divorced.equals("Yes")) {
                                            profiles.add(profile);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (profiles.size() > 0) {
                            ProfileAdapter  profileAdapter = new ProfileAdapter(profiles, advertisements, this,this);
                            binding.divorcedrecycler.setAdapter(profileAdapter);
                            binding.divorcedrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        binding.progresshome.setVisibility(View.GONE);
        binding.txtloading.setVisibility(View.GONE);
    }
    private void getlocationlist() {
        binding.hometxt.setText(city);
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_DIVORCED)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = profile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(profile.validity);
                                if (differenceDates <= valid) {
                                    if (profile.special == null) {
                                        if(profile.state.contains(city)) {
                                            profiles.add(profile);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (profiles.size() > 0) {
                            profileAdapter = new ProfileAdapter(profiles, advertisements, this,this);
                            binding.divorcedrecycler.setAdapter(profileAdapter);
                            binding.divorcedrecycler.setVisibility(View.VISIBLE);

                        } else {

                        }
                    } else {

                    }
                });
        database.collection(Constants.KEY_POST_DIVORCED)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    if (specialprofile.special != null) {
                                        if(specialprofile.state.contains(city)) {
                                            specialprofiles.add(specialprofile);
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            SpecialProfileAdapter specialprofileAdapter = new SpecialProfileAdapter(specialprofiles, advertisements, this,this);
                            binding.specialprofilesrecycler.setAdapter(specialprofileAdapter);
                            binding.specialprofilesrecycler.setVisibility(View.VISIBLE);
                        } else {
                            getspecial();
                            getadvertisements();
                        }
                    } else {

                    }
                });
    }
    private void getmale() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        for(QueryDocumentSnapshot queryDocumentSnapshot: task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = profile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(profile.validity);
                                if (differenceDates <= valid) {
                                    if (profile.special == null) {
                                        if(profile.gender.equals("Male")) {
                                            if(profile.divorced.equals("Yes")){
                                                profiles.add(profile);
                                            }
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (profiles.size() > 0) {
                            ProfileAdapter  profileAdapter = new ProfileAdapter(profiles, advertisements, this,this);
                            binding.divorcedrecycler.setAdapter(profileAdapter);
                            binding.divorcedrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
    }

    private void getspecialmale() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_SPECIAL)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    if( specialprofile.special != null){
                                        if(specialprofile.divorced.equals("Yes")) {
                                          if(specialprofile.gender.equals("Male")) {
                                                specialprofiles.add(specialprofile);
                                            }
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            SpecialProfileAdapter specialprofileAdapter = new SpecialProfileAdapter(specialprofiles, advertisements,this,this);
                            binding.specialprofilesrecycler.setAdapter(specialprofileAdapter);
                            binding.specialprofilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        getmale();
    }

    private void getspecialfemale() {
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult()) {
                            if (currentUserId.equals(queryDocumentSnapshot.getId())) {
                                continue;
                            }
                            SpecialProfile specialprofile = new SpecialProfile();
                            specialprofile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            specialprofile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            specialprofile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            specialprofile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            specialprofile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            specialprofile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            specialprofile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            specialprofile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            specialprofile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            specialprofile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            specialprofile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            specialprofile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            specialprofile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            specialprofile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            specialprofile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            specialprofile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            specialprofile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            specialprofile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            specialprofile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            specialprofile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            specialprofile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            specialprofile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            specialprofile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            specialprofile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            specialprofile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            specialprofile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            specialprofile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            specialprofile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            specialprofile.fcmtoken = queryDocumentSnapshot.getId();
                            specialprofile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            specialprofile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            specialprofile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            specialprofile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = specialprofile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(specialprofile.validity);
                                if (differenceDates <= valid) {
                                    if( specialprofile.special != null){
                                        if(specialprofile.divorced.equals("Yes")) {
                                           if(specialprofile.gender.equals("Female")) {
                                                specialprofiles.add(specialprofile);
                                            }
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (specialprofiles.size() > 0) {
                            SpecialProfileAdapter specialprofileAdapter = new SpecialProfileAdapter(specialprofiles, advertisements,this,this);
                            binding.specialprofilesrecycler.setAdapter(specialprofileAdapter);
                            binding.specialprofilesrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
        getfemale();
    }

    public void  getfemale(){
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        database.collection(Constants.KEY_POST_PROFILE)
                .orderBy(Constants.KEY_CITY, Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    String currentUserId = prefrenceManager.getString(Constants.KEY_USER_ID);
                    if(task.isSuccessful() && task.getResult() != null){
                        for(QueryDocumentSnapshot queryDocumentSnapshot: task.getResult()){
                            if(currentUserId.equals(queryDocumentSnapshot.getId())){
                                continue;
                            }
                            Profile profile = new Profile();
                            profile.firstname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_FIRST_NAME);
                            profile.lastname = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_LAST_NAME);
                            profile.profileimage = queryDocumentSnapshot.getString(Constants.KEY_POST_IMAGE2);
                            profile.middlename = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_MIDDLE_NAME);
                            profile.dateofbirth = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_DATEOFBIRTH);
                            profile.fathername = queryDocumentSnapshot.getString(Constants.KEY_FATHER_NAME);
                            profile.fatheroccupation = queryDocumentSnapshot.getString(Constants.KEY_FATHER_OCCUPATION);
                            profile.gender = queryDocumentSnapshot.getString(Constants.KEY_GENDER);
                            profile.mothername = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_NAME);
                            profile.motheroccupation = queryDocumentSnapshot.getString(Constants.KEY_MOTHER_OCCUPATION);
                            profile.weight = queryDocumentSnapshot.getString(Constants.KEY_WEIGHT);
                            profile.heightfeet = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_FEET);
                            profile.heightinch = queryDocumentSnapshot.getString(Constants.KEY_HEIGHT_INCHES);
                            profile.cast = queryDocumentSnapshot.getString(Constants.KEY_CAST);
                            profile.education = queryDocumentSnapshot.getString(Constants.KEY_SELECT_EDUCATION);
                            profile.occupation = queryDocumentSnapshot.getString(Constants.KEY_SELECT_OCCUPATION);
                            profile.monthlyincome = queryDocumentSnapshot.getString(Constants.KEY_MONTHLY_INCOME);
                            profile.sisters = queryDocumentSnapshot.getString(Constants.KEY_SELECT_SISTER);
                            profile.brothers = queryDocumentSnapshot.getString(Constants.KEY_SELECT_BROTHER);
                            profile.manglik = queryDocumentSnapshot.getString(Constants.KEY_IS_MANGLIK);
                            profile.divorced = queryDocumentSnapshot.getString(Constants.KEY_IS_DIVORCED);
                            profile.allowcall = queryDocumentSnapshot.getString(Constants.KEY_ALLOW_CALL);
                            profile.contactno = queryDocumentSnapshot.getString(Constants.KEY_CONTACT_NO);
                            profile.iswidow = queryDocumentSnapshot.getString(Constants.KEY_IS_WIDOW);
                            profile.currentadress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.hometownaddress = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_ADDRESS);
                            profile.description = queryDocumentSnapshot.getString(Constants.KEY_DESCRIPTION);
                            profile.currentDateandTime = queryDocumentSnapshot.getString(Constants.KEY_CURRENT_DATE_TIME);
                            profile.city = queryDocumentSnapshot.getString(Constants.KEY_CITY);
                            profile.state = queryDocumentSnapshot.getString(Constants.KEY_STATE);
                            profile.fcmtoken = queryDocumentSnapshot.getId();
                            profile.profilerecieverid = queryDocumentSnapshot.getString(Constants.KEY_PROFILE_RECIEVER_ID);
                            profile.special = queryDocumentSnapshot.getString(Constants.KEY_SPECIAL);
                            profile.validity = queryDocumentSnapshot.getString(Constants.KEY_VALIDITY);
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                String CurrentDate = sdf.format(new Date());
                                String FinalDate = profile.currentDateandTime;
                                Date date1;
                                Date date2;
                                SimpleDateFormat dates = new SimpleDateFormat("dd.MM.yyyy  HH:mm");
                                date1 = dates.parse(CurrentDate);
                                date2 = dates.parse(FinalDate);
                                long difference = Math.abs(date1.getTime() - date2.getTime());
                                long differenceDates = difference / (24 * 60 * 60 * 1000);
                                long valid = Long.parseLong(profile.validity);
                                if (differenceDates <= valid) {
                                    if (profile.special == null) {
                                        if(profile.gender.equals("Female")) {
                                            if(profile.divorced.equals("Yes")) {
                                                profiles.add(profile);
                                            }
                                        }
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (profiles.size() > 0) {
                            ProfileAdapter  profileAdapter = new ProfileAdapter(profiles, advertisements, this,this);
                            binding.divorcedrecycler.setAdapter(profileAdapter);
                            binding.divorcedrecycler.setVisibility(View.VISIBLE);
                        } else {

                        }
                    } else {

                    }
                });
    }

    @Override
    public void onProfileClicked(Profile profile) {
        Intent intent = new Intent(getApplicationContext(),PostProfileDetailActivity.class);
        intent.putExtra(Constants.KEY_PROFILE,profile);
        intent.putExtra(Constants.KEY_PROFILE_DATEOFBIRTH,profile);
        intent.putExtra(Constants.KEY_PROFILE_FIRST_NAME,profile);
        intent.putExtra(Constants.KEY_PROFILE_MIDDLE_NAME,profile);
        intent.putExtra(Constants.KEY_PROFILE_LAST_NAME,profile);
        intent.putExtra(Constants.KEY_GENDER,profile);
        intent.putExtra(Constants.KEY_FATHER_NAME,profile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_MOTHER_NAME,profile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_CURRENT_ADDRESS,profile);
        intent.putExtra(Constants.KEY_HOMETOWN_ADDRESS,profile);
        intent.putExtra(Constants.KEY_DESCRIPTION,profile);
        intent.putExtra(Constants.KEY_IS_MANGLIK,profile);
        intent.putExtra(Constants.KEY_IS_DIVORCED,profile);
        intent.putExtra(Constants.KEY_ALLOW_CALL,profile);
        intent.putExtra(Constants.KEY_IS_WIDOW,profile);
        intent.putExtra(Constants.KEY_SELECT_BROTHER,profile);
        intent.putExtra(Constants.KEY_SELECT_SISTER,profile);
        intent.putExtra(Constants.KEY_MONTHLY_INCOME,profile);
        intent.putExtra(Constants.KEY_SELECT_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_SELECT_EDUCATION,profile);
        intent.putExtra(Constants.KEY_CAST,profile);
        intent.putExtra(Constants.KEY_WEIGHT,profile);
        intent.putExtra(Constants.KEY_CONTACT_NO,profile);
        intent.putExtra(Constants.KEY_HEIGHT_INCHES,profile);
        intent.putExtra(Constants.KEY_HEIGHT_FEET,profile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,profile);
        intent.putExtra(Constants.KEY_POST_IMAGE,profile);
        intent.putExtra(Constants.KEY_CURRENT_DATE_TIME,profile);
        intent.putExtra(Constants.KEY_CITY,profile);
        intent.putExtra(Constants.KEY_STATE,profile);
        intent.putExtra(Constants.KEY_PROFILE_RECIEVER_ID,profile);
        intent.putExtra(Constants.KEY_FCM_TOKEN,profile);
        intent.putExtra(Constants.KEY_SPECIAL,"null");
        intent.putExtra(Constants.KEY_ACTIVITY,"divorce");
        startActivity(intent);
        finish();
    }

    @Override
    public void onSpecialProfileClicked(SpecialProfile specialProfile) {
        Intent intent = new Intent(getApplicationContext(),PostProfileDetailActivity.class);
        intent.putExtra(Constants.KEY_PROFILE,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_DATEOFBIRTH,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_FIRST_NAME,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_MIDDLE_NAME,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_LAST_NAME,specialProfile);
        intent.putExtra(Constants.KEY_GENDER,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_NAME,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_NAME,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_CURRENT_ADDRESS,specialProfile);
        intent.putExtra(Constants.KEY_HOMETOWN_ADDRESS,specialProfile);
        intent.putExtra(Constants.KEY_DESCRIPTION,specialProfile);
        intent.putExtra(Constants.KEY_IS_MANGLIK,specialProfile);
        intent.putExtra(Constants.KEY_IS_DIVORCED,specialProfile);
        intent.putExtra(Constants.KEY_ALLOW_CALL,specialProfile);
        intent.putExtra(Constants.KEY_IS_WIDOW,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_BROTHER,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_SISTER,specialProfile);
        intent.putExtra(Constants.KEY_MONTHLY_INCOME,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_SELECT_EDUCATION,specialProfile);
        intent.putExtra(Constants.KEY_CAST,specialProfile);
        intent.putExtra(Constants.KEY_WEIGHT,specialProfile);
        intent.putExtra(Constants.KEY_HEIGHT_INCHES,specialProfile);
        intent.putExtra(Constants.KEY_HEIGHT_FEET,specialProfile);
        intent.putExtra(Constants.KEY_MOTHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_FATHER_OCCUPATION,specialProfile);
        intent.putExtra(Constants.KEY_POST_IMAGE,specialProfile);
        intent.putExtra(Constants.KEY_CURRENT_DATE_TIME,specialProfile);
        intent.putExtra(Constants.KEY_CONTACT_NO,specialProfile);
        intent.putExtra(Constants.KEY_PROFILE_RECIEVER_ID,specialProfile);
        intent.putExtra(Constants.KEY_FCM_TOKEN,specialProfile);
        intent.putExtra(Constants.KEY_CITY,specialProfile);
        intent.putExtra(Constants.KEY_STATE,specialProfile);
        intent.putExtra(Constants.KEY_SPECIAL,"special");
        intent.putExtra(Constants.KEY_ACTIVITY,"divorce");
        startActivity(intent);
        finish();
    }


    @Override
    public void onBackPressed() {
        startActivity(new Intent(DivorcedActivity.this,HomeActivity.class));
    }
}