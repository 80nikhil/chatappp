package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.HashMap;

public class ProfileActivity extends AppCompatActivity {

    LinearLayout terms,about,refund,support,privacy,logout,changepassword,UpdateProfile;
    RoundedImageView imgregister;
    TextView txtname;
    ImageView Backbtn;
    private PrefrenceManager prefrenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        terms = findViewById(R.id.Term);
        about = findViewById(R.id.About_us);
        refund = findViewById(R.id.Refund);
        support = findViewById(R.id.supported);
        privacy = findViewById(R.id.Privacy);
        logout = findViewById(R.id.logout);
        changepassword = findViewById(R.id.change_pass);
        imgregister = findViewById(R.id.img_register);
        txtname = findViewById(R.id.txtname);
        UpdateProfile = findViewById(R.id.NameEdit);
        Backbtn = findViewById(R.id.Backbtn);
        prefrenceManager = new PrefrenceManager(getApplicationContext());
        loadUserDetails();

        Backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(i);
            }
        });

        UpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),UpdateProfileActivity.class);
                startActivity(intent);
            }
        });

        changepassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,ChangePassword.class);
                startActivity(i);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signout();
            }
        });

        terms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,TermActivity.class);
                startActivity(i);
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,AboutActivity.class);
                startActivity(i);
            }
        });
        refund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,RefundActivity.class);
                startActivity(i);
            }
        });
        support.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,SupportActivity.class);
                startActivity(i);
            }
        });
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProfileActivity.this,privacyActivity.class);
                startActivity(i);
            }
        });
    }

    private  void  signout(){
        Toast.makeText(ProfileActivity.this,"Logging Out",Toast.LENGTH_SHORT).show();
        FirebaseFirestore database = FirebaseFirestore.getInstance();
        DocumentReference documentReference  = database.collection(Constants.KEY_COLLECTION_USERS)
                .document(prefrenceManager.getString(Constants.KEY_USER_ID));
        HashMap<String,Object> updates = new HashMap<>();
        updates.put(Constants.KEY_FCM_TOKEN, FieldValue.delete());
        documentReference.update(updates)
                .addOnSuccessListener(unused -> {
                    prefrenceManager.putBoolean(Constants.KEY_IS_SIGNED_IN,false);
                    startActivity(new Intent(getApplicationContext(), SignInactivity.class));
                    finish();
                });
    }

    private void loadUserDetails(){
        txtname.setText(prefrenceManager.getString(Constants.KEY_NAME));
        byte[] bytes = Base64.decode(prefrenceManager.getString(Constants.KEY_IMAGE),Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);
        imgregister.setImageBitmap(bitmap);
    }
}