package com.example.chatapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.chatapp.R;
import com.example.chatapp.utilities.Constants;
import com.example.chatapp.utilities.PrefrenceManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    ImageView mapbutton;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    SearchView searchView;
    Geocoder geocoder;
    Button btncontinue;
    EditText edtaddress;
    private GoogleMap mMap;
    String addres,city,state;
    PrefrenceManager prefrenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        prefrenceManager = new PrefrenceManager(getApplicationContext());
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        mapbutton = findViewById(R.id.mapbutton);
        searchView = findViewById(R.id.sv_location);
        edtaddress = findViewById(R.id.edtadress);
        btncontinue = findViewById(R.id.btn_continue);


        fetchLocation();
        btncontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(prefrenceManager.getString(Constants.KEY_ID ).equals("hometown")){
                    Intent intent = new Intent();
                    intent.putExtra(Constants.KEY_HOMETOWN_ADDRESS,edtaddress.getText().toString());
                    setResult(RESULT_OK, intent);
                    finish();
                }else if(prefrenceManager.getString(Constants.KEY_ID ).equals("current")){
                    Intent intent = new Intent();
                    intent.putExtra(Constants.KEY_CURRENT_ADDRESS,edtaddress.getText().toString());
                    intent.putExtra(Constants.KEY_POST_CITY,city);
                    intent.putExtra(Constants.KEY_POST_STATE,state);
                    setResult(RESULT_OK, intent);
                    finish();
                }else if(prefrenceManager.getString(Constants.KEY_ID ).equals("advertisement")) {
                    Intent intent = new Intent();
                    intent.putExtra(Constants.KEY_ADVERTISEMENT_ADDRESS,edtaddress.getText().toString());
                    setResult(RESULT_OK, intent);
                    finish();
                    prefrenceManager.putString(Constants.KEY_ADVERTISEMENT_ADDRESS, edtaddress.getText().toString());
                }if(prefrenceManager.getString(Constants.KEY_SCREEN_ID).equals("updateprofile")) {
                    if(prefrenceManager.getString(Constants.KEY_ID).equals("updatecurrent")) {
                        Intent i = new Intent(MapActivity.this, UpdateProfileActivity.class);
                        prefrenceManager.putString(Constants.KEY_CURRENT_ADDRESS,edtaddress.getText().toString());
                        startActivity(i);
                    }else if(prefrenceManager.getString(Constants.KEY_ID).equals("updatehometown")) {
                        Intent i = new Intent(MapActivity.this, UpdateProfileActivity.class);
                        prefrenceManager.putString(Constants.KEY_LOCATION, edtaddress.getText().toString());
                        startActivity(i);
                    }
                }if(prefrenceManager.getString(Constants.KEY_SCREEN_ID).equals("boy")){
                Intent i = new Intent(MapActivity.this,BoyActivity.class);
                prefrenceManager.putString(Constants.KEY_STATE,state);
                i.putExtra(Constants.KEY_STATE,state);
                i.putExtra(Constants.KEY_CITY,city);
                i.putExtra(Constants.KEY_CURRENT_ADDRESS,addres);
                startActivity(i);
                }if(prefrenceManager.getString(Constants.KEY_SCREEN_ID).equals("girl")){
                    Intent i = new Intent(MapActivity.this,GirlActivity.class);
                    prefrenceManager.putString(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_CITY,city);
                    i.putExtra(Constants.KEY_CURRENT_ADDRESS,addres);
                    startActivity(i);
                }if(prefrenceManager.getString(Constants.KEY_SCREEN_ID).equals("divorce")){
                    Intent i = new Intent(MapActivity.this,DivorcedActivity.class);
                    prefrenceManager.putString(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_CITY,city);
                    i.putExtra(Constants.KEY_CURRENT_ADDRESS,addres);
                    startActivity(i);
                }if(prefrenceManager.getString(Constants.KEY_SCREEN_ID).equals("widow")){
                    Intent i = new Intent(MapActivity.this,WidowActivity.class);
                    prefrenceManager.putString(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_STATE,state);
                    i.putExtra(Constants.KEY_CITY,city);
                    i.putExtra(Constants.KEY_CURRENT_ADDRESS,addres);
                    startActivity(i);
                }
            }
        });

            mapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchLocation();
            }
        });

    }


    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.myMap);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(MapActivity.this);
                }
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                MarkerOptions markerOptions=new MarkerOptions();
                String location = searchView.getQuery().toString();
                List<Address> addresslist = null;

                if(location!=null || !location.equals("")){
                    Geocoder geocoder = new Geocoder(MapActivity.this);
                    try{
                        addresslist = geocoder.getFromLocationName(location,1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Address address = addresslist.get(0);
                LatLng latLng = new LatLng(address.getLatitude(),address.getLongitude());
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(latLng).title(location));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,20));
                List<Address> addresses;
                geocoder = new Geocoder(MapActivity.this, Locale.getDefault());

                try {
                    addresses = geocoder.getFromLocation(address.getLatitude(),address.getLongitude(), 1);
                     addres = addresses.get(0).getAddressLine(0);
                     city = addresses.get(0).getLocality();
                     state = addresses.get(0).getAdminArea();
                    String country = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    String knownName = addresses.get(0).getFeatureName();
                    edtaddress.setText(addres);
                    prefrenceManager.putString(Constants.KEY_CITY,city);
                    prefrenceManager.putString(Constants.KEY_STATE,state);
                    markerOptions.title(addres);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.clear();
        LatLng latLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here!");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 50));
        googleMap.addMarker(markerOptions);
        getaddress();

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                MarkerOptions markerOptions=new MarkerOptions();
                markerOptions.position(latLng);
                googleMap.clear();
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,50));
                googleMap.addMarker(markerOptions);
                List<Address> addresses;
                geocoder = new Geocoder(MapActivity.this, Locale.getDefault());

                try {
                    addresses = geocoder.getFromLocation(latLng.latitude,latLng.longitude, 1);
                    addres = addresses.get(0).getAddressLine(0);
                    city = addresses.get(0).getLocality();
                    state = addresses.get(0).getAdminArea();
                    String country = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    String knownName = addresses.get(0).getFeatureName();
                    edtaddress.setText(addres);
                    prefrenceManager.putString(Constants.KEY_CITY,city);
                    prefrenceManager.putString(Constants.KEY_STATE,state);
                    markerOptions.title(addres);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void getaddress() {
        List<Address> addresses;
        geocoder = new Geocoder(MapActivity.this, Locale.getDefault());

        try {
            LatLng latLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
            addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            addres = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
             city = addresses.get(0).getLocality();
             state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            String knownName = addresses.get(0).getFeatureName();
            edtaddress.setText(addres);
            prefrenceManager.putString(Constants.KEY_CITY,city);
            prefrenceManager.putString(Constants.KEY_STATE,state);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}