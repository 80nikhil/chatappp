package com.example.chatapp;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

public class PersistentBag {
    public JSONArray mybagcart = new JSONArray();

    SharedPreferences sharedPreferences ;
    private static PersistentBag ourInstance = null;
    public static PersistentBag getInstance(Context context) {
        if (ourInstance == null){
            ourInstance = new PersistentBag(context);
        }
        return ourInstance;
    }
    private PersistentBag(Context context) {
        sharedPreferences = context.getSharedPreferences("my_prefrence", MODE_PRIVATE);
    }

    public JSONArray getMybagcart(){
        try {
            mybagcart = new JSONArray(sharedPreferences.getString("mycart","[]"));
            return mybagcart;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new JSONArray();
    }

    public void setMybagcart(JSONArray mybagcart) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("mycart",mybagcart.toString());
        editor.commit();
    }


}