package com.example.chatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatapp.activities.AdvertisementdetailActivity;
import com.example.chatapp.activities.FavoritePostDetailActivity;
import com.example.chatapp.databinding.ItemContainerPostAdvertisementBinding;
import com.example.chatapp.databinding.ItemContainerPostProfileBinding;
import com.example.chatapp.listeners.ProfileListener;
import com.example.chatapp.models.Advertisement;
import com.example.chatapp.models.SpecialProfile;
import com.example.chatapp.utilities.Constants;

import java.util.List;

public class SpecialProfileAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    final int VIEW_TYPE_POST = 0;
    final int VIEW_TYPE_ADVERTISEMENT = 1;
    List<SpecialProfile> specialprofiles;
    List<Advertisement> advertisements;
    public final ProfileListener profileListener;
    Context  context;

    public  SpecialProfileAdapter(List<SpecialProfile> specialprofiles, List<Advertisement> advertisements, ProfileListener profileListener,Context context){
        this.specialprofiles = specialprofiles;
        this.advertisements = advertisements;
        this.profileListener = profileListener;
        this.context = context;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType == VIEW_TYPE_POST){
            return new SpecialProfileAdapter.MessageViewHolder(
                    ItemContainerPostProfileBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        }
        if(viewType == VIEW_TYPE_ADVERTISEMENT){
            return new SpecialProfileAdapter.ImageViewHolder(
                    ItemContainerPostAdvertisementBinding.inflate(
                            LayoutInflater.from(parent.getContext()),
                            parent,
                            false
                    )
            );
        }

        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        try {
            if (getItemViewType(position) == VIEW_TYPE_POST) {
                ((SpecialProfileAdapter.MessageViewHolder) holder).setData(specialprofiles.get(position - ((position/5)+1)));
            }
            else if(getItemViewType(position) == VIEW_TYPE_ADVERTISEMENT){
                ((SpecialProfileAdapter.ImageViewHolder) holder).setData(advertisements.get(position/5));
            }
        }catch(Exception e){

        }
    }
    @Override
    public int getItemCount() {
        return  specialprofiles.size()+advertisements.size();
    }

    @Override
    public int getItemViewType(int position){
        if(specialprofiles.isEmpty() == false) {
            if (position % 5 != 0) {
                return VIEW_TYPE_POST;
            }
        }else {
            return VIEW_TYPE_ADVERTISEMENT;
        }
        return VIEW_TYPE_ADVERTISEMENT;
    }
    public class MessageViewHolder extends RecyclerView.ViewHolder {
        private final ItemContainerPostProfileBinding binding;

        MessageViewHolder(ItemContainerPostProfileBinding itemContainerPostProfileBinding) {
            super(itemContainerPostProfileBinding.getRoot());
            binding = itemContainerPostProfileBinding;
        }
        public void setData(SpecialProfile specialprofiles) {
            binding.profilePostName.setText(specialprofiles.firstname+" "+specialprofiles.middlename+" "+specialprofiles.lastname);
            binding.profiledateofbirth.setText(specialprofiles.dateofbirth);
            binding.profilegender.setText(specialprofiles.gender);
            binding.profileheight.setText(specialprofiles.heightfeet+" "+specialprofiles.heightinch);
            if(specialprofiles.manglik.equals("yes")){
                binding.profilemanglik.setText("manglik");
            }else{
                binding.profilemanglik.setText("not-manglik");
            }
            binding.profilecurrenttimedate.setText(specialprofiles.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(specialprofiles.profileimage));
            binding.profilecast.setText(specialprofiles.cast);
            binding.profilecity.setText(specialprofiles.city);
            binding.profilestate.setText(specialprofiles.state);
            if(specialprofiles.special != null){
                binding.ribbon.setVisibility(View.VISIBLE);
            }
            binding.getRoot().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    profileListener.onSpecialProfileClicked(specialprofiles);
                    Intent i = new Intent(context, FavoritePostDetailActivity.class);
                    i.putExtra(Constants.KEY_ID,specialprofiles.fcmtoken);
                    i.putExtra(Constants.KEY_SPECIAL,specialprofiles.special);
                    context.startActivity(i);
                }
            });
        }
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder {
        private final  ItemContainerPostAdvertisementBinding binding;

        ImageViewHolder(ItemContainerPostAdvertisementBinding itemContainerPostAdvertisementBinding) {
            super(itemContainerPostAdvertisementBinding.getRoot());
            binding = itemContainerPostAdvertisementBinding;
        }
        public void setData(Advertisement advertisement) {
            binding.TitleName.setText(advertisement.titlename);
            binding.OwnerName.setText(advertisement.ownername);
            binding.OwnerContacts.setText(advertisement.ownercontact);
            binding.Description.setText(advertisement.description);
            binding.currentAddress.setText(advertisement.currentadress);
            binding.currentdatetime.setText(advertisement.currentDateandTime);
            binding.profilePostImage.setImageBitmap(getProfileImage(advertisement.advertiseimage));
            binding.cardads.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context.getApplicationContext(), AdvertisementdetailActivity.class);
                    i.putExtra(Constants.KEY_ID,advertisement.id);
                    context.startActivity(i);
                }
            });
        }
    }
    private Bitmap getProfileImage(String encodedImage){
        byte[] bytes = Base64.decode(encodedImage,Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes,0, bytes.length);
    }
}
