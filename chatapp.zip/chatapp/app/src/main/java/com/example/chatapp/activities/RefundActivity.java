package com.example.chatapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import com.example.chatapp.R;

public class RefundActivity extends AppCompatActivity {
 WebView mywebview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund);


        mywebview = findViewById(R.id.mywebview);
        mywebview.loadUrl("https://kushwahasamajshubhvivah.com/refund");
        mywebview.getSettings().setDomStorageEnabled(true);
        mywebview.getSettings().setJavaScriptEnabled(true);
    }
}