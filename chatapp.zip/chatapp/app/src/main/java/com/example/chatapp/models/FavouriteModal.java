package com.example.chatapp.models;


public class FavouriteModal {
    String name,dateofbirth, education,sister,brother,cast,textdatetime,city,favimage,special,validity,id;

    public FavouriteModal(String name, String dateofbirth, String education, String sister, String brother
            , String cast, String textdatetime, String city, String favimage,String special,String validity,String id) {
        this.name = name;
        this.dateofbirth = dateofbirth;
        this.education = education;
        this.sister = sister;
        this.brother = brother;
        this.cast = cast;
        this.textdatetime = textdatetime;
        this.city = city;
        this.favimage = favimage;
        this.special = special;
        this.validity = validity;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) {
        this.special = special;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public String getFavimage() {
        return favimage;
    }

    public void setFavimage(String favimage) {
        this.favimage = favimage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getSister() {
        return sister;
    }

    public void setSister(String sister) {
        this.sister = sister;
    }

    public String getBrother() {
        return brother;
    }

    public void setBrother(String brother) {
        this.brother = brother;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getTextdatetime() {
        return textdatetime;
    }

    public void setTextdatetime(String textdatetime) {
        this.textdatetime = textdatetime;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
